function [ep,out] = VBA_groupBMCbtw(L,options,factors)
    error('*** This function is deprecated. Please use VBA_groupBMC_btwConds instead. See also VBA_groupBMC_btwGroups.')
end