function [subjectID] = shellmdl_format_subjectID(subject)
% subjectID = shellmdl_format_subjectID(subject)
%
% shellmdl_format_subjectID is a function stored in the "utils" folder that 
% translates integer subject numbers into the respective subjectIDs 
% (strings).
%
% Author: Vasco A. Concei��o
%
% Last modified: September 2023

%%
if subject < 10
    subjectID = ['000' num2str(subject)];
elseif subject >= 10 && subject < 100
    subjectID = ['00' num2str(subject)];
elseif subject >= 100 && subject < 1000
    subjectID = ['0' num2str(subject)];
elseif subject >= 1000 && subject < 10000
    subjectID = num2str(subject);
else
    error('The introduced subjectID does not seem to be correct.');
end;
end

