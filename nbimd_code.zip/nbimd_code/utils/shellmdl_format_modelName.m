function [modelName] = shellmdl_format_modelName(modelNumber, options)
% modelName = shellmdl_format_modelName(modelNumber, options)
%
% shellmdl_format_modelName is a function stored in the "utils" folder that 
% translates model numbers into the respective modelNames (strings), 
% according to the information stored in options.
%
% Author: Vasco A. Concei��o
%
% Last modified: September 2023

modelName = options.rl.modelNames{modelNumber, 1};

end