function [subjIndices] = shellmdl_subj2indices(subjects, options)
% [subjIndices] = shellmdl_subj2indices(subjects, options)
%
% shellmdl_subj2indices is a function stored in the "utils" folder that 
% returns a sorted list of the indices of the input subjects.
%
% Called in:
%   shellmdl_assess_btw_group_differences_in_model_frequencies;
%   ...
%
% List of key auxiliary functions:
%   [none]
%
% Author: Vasco A. Concei��o
%
% Last modified: September 2023

subjects    = intersect(subjects, options.dataset.subjects);

subjects    = sort(subjects);
subjIndices = - Inf * ones(size(subjects));

counter = 1;
iSubj   = 1;

while counter <= numel(subjects) && iSubj <= numel(options.dataset.subjects)
    if subjects(counter) == options.dataset.subjects(iSubj)
        subjIndices(counter) = iSubj;
        counter = counter + 1;
    end;
    iSubj = iSubj + 1;
end;
end