function [paths] = shellmdl_paths(paths, varargin)
% paths = shellmdl_paths(paths, varargin)
%
% shellmdl_paths is a function that is used to define all paths of 
% interest, based on the main paths defined in shellmdl_set_main_paths: 
% paths.datadir, paths.codedir, paths.tapascodedir (if applicable), and 
% paths.resultsdir. 
%
%   INPUT:
%           paths                           Essential input (struct)
%           session                         Optional input (integer)
%           subject                         Optional input (integer)
%           modelNumber                     Optional input (integer)
%           options                         Optional input; to be provided
%                                       together with modelNumber (struct)
%
%   OUTPUT:
%           paths
%
% This function is called several times, by other functions and scripts, as
% many of the paths specified here are specific to the input session and/or
% subject and/or modelNumber.
% 
% This function should not require any additional configuration.
%
% List of key auxiliary functions:
%   shellmdl_format_subjectID               Inside the "utils" subfolder
%   shellmdl_format_modelName               Inside the "utils" subfolder
%
% Note: This function was adapted from other projects; thus, it may reflect
% the contribution from several authors.
%
% Last modified: December 2023

%% Preprocess the input
if nargin == 2
    if numel(varargin{1}) == 1
        session = varargin{1};
    else
        session = 0;                    % error code to be used when the session is not relevant
    end;
    
elseif nargin == 3
    if numel(varargin{1}) == 1
        session = varargin{1};
    else
        session = 0;                    % error code to be used when the session is not relevant
    end;
    subject = varargin{2};
    
elseif nargin == 5 % nargin == 4 does not make sense, as options should
    % always be provided together with modelNumber
    if numel(varargin{1}) == 1
        session = varargin{1};
    else
        session = 0;                    % error code to be used when the session is not relevant
    end;
    subject = varargin{2};
    modelNumber = varargin{3};
    options = varargin{4};
    
else
    error('A wrong number of input arguments was used in shellmdl_paths.');
end;

if nargin > 1
    if session > 1
        error('Only data from the first session should be analyzed for this project.');
    end;
end;

%% Define the general data-, code-, and results-related paths and files
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% data (sub)folders
paths.data.rawdir               = paths.datadir;                                                            % folder with the raw data                      (unchanged raw files)
paths.data.manpreprocdir        = paths.datadir;                                                            % folder with the manually preprocessed data    (files obtained from the raw files via manual preprocessing before the MATLAB code was run)
paths.data.preprocdir           = fullfile(paths.datadir, 'preproc');                                       % folder with the preprocessed data             (files obtained from the manually preprocessed files by running the MATLAB code)

paths.data.manpreproc.behavdir  = [paths.data.manpreprocdir filesep 'A_Behav' filesep 'behavior'];          % folder with the manually preprocessed individual behavioral data (obtained by extracting the raw .zip file)
paths.data.preproc.behavdir     = fullfile(paths.data.preprocdir, 'individ_behav_data');                    % folder with the preprocessed individual behavioral data

% data (sub)files
paths.data.raw.maingroupdatafile            = fullfile(paths.data.rawdir, 'A_Data.csv');                    % raw main data file
paths.data.raw.ocirgroupdatafile            = fullfile(paths.data.rawdir, 'A_OCIR.csv');                    % raw OCI-R data file

paths.data.manpreproc.maingroupdatafile     = fullfile(paths.data.rawdir, 'A_Data.xls');                    % manually preprocessed main data file  (raw .csv file saved as a .xls file with comma-delimited information in different columns)
paths.data.manpreproc.ocirgroupdatafile     = fullfile(paths.data.rawdir, 'A_OCIR.xls');                    % manually preprocessed OCI-R data file (raw .csv file saved as a .xls file with comma-delimited information in different columns)

paths.data.preproc.maingroupdatafile        = fullfile(paths.data.preprocdir, 'main_data_file.xls');        % copy of the raw .csv main data file
paths.data.preproc.ocirgroupdatafile        = fullfile(paths.data.preprocdir, 'ocir_data_file.xls');        % copy of the raw .csv OCI-R data file

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% code folders
paths.code.configdir            = fullfile(paths.codedir, 'config');
paths.code.stepsdir             = fullfile(paths.codedir, 'steps');
paths.code.utilsdir             = fullfile(paths.codedir, 'utils');

% code subfolders
paths.code.steps.groupdir                   = fullfile(paths.code.stepsdir, 'group');
paths.code.steps.qualitydir                 = fullfile(paths.code.stepsdir, 'quality');
paths.code.steps.subjectsdir                = fullfile(paths.code.stepsdir, 'subjects');
paths.code.steps.taskdir                    = fullfile(paths.code.stepsdir, 'task');

paths.code.steps.group.behaviordir                      = fullfile(paths.code.steps.groupdir, 'behavior');
paths.code.steps.group.demographicsdir                  = fullfile(paths.code.steps.groupdir, 'demographics');
paths.code.steps.group.drugdir                          = fullfile(paths.code.steps.groupdir, 'drug');
paths.code.steps.group.modelcomparisondir               = fullfile(paths.code.steps.groupdir, 'modelcomparison');
paths.code.steps.group.modelfitdir                      = fullfile(paths.code.steps.groupdir, 'modelfit');
paths.code.steps.group.modelsimulationsdir              = fullfile(paths.code.steps.groupdir, 'modelsimulations');
paths.code.steps.group.regressiondir                    = fullfile(paths.code.steps.groupdir, 'regression');

paths.code.steps.subjects.behaviordir                   = fullfile(paths.code.steps.subjectsdir, 'behavior');
paths.code.steps.subjects.modelfitdir                   = fullfile(paths.code.steps.subjectsdir, 'modelfit');
paths.code.steps.subjects.modelsimulationsdir           = fullfile(paths.code.steps.subjectsdir, 'modelsimulations');

paths.code.steps.group.regression.behavior2drugdir              = fullfile(paths.code.steps.group.regressiondir, 'behavior2drug');
paths.code.steps.group.regression.behavior2questiondir          = fullfile(paths.code.steps.group.regressiondir, 'behavior2question');
paths.code.steps.group.regression.behavior2drugquestiondir      = fullfile(paths.code.steps.group.regressiondir, 'behavior2drugquestion');

paths.code.steps.group.regression.model2drugdir                 = fullfile(paths.code.steps.group.regressiondir, 'model2drug');
paths.code.steps.group.regression.model2questiondir             = fullfile(paths.code.steps.group.regressiondir, 'model2question');
paths.code.steps.group.regression.model2drugquestiondir         = fullfile(paths.code.steps.group.regressiondir, 'model2drugquestion');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% tapas code folders
% paths.tapascode.popmcmcdir   	= fullfile(paths.tapascodedir, 'popmcmc');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% results folders
paths.results.groupdir              = fullfile(paths.resultsdir, 'group');
paths.results.qualitydir            = fullfile(paths.resultsdir, 'quality');
paths.results.subjectsdir           = fullfile(paths.resultsdir, 'subjects');
paths.results.taskdir               = fullfile(paths.resultsdir, 'task');
paths.results.modelsimulationsdir   = fullfile(paths.resultsdir, 'modelsimulations');

% results subfolders
paths.results.group.behaviordir                 = fullfile(paths.results.groupdir, 'behavior');
paths.results.group.behavior2modeldir           = fullfile(paths.results.groupdir, 'behavior2model');
paths.results.group.demographicsdir             = fullfile(paths.results.groupdir, 'demographics');
paths.results.group.drugdir                     = fullfile(paths.results.groupdir, 'drug');
paths.results.group.questionnairesdir           = fullfile(paths.results.groupdir, 'questionnaires');
paths.results.group.modelcomparisondir          = fullfile(paths.results.groupdir, 'modelcomparison');
paths.results.group.modelfitdir                 = fullfile(paths.results.groupdir, 'modelfit');
paths.results.group.modelinspectiondir          = fullfile(paths.results.groupdir, 'modelinspection');
paths.results.group.modelsimulationsdir         = fullfile(paths.results.groupdir, 'modelsimulations');
paths.results.group.regressiondir               = fullfile(paths.results.groupdir, 'regression');
paths.results.group.ccadir                      = fullfile(paths.results.groupdir, 'cca');
paths.results.group.linearmodelsdir             = fullfile(paths.results.groupdir, 'linearmodels');
paths.results.group.selectedmodelsanalysisdir  	= fullfile(paths.results.groupdir, 'selectedmodelsanalysis');
paths.results.group.behavioralreplicationdir    = fullfile(paths.results.groupdir, 'behavioralreplication');

paths.results.modelsimulations.pocdir         	= fullfile(paths.results.modelsimulationsdir,       'poc');
paths.results.modelsimulations.poc.figuresdir 	= fullfile(paths.results.modelsimulations.pocdir,  	'figures');

%% Define the session-specific paths and files
if nargin > 1
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % results/.../sessionX folders
    paths.results.group.behavior.tempsessiondir                 = fullfile(paths.results.group.behaviordir,                 ['session' num2str(session)]);
    paths.results.group.behavior2model.tempsessiondir           = fullfile(paths.results.group.behavior2modeldir,           ['session' num2str(session)]);
    paths.results.group.drug.tempsessiondir                     = fullfile(paths.results.group.drugdir,                     ['session' num2str(session)]);
    paths.results.group.questionnaires.tempsessiondir           = fullfile(paths.results.group.questionnairesdir,           ['session' num2str(session)]);
    paths.results.group.modelcomparison.tempsessiondir          = fullfile(paths.results.group.modelcomparisondir,          ['session' num2str(session)]);
    paths.results.group.modelfit.tempsessiondir                 = fullfile(paths.results.group.modelfitdir,                 ['session' num2str(session)]);
    paths.results.group.modelinspection.tempsessiondir          = fullfile(paths.results.group.modelinspectiondir,          ['session' num2str(session)]);
    paths.results.group.regression.tempsessiondir               = fullfile(paths.results.group.regressiondir,               ['session' num2str(session)]);
    paths.results.group.cca.tempsessiondir                      = fullfile(paths.results.group.ccadir,                      ['session' num2str(session)]);
    paths.results.group.linearmodels.tempsessiondir             = fullfile(paths.results.group.linearmodelsdir,             ['session' num2str(session)]);
    paths.results.group.selectedmodelsanalysis.tempsessiondir   = fullfile(paths.results.group.selectedmodelsanalysisdir,   ['session' num2str(session)]);
    paths.results.group.behavioralreplication.tempsessiondir    = fullfile(paths.results.group.behavioralreplicationdir,    ['session' num2str(session)]);
    
    % results/.../sessionX subfolders
    paths.results.group.behavior.tempsession.alldir                     = fullfile(paths.results.group.behavior.tempsessiondir, 'all');
    paths.results.group.behavior.tempsession.drugdir                    = fullfile(paths.results.group.behavior.tempsessiondir, 'drug');
    paths.results.group.behavior.tempsession.placebodir                 = fullfile(paths.results.group.behavior.tempsessiondir, 'placebo');
    
    paths.results.group.modelcomparison.tempsession.alldir              = fullfile(paths.results.group.modelcomparison.tempsessiondir, 'all');
    paths.results.group.modelcomparison.tempsession.drugdir             = fullfile(paths.results.group.modelcomparison.tempsessiondir, 'drug');
    paths.results.group.modelcomparison.tempsession.placebodir          = fullfile(paths.results.group.modelcomparison.tempsessiondir, 'placebo');
    
    paths.results.group.modelfit.tempsession.alldir                     = fullfile(paths.results.group.modelfit.tempsessiondir, 'all');
    paths.results.group.modelfit.tempsession.drugdir                    = fullfile(paths.results.group.modelfit.tempsessiondir, 'drug');
    paths.results.group.modelfit.tempsession.placebodir                 = fullfile(paths.results.group.modelfit.tempsessiondir, 'placebo');
    
    paths.results.group.modelinspection.tempsession.alldir              = fullfile(paths.results.group.modelinspection.tempsessiondir, 'all');
    paths.results.group.modelinspection.tempsession.drugdir             = fullfile(paths.results.group.modelinspection.tempsessiondir, 'drug');
    paths.results.group.modelinspection.tempsession.placebodir          = fullfile(paths.results.group.modelinspection.tempsessiondir, 'placebo');
    
    paths.results.group.modelinspection.tempsession.all.pgojamovidir  	= fullfile(paths.results.group.modelinspection.tempsession.alldir, 'pgojamovi');
    
    paths.results.group.modelsimulations.effectofstateinferencedir                      = fullfile(paths.results.group.modelsimulationsdir, 'effectofstateinference');
    paths.results.group.modelsimulations.effectofstateinference.tempsessiondir          = fullfile(paths.results.group.modelsimulations.effectofstateinferencedir, ['session' num2str(session)]);
    paths.results.group.modelsimulations.effectofstateinference.tempsession.alldir      = fullfile(paths.results.group.modelsimulations.effectofstateinference.tempsessiondir, 'all');
    
    paths.results.group.modelsimulations.effectofstateinference.tempsession.all.effectofstateinferencefile          = fullfile(paths.results.group.modelsimulations.effectofstateinference.tempsession.alldir, 'simulation_results.mat');
    paths.results.group.modelsimulations.effectofstateinference.tempsession.all.aggregeffectofstateinferencefile    = fullfile(paths.results.group.modelsimulations.effectofstateinference.tempsession.alldir, 'aggreg_simul_results.mat');
    
    paths.results.group.modelsimulations.effectofstateinference.figuresdir                                          = fullfile(paths.results.group.modelsimulations.effectofstateinferencedir, 'figures');
    
    paths.results.group.modelsimulations.modelrecoverydir                               = fullfile(paths.results.group.modelsimulationsdir, 'modelrecovery');
    paths.results.group.modelsimulations.modelrecovery.tempsessiondir                   = fullfile(paths.results.group.modelsimulations.modelrecoverydir, ['session' num2str(session)]);
    paths.results.group.modelsimulations.modelrecovery.tempsession.alldir               = fullfile(paths.results.group.modelsimulations.modelrecovery.tempsessiondir, 'all');
    
    paths.results.group.modelsimulations.modelrecovery.tempsession.all.modelrecoveryfile        = fullfile(paths.results.group.modelsimulations.modelrecovery.tempsession.alldir, 'simulation_results.mat');
    paths.results.group.modelsimulations.modelrecovery.tempsession.all.aggregmodelrecoveryfile 	= fullfile(paths.results.group.modelsimulations.modelrecovery.tempsession.alldir, 'aggreg_simul_results.mat');
    
    paths.results.group.modelsimulations.modelrecovery.figuresdir                            	= fullfile(paths.results.group.modelsimulations.modelrecoverydir, 'figures');
    
    paths.results.group.modelsimulations.modelrecovery.tempsession.all.figuresdir       = fullfile(paths.results.group.modelsimulations.modelrecovery.tempsession.alldir, 'figures');
    
    paths.results.group.modelsimulations.paramrecoverydir                               = fullfile(paths.results.group.modelsimulationsdir, 'paramrecovery');
    paths.results.group.modelsimulations.paramrecovery.tempsessiondir                   = fullfile(paths.results.group.modelsimulations.paramrecoverydir, ['session' num2str(session)]);
    paths.results.group.modelsimulations.paramrecovery.tempsession.alldir               = fullfile(paths.results.group.modelsimulations.paramrecovery.tempsessiondir, 'all');
    
    paths.results.group.modelsimulations.paramrecovery.tempsession.all.paramrecoveryfile     	= fullfile(paths.results.group.modelsimulations.paramrecovery.tempsession.alldir, 'simulation_results.mat');
    paths.results.group.modelsimulations.paramrecovery.tempsession.all.aggregparamrecoveryfile 	= fullfile(paths.results.group.modelsimulations.paramrecovery.tempsession.alldir, 'aggreg_simul_results.mat');
    
    paths.results.group.modelsimulations.paramrecovery.figuresdir                            	= fullfile(paths.results.group.modelsimulations.paramrecoverydir, 'figures');
    
    paths.results.group.modelsimulations.paramrecovery.tempsession.all.figuresdir               = fullfile(paths.results.group.modelsimulations.paramrecovery.tempsession.alldir, 'figures');
    
    paths.results.group.modelsimulations.paramrecovery.tempsession.all.pholmfile                = fullfile(paths.results.group.modelsimulations.paramrecovery.tempsession.alldir, 'p_holm.xls');
    paths.results.group.modelsimulations.paramrecovery.tempsession.all.puncorrfile              = fullfile(paths.results.group.modelsimulations.paramrecovery.tempsession.alldir, 'p_uncorr.xls');
    
    paths.results.group.regression.tempsession.behavior2drugdir         = fullfile(paths.results.group.regression.tempsessiondir,   'behavior2drug');
    paths.results.group.regression.tempsession.behavior2drugquestiondir = fullfile(paths.results.group.regression.tempsessiondir,   'behavior2drugquestion');
    paths.results.group.regression.tempsession.behavior2questiondir     = fullfile(paths.results.group.regression.tempsessiondir,   'behavior2question');
    
    paths.results.group.regression.tempsession.model2drugdir            = fullfile(paths.results.group.regression.tempsessiondir,   'model2drug');
    paths.results.group.regression.tempsession.model2drugquestiondir    = fullfile(paths.results.group.regression.tempsessiondir,   'model2drugquestion');
    paths.results.group.regression.tempsession.model2questiondir        = fullfile(paths.results.group.regression.tempsessiondir,   'model2question');
    
    paths.results.group.cca.tempsession.alldir                          = fullfile(paths.results.group.cca.tempsessiondir,          'all');
    
    paths.results.group.linearmodels.tempsession.alldir                 = fullfile(paths.results.group.linearmodels.tempsessiondir, 'all');
    
    paths.results.group.selectedmodelsanalysis.tempsession.alldir       = fullfile(paths.results.group.selectedmodelsanalysis.tempsessiondir,   'all');
    
    paths.results.group.behavioralreplication.tempsession.alldir    	= fullfile(paths.results.group.behavioralreplication.tempsessiondir,    'all');
    
    paths.results.group.modelcomparison.tempsession.all.figuresdir          = fullfile(paths.results.group.modelcomparison.tempsession.alldir,          'figures');
    
    paths.results.group.selectedmodelsanalysis.tempsession.all.figuresdir   = fullfile(paths.results.group.selectedmodelsanalysis.tempsession.alldir, 	'figures');
    
    paths.results.group.behavioralreplication.tempsession.all.figuresdir    = fullfile(paths.results.group.behavioralreplication.tempsession.alldir,    'figures');
    
    paths.results.group.behavior.tempsession.all.preprocdir             = fullfile(paths.results.group.behavior.tempsession.alldir,             'preproc');
    paths.results.group.behavior.tempsession.drug.preprocdir            = fullfile(paths.results.group.behavior.tempsession.drugdir,            'preproc');
    paths.results.group.behavior.tempsession.placebo.preprocdir         = fullfile(paths.results.group.behavior.tempsession.placebodir,         'preproc');
    
    paths.results.group.behavior.tempsession.all.procdir                = fullfile(paths.results.group.behavior.tempsession.alldir,             'proc');
    paths.results.group.behavior.tempsession.drug.procdir               = fullfile(paths.results.group.behavior.tempsession.drugdir,            'proc');
    paths.results.group.behavior.tempsession.placebo.procdir            = fullfile(paths.results.group.behavior.tempsession.placebodir,         'proc');
    
    paths.results.group.modelinspection.tempsession.all.figuresdir      = fullfile(paths.results.group.modelinspection.tempsession.alldir,      'figures');
    paths.results.group.modelinspection.tempsession.drug.figuresdir     = fullfile(paths.results.group.modelinspection.tempsession.drugdir,     'figures');
    paths.results.group.modelinspection.tempsession.placebo.figuresdir  = fullfile(paths.results.group.modelinspection.tempsession.placebodir,  'figures');
    
    paths.results.group.behavior.tempsession.all.pgofiguredir           = fullfile(paths.results.group.behavior.tempsession.alldir,             'pgofigure');
    paths.results.group.behavior.tempsession.drug.pgofiguredir          = fullfile(paths.results.group.behavior.tempsession.drugdir,            'pgofigure');
    paths.results.group.behavior.tempsession.placebo.pgofiguredir       = fullfile(paths.results.group.behavior.tempsession.placebodir,         'pgofigure');
    
    paths.results.group.behavior.tempsession.all.pcorrfiguredir      	= fullfile(paths.results.group.behavior.tempsession.alldir,             'pcorrfigure');
    paths.results.group.behavior.tempsession.drug.pcorrfiguredir      	= fullfile(paths.results.group.behavior.tempsession.drugdir,            'pcorrfigure');
    paths.results.group.behavior.tempsession.placebo.pcorrfiguredir   	= fullfile(paths.results.group.behavior.tempsession.placebodir,         'pcorrfigure');
    
    paths.results.group.behavior.tempsession.all.pgojamovidir           = fullfile(paths.results.group.behavior.tempsession.alldir,             'pgojamovi');
    paths.results.group.behavior.tempsession.drug.pgojamovidir          = fullfile(paths.results.group.behavior.tempsession.drugdir,            'pgojamovi');
    paths.results.group.behavior.tempsession.placebo.pgojamovidir       = fullfile(paths.results.group.behavior.tempsession.placebodir,         'pgojamovi');
    
    % results/.../sessionX (sub)files
    paths.results.group.behavior2model.tempsession.stimfile         = fullfile(paths.results.group.behavior2model.tempsessiondir,       'stim_m.mat');  % before, this file was named stims_m; errors may occur if this is/was not replaced everywhere
    paths.results.group.behavior2model.tempsession.actionsfile      = fullfile(paths.results.group.behavior2model.tempsessiondir,       'actions_m.mat'); 
    paths.results.group.behavior2model.tempsession.reinfsfile       = fullfile(paths.results.group.behavior2model.tempsessiondir,       'reinfs_m.mat'); 
    paths.results.group.behavior2model.tempsession.reinfsIfGofile   = fullfile(paths.results.group.behavior2model.tempsessiondir,       'reinfsIfGo_m.mat'); 
    paths.results.group.behavior2model.tempsession.RTsfile          = fullfile(paths.results.group.behavior2model.tempsessiondir,       'RTs_m.mat'); 
    
    paths.results.group.regression.tempsession.behavior2drugfile  	= fullfile(paths.results.group.regression.tempsession.behavior2drugdir, 'behavior2drugfile.mat');
    paths.results.group.regression.tempsession.model2drugfile       = fullfile(paths.results.group.regression.tempsession.model2drugdir,    'model2drugfile.mat');
    
    paths.results.group.behavior.tempsession.all.preprocfile                    = fullfile(paths.results.group.behavior.tempsession.all.preprocdir,     'group_behav_data.mat');
    paths.results.group.behavior.tempsession.drug.preprocfile                   = fullfile(paths.results.group.behavior.tempsession.drug.preprocdir,    'group_behav_data.mat');
    paths.results.group.behavior.tempsession.placebo.preprocfile                = fullfile(paths.results.group.behavior.tempsession.placebo.preprocdir, 'group_behav_data.mat');
    
    paths.results.group.behavior.tempsession.all.procfile                       = fullfile(paths.results.group.behavior.tempsession.all.procdir,        'group_behav_data.mat');
    paths.results.group.behavior.tempsession.drug.procfile                      = fullfile(paths.results.group.behavior.tempsession.drug.procdir,       'group_behav_data.mat');
    paths.results.group.behavior.tempsession.placebo.procfile                   = fullfile(paths.results.group.behavior.tempsession.placebo.procdir,    'group_behav_data.mat');
    
    paths.results.group.behavior.tempsession.all.pgofigurefile               	= fullfile(paths.results.group.behavior.tempsession.all.pgofiguredir,       'group_pgo_season_data.mat');
    paths.results.group.behavior.tempsession.drug.pgofigurefile                 = fullfile(paths.results.group.behavior.tempsession.drug.pgofiguredir,      'group_pgo_season_data.mat');
    paths.results.group.behavior.tempsession.placebo.pgofigurefile            	= fullfile(paths.results.group.behavior.tempsession.placebo.pgofiguredir,   'group_pgo_season_data.mat');
    
    paths.results.group.behavior.tempsession.all.pcorrfigurefile               	= fullfile(paths.results.group.behavior.tempsession.all.pcorrfiguredir, 	'group_pcorr_season_data.mat');
    paths.results.group.behavior.tempsession.drug.pcorrfigurefile           	= fullfile(paths.results.group.behavior.tempsession.drug.pcorrfiguredir,  	'group_pcorr_season_data.mat');
    paths.results.group.behavior.tempsession.placebo.pcorrfigurefile         	= fullfile(paths.results.group.behavior.tempsession.placebo.pcorrfiguredir, 'group_pcorr_season_data.mat');
    
    paths.results.group.behavior.tempsession.all.pgojamovifile               	= fullfile(paths.results.group.behavior.tempsession.all.pgojamovidir,       'group_pgo_season_jamovi_data.xls');
    
    paths.results.group.modelcomparison.tempsession.all.modelEvidencesFile      = fullfile(paths.results.group.modelcomparison.tempsession.alldir, 'modelEvidences.mat');
    paths.results.group.modelcomparison.tempsession.all.McFaddenPseudoR2File  	= fullfile(paths.results.group.modelcomparison.tempsession.alldir, 'McFaddenPseudoR2.mat');
    paths.results.group.modelcomparison.tempsession.all.deltaLogMEfile          = fullfile(paths.results.group.modelcomparison.tempsession.alldir, 'deltaLogME.mat');
    
    paths.results.group.modelcomparison.tempsession.all.lambdasBCxDeltaLogMEfile        = fullfile(paths.results.group.modelcomparison.tempsession.alldir,      'lambdasBCxDeltaLogME.xls');
    
    paths.results.group.modelinspection.tempsession.all.paramApproximationsfile         = fullfile(paths.results.group.modelinspection.tempsession.alldir,      'paramApproximations.mat');
    paths.results.group.modelinspection.tempsession.drug.paramApproximationsfile        = fullfile(paths.results.group.modelinspection.tempsession.drugdir,     'paramApproximations.mat');
    paths.results.group.modelinspection.tempsession.placebo.paramApproximationsfile     = fullfile(paths.results.group.modelinspection.tempsession.placebodir,  'paramApproximations.mat');
    
    paths.results.group.modelinspection.tempsession.all.predictedModelVariablesfile     = fullfile(paths.results.group.modelinspection.tempsession.alldir,      'predictedModelVariables.mat');
    paths.results.group.modelinspection.tempsession.drug.predictedModelVariablesfile    = fullfile(paths.results.group.modelinspection.tempsession.drugdir,     'predictedModelVariables.mat');
    paths.results.group.modelinspection.tempsession.placebo.predictedModelVariablesfile = fullfile(paths.results.group.modelinspection.tempsession.placebodir,  'predictedModelVariables.mat');
    
    paths.results.group.modelinspection.tempsession.all.predictedMeanPGoFile            = fullfile(paths.results.group.modelinspection.tempsession.alldir,      'predictedMeanPGo.mat');
    paths.results.group.modelinspection.tempsession.drug.predictedMeanPGofile           = fullfile(paths.results.group.modelinspection.tempsession.drugdir,     'predictedMeanPGo.mat');
    paths.results.group.modelinspection.tempsession.placebo.predictedMeanPGofile        = fullfile(paths.results.group.modelinspection.tempsession.placebodir,  'predictedMeanPGo.mat');
    
    paths.results.group.modelinspection.tempsession.all.predictedMeanPGoSuppFile        = fullfile(paths.results.group.modelinspection.tempsession.alldir,      'predictedMeanPGoSupp.mat');
    paths.results.group.modelinspection.tempsession.drug.predictedMeanPGoSuppFile       = fullfile(paths.results.group.modelinspection.tempsession.drugdir,     'predictedMeanPGoSupp.mat');
    paths.results.group.modelinspection.tempsession.placebo.predictedMeanPGoSuppFile    = fullfile(paths.results.group.modelinspection.tempsession.placebodir,  'predictedMeanPGoSupp.mat');
    
    paths.results.group.modelinspection.tempsession.all.pgojamovi1file                  = fullfile(paths.results.group.modelinspection.tempsession.all.pgojamovidir, 	'group_pgo_sr8_jamovi_data.xls');
    paths.results.group.modelinspection.tempsession.all.pgojamovi2file                  = fullfile(paths.results.group.modelinspection.tempsession.all.pgojamovidir,   	'group_pgo_ssr8_jamovi_data.xls');

    paths.results.group.cca.tempsession.all.datafile                                    = fullfile(paths.results.group.cca.tempsession.alldir,                  'cca_data.xls');
    paths.results.group.cca.tempsession.all.resultsfile                                 = fullfile(paths.results.group.cca.tempsession.alldir,                  'cca_results.mat');
    
    paths.results.group.linearmodels.tempsession.all.datafile                           = fullfile(paths.results.group.linearmodels.tempsession.alldir,         'linear_models_data.xls');
    paths.results.group.linearmodels.tempsession.all.csvdatafile                        = fullfile(paths.results.group.linearmodels.tempsession.alldir,         'linear_models_data.csv');
    
    paths.results.group.behavioralreplication.tempsession.all.robustregsdatafile            = fullfile(paths.results.group.behavioralreplication.tempsession.alldir,  	'robust_regs_data.xls');
    paths.results.group.behavioralreplication.tempsession.all.csvrobustregsdatafile         = fullfile(paths.results.group.behavioralreplication.tempsession.alldir,  	'robust_regs_data.csv');
    paths.results.group.behavioralreplication.tempsession.all.jamovipgoglmmdatafile         = fullfile(paths.results.group.behavioralreplication.tempsession.alldir, 	'pgo_season_glmm_data.xls');
    paths.results.group.behavioralreplication.tempsession.all.jamovipunfirstphasedatafile  	= fullfile(paths.results.group.behavioralreplication.tempsession.alldir,  	'pgo_pun_first_phase_data.xls');
    paths.results.group.behavioralreplication.tempsession.all.jamovipuninhibdatafile      	= fullfile(paths.results.group.behavioralreplication.tempsession.alldir,   	'pgo_pun_inhib_data.xls');
end;

%% Define the (session-) subject-specific paths and files
if nargin > 2
    subjectID = shellmdl_format_subjectID(subject);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % data subsubfolders
    paths.data.behavior.tempsubjectdir  = [paths.data.preprocdir filesep 'individ_behav_data' filesep 'A' subjectID];
    paths.data.trace.tempsubjectdir     = paths.data.behavior.tempsubjectdir;
    
    % data (sub)files
    if session == 1
        paths.data.behavior.tempsubject.tempsessionfile         = [paths.data.behavior.tempsubjectdir filesep 'GONOGO_shortlog_A' subjectID '.txt'];
        paths.data.behavior.tempsubject.tempsessiontracefile    = [paths.data.trace.tempsubjectdir filesep 'GONOGO_trace_A' subjectID '.csv'];
    elseif session == 0
        % error code, when there is no need to use session information, but
        % subject info is required
    else
        error('The wrong session number was specified.');
    end;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % results subsubfolders
    paths.results.subjects.tempsubjectdir       = fullfile(paths.results.subjectsdir, ['NBIMD_SHELL_' subjectID]);
    
    paths.results.subjects.tempsubject.behaviordir      = fullfile(paths.results.subjects.tempsubjectdir, 'behavior');
    paths.results.subjects.tempsubject.drugdir          = fullfile(paths.results.subjects.tempsubjectdir, 'drug');
    paths.results.subjects.tempsubject.modelsdir        = fullfile(paths.results.subjects.tempsubjectdir, 'models');
    paths.results.subjects.tempsubject.tracedir         = fullfile(paths.results.subjects.tempsubjectdir, 'trace');
    
    paths.results.subjects.tempsubject.behavior.tempsessiondir      = fullfile(paths.results.subjects.tempsubject.behaviordir,  ['session' num2str(session)]);
    paths.results.subjects.tempsubject.drug.tempsessiondir          = fullfile(paths.results.subjects.tempsubject.drugdir,      ['session' num2str(session)]);
    paths.results.subjects.tempsubject.models.tempsessiondir        = fullfile(paths.results.subjects.tempsubject.modelsdir,    ['session' num2str(session)]);
    
    paths.results.subjects.tempsubject.behavior.tempsession.preprocdir      = fullfile(paths.results.subjects.tempsubject.behavior.tempsessiondir, 'preproc');
    paths.results.subjects.tempsubject.behavior.tempsession.procdir         = fullfile(paths.results.subjects.tempsubject.behavior.tempsessiondir, 'proc');
    
    % results (sub)files
    paths.results.subjects.tempsubject.tracefile                            = fullfile(paths.results.subjects.tempsubject.tracedir, ...
        ['trace_data_' num2str(subject) '.mat']);
    paths.results.subjects.tempsubject.behavior.tempsession.preprocfile     = fullfile(paths.results.subjects.tempsubject.behavior.tempsession.preprocdir, ...
        ['behav_data_' num2str(subject) '.mat']);
    paths.results.subjects.tempsubject.behavior.tempsession.procfile        = fullfile(paths.results.subjects.tempsubject.behavior.tempsession.procdir, ...
        ['behav_data_' num2str(subject) '.mat']);
end;

%% Define the ((session-)subject-) model-specific paths and files
if nargin > 3
    modelName = shellmdl_format_modelName(modelNumber, options);
    
    % resuls/.../models folders
    paths.results.subjects.tempsubject.models.tempsessiondir        = fullfile(paths.results.subjects.tempsubject.modelsdir, ['session' num2str(session)]);
    
    paths.results.group.modelinspection.tempsessiondir              = fullfile(paths.results.group.modelinspectiondir, ['session' num2str(session)]);
    
    % resuls/.../models subfolders
    paths.results.subjects.tempsubject.models.tempsession.tempmodeldir      = fullfile(paths.results.subjects.tempsubject.models.tempsessiondir, modelName);
    
    paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelfitdir             = fullfile(paths.results.subjects.tempsubject.models.tempsession.tempmodeldir, 'modelfit');
    paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelinspectiondir     	= fullfile(paths.results.subjects.tempsubject.models.tempsession.tempmodeldir, 'modelinspection');
    paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelsimulationsdir     = fullfile(paths.results.subjects.tempsubject.models.tempsession.tempmodeldir, 'modelsimulations');
    
        
    paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelsimulations.pocdir                         = fullfile(paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelsimulationsdir, 'poc');
    
    paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelsimulations.effectofstateinferencedir      = fullfile(paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelsimulationsdir, 'effectofstateinference');
    paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelsimulations.effectofstateinferencefile     = fullfile(paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelsimulations.effectofstateinferencedir, ['simulResults-' num2str(subject) '.mat']);
    
    paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelsimulations.modelrecoverydir               = fullfile(paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelsimulationsdir, 'modelrecovery');
    paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelsimulations.modelrecoveryfile              = fullfile(paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelsimulations.modelrecoverydir, ['simulResults-' num2str(subject) '.mat']);
    
    paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelsimulations.paramrecoverydir               = fullfile(paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelsimulationsdir, 'paramrecovery');
    paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelsimulations.paramrecoveryfile              = fullfile(paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelsimulations.paramrecoverydir, ['simulResults-' num2str(subject) '.mat']);
    
    paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelinspection.figuresdir  = fullfile(paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelinspectiondir, 'figures');
    
    paths.results.group.modelinspection.tempsession.tempmodeldir                                = fullfile(paths.results.group.modelinspection.tempsessiondir, modelName);
    
    % resuls/.../models (sub)files
    paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelfitdiagnosisfile       = fullfile(paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelfitdir, ['diagResults-' num2str(subject) '.mat']);
    paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelfittifile              = fullfile(paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelfitdir, ['tiResults-' num2str(subject) '.mat']);
    
    paths.results.subjects.tempsubject.models.tempsession.tempmodel.predictedModelVariablesfile = fullfile(paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelinspectiondir, ['predictedModelVariables-' num2str(subject) '.mat']);
end;