function [h, p] = shellmdl_assess_btw_group_differences_in_model_frequencies(options, paths, comparisonInfo, varargin)
% [] = shellmdl_assess_btw_group_differences_in_model_frequencies(options, paths, comparisonInfo, varargin)
%
% shellmdl_assess_btw_group_differences_in_model_frequencies is a function
% that compares the frequency of the RL models of interest across groups,
% using the VBA toolbox, by calling VBA_groupBMC_btwGroups(_changed). If
% varargin is empty, the function assumes that the on- vs. off-escitalopram
% groups are being compared, and:
% - if comparisonInfo == 'main', only S-R and S-S-R models are compared;
% - if comparisonInfo == 'supp', all models are compared.
% If varargin is not empty, the groups specified in varargin{1} are
% analyzed instead; the same rationale applies regarding the candidate
% models. The function then returns the respective h and p.
%
% Called in:
%  shellmdl_master
%  shellmdl_assess_plot_relations_state_inference_stickiness
%
% List of key auxiliary functions:
%  VBA_groupBMC_btwGroups
%  VBA_groupBMC_btwGroups_changed
%
% Author: Vasco A. Concei��o
%
% Last modified: October 2023

%% Comparison of the model frequencies between groups & data saving
paths = shellmdl_paths(paths, 1);
load(paths.results.group.modelcomparison.tempsession.all.modelEvidencesFile);

if isequal(comparisonInfo, 'main')
    ME_TI_m = modelEvidences(options.rl.mainComparisonModels, :);
elseif isequal(comparisonInfo, 'supp')
    ME_TI_m = modelEvidences;
else
    error('Error in shellmdl_assess_btw_group_differences_in_model_frequencies: comparisonInfo was misspecified.');
end;

if nargin < 4   % varagin is empty; two groups (on- vs. off-escitalopram) will be compared
    if options.verbose.modelcomparison
        disp(' ');
        disp(['Running shellmdl_assess_btw_group_differences_in_model_frequencies using comparisonInfo = ' comparisonInfo '...']);
        disp(' ');
    end;
    
    [onDrugSubjs, offDrugSubjs] = shellmdl_process_drug_groups(options, paths);
    
    onDrugSubjIndices   = shellmdl_subj2indices(onDrugSubjs, options);
    offDrugSubjIndices  = shellmdl_subj2indices(offDrugSubjs, options);
    
    ME_TI_onDrug_m  = ME_TI_m(:, onDrugSubjIndices);
    ME_TI_offDrug_m = ME_TI_m(:, offDrugSubjIndices);
    
    [h, p] = VBA_groupBMC_btwGroups({ME_TI_onDrug_m, ME_TI_offDrug_m});
    
else            % varargin is not empty; more than two groups (high-escitalopram, placebo, and low-escitalopram) will be compared
    if options.verbose.modelcomparison || options.verbose.selectedmodelsanalysis
        disp(' ');
        disp('Running shellmdl_assess_btw_group_differences_in_model_frequencies applied to the high-escitalopram, placebo, and low-escitalopram groups...');
        disp(' ');
    end;
    
    groupInfo = varargin{1};
    
    [h, p] = VBA_groupBMC_btwGroups_changed({ME_TI_m(:, groupInfo.highEscitalSubjects), ...
        ME_TI_m(:, groupInfo.placeboSubjects), ...
        ME_TI_m(:, groupInfo.lowEscitalSubjects)});
    
    if options.verbose.modelcomparison || options.verbose.selectedmodelsanalysis
        disp(' ');
        disp('When assessing whether the high-escitalopram, placebo, and low-escitalopram groups differed in model frequencies:');
        h, p
    end;
end