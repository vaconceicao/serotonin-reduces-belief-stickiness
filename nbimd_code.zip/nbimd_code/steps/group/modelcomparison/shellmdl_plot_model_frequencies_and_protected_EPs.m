function [] = shellmdl_plot_model_frequencies_and_protected_EPs(options, paths, comparisonInfo)
% [] = shellmdl_plot_model_frequencies_and_protected_EPs(options, paths, comparisonInfo)
%
% shellmdl_plot_model_frequencies_and_protected_EPs is a function that
% compares the RL models of interest using the VBA toolbox, by calling
% VBA_groupBMC; then, it plots the corresponding model frequencies and
% protected exceedance probabilities (EPs).
% If comparisonInfo == 'main', it plots Figure 4;
% if comparisonInfo == 'supp', it plots Extended Data Figure 2].
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  VBA_groupBMC
%
% Notes:
%   Some of the text in the Figures was added in Adobe Illustrator
%
% Author: Vasco A. Concei��o
%
% Last modified: April 2024

%% Main code (including figure generation & data saving):
paths = shellmdl_paths(paths, 1);
load(paths.results.group.modelcomparison.tempsession.all.modelEvidencesFile);

if isequal(comparisonInfo, 'main')
    ME_TI_m = modelEvidences(options.rl.mainComparisonModels, :);
elseif isequal(comparisonInfo, 'supp')
    ME_TI_m = modelEvidences;
else
    error('Error: comparisonInfo was misspecified.');
end;

if options.verbose.modelcomparison
    disp(' ');
    disp(['Running shellmdl_plot_model_frequencies_and_protected_EPs using comparisonInfo = ' comparisonInfo '...']);
end;

[posterior, out]    = VBA_groupBMC(ME_TI_m);
modelFrequencies    = posterior.a / sum(posterior.a);
peps                = out.pxp';

if options.verbose.modelcomparison
    disp(' '); disp('The model frequencies were equal to:');
    disp(round(modelFrequencies, 5));
    disp(' '); disp('The protected exceedance probabilities were equal to:');
    disp(round(peps, 5));
end;

outputDir = paths.results.group.modelcomparison.tempsession.all.figuresdir;
if ~exist(outputDir, 'dir')
    mkdir(outputDir);
end;

if isequal(comparisonInfo, 'main')
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    f = figure();
    set(f, 'name', options.figs.fig4A.name, 'units', 'centimeters', 'position', options.figs.fig4A.dimensions, ...
        'paperunits', 'centimeters', 'paperposition', options.figs.fig4A.dimensions);
    hold on;
    
    patch([1 1 10 10],      [0 1 1 0], 'k', 'facecolor', [0.86 0.86 0.86], 'edgecolor', [0.86 0.86 0.86]);
    patch([1 1 10 10] + 9,  [0 1 1 0], 'k', 'facecolor', [0.94 0.94 0.94], 'edgecolor', [0.94 0.94 0.94]);
    
    b = bar(2:9, modelFrequencies(1:8));
    b.FaceColor = 'k';
    b.EdgeColor = 'k';
    
    b = bar(11:18, modelFrequencies(9:16));
    b.FaceColor = 'k';
    b.EdgeColor = 'k';
    
    ylabel(options.figs.fig4A.yLabel, 'fontname', options.figs.fontName, 'fontsize', options.figs.labelFontSize);
    axis(options.figs.fig4A.axis);
    set(gca, 'xtick', options.figs.fig4A.xTick, 'xticklabel', options.figs.fig4A.xTickLabel, ...
        'ytick', options.figs.fig4A.yTick, 'fontname', ...
        options.figs.fontName, 'fontsize', options.figs.fontSize);
    
    if options.save.modelcomparison && options.overwrite.modelcomparison
        if options.verbose.modelcomparison
            disp(' '); disp('Figure 4A was overwritten.');
        end;
        export_fig([outputDir filesep options.figs.fig4A.name], '-r800', '-nocrop', '-tiff', '-transparent');
        print([outputDir filesep options.figs.fig4A.name], '-r800', '-depsc', '-tiff');
        close(f);
    end;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    f = figure();
    set(f, 'name', options.figs.fig4B.name, 'units', 'centimeters', 'position', options.figs.fig4B.dimensions, ...
        'paperunits', 'centimeters', 'paperposition', options.figs.fig4B.dimensions);
    hold on;
    
    patch([1 1 10 10],      [0 1 1 0], 'k', 'facecolor', [0.86 0.86 0.86], 'edgecolor', [0.86 0.86 0.86]);
    patch([1 1 10 10] + 9,  [0 1 1 0], 'k', 'facecolor', [0.94 0.94 0.94], 'edgecolor', [0.94 0.94 0.94]);
    
    b = bar(2:9, peps(1:8));
    b.FaceColor = 'k';
    b.EdgeColor = 'k';
    
    b = bar(11:18, peps(9:16));
    b.FaceColor = 'k';
    b.EdgeColor = 'k';
    
    plot(options.figs.fig4B.axis(1:2), [options.figs.fig4B.yThreshold options.figs.fig4B.yThreshold], options.figs.fig4B.thresholdLine);
    
    ylabel(options.figs.fig4B.yLabel, 'fontname', options.figs.fontName, 'fontsize', options.figs.labelFontSize);
    axis(options.figs.fig4B.axis);
    set(gca, 'xtick', options.figs.fig4B.xTick, 'xticklabel', options.figs.fig4B.xTickLabel, ...
        'ytick', options.figs.fig4B.yTick, 'fontname', ...
        options.figs.fontName, 'fontsize', options.figs.fontSize);
    
    if options.save.modelcomparison && options.overwrite.modelcomparison
        if options.verbose.modelcomparison
            disp(' '); disp('Figure 4B was overwritten.');
        end;
        export_fig([outputDir filesep options.figs.fig4B.name], '-r800', '-nocrop', '-tiff', '-transparent');
        print([outputDir filesep options.figs.fig4B.name], '-r800', '-depsc', '-tiff');
        close(f);
    end;
    
else
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    f = figure();
    set(f, 'name', options.figs.figED2A.name, 'units', 'centimeters', 'position', options.figs.figED2A.dimensions, ...
        'paperunits', 'centimeters', 'paperposition', options.figs.figED2A.dimensions);
    
    reorderedFreq = modelFrequencies([1:8, 17:24, 25:32, 9:16]); % to plot the models in the following order: S-R, S-R_{alpha(T)}, S-R_{StimStick}, and S-S-R
    
    nModels = numel(reorderedFreq);
    
    hold all;
    
    patch([1 1 10 10],        [0 1 1 0], 'k', 'facecolor', [0.86 0.86 0.86], 'edgecolor', [0.86 0.86 0.86]);
    patch([1 1 10 10] + 9,    [0 1 1 0], 'k', 'facecolor', [0.94 0.94 0.94], 'edgecolor', [0.94 0.94 0.94]);
    patch([1 1 10 10] + 18,   [0 1 1 0], 'k', 'facecolor', [0.86 0.86 0.86], 'edgecolor', [0.86 0.86 0.86]);
    patch([1 1 10 10] + 27,   [0 1 1 0], 'k', 'facecolor', [0.94 0.94 0.94], 'edgecolor', [0.94 0.94 0.94]);
    
    b = bar(2:9, reorderedFreq(1:8), 'k');
    b = bar(11:18, reorderedFreq(9:16), 'k');
    b = bar(20:27, reorderedFreq(17:24), 'k');
    b = bar(29:36, reorderedFreq(25:32), 'k');
    
    axis([0.5, nModels + 5.5, 0, 1]);
    
    set(gca, 'ytick', 0:0.2:1, 'xtick', 1:(nModels + 5), 'xticklabel', options.figs.figED2A.xTickLabel, ...
        'XTickLabelRotation', options.figs.figED2A.xTickAngle, 'fontname', 'arial', 'fontsize', 8);
    
    ylabel('Model frequency', 'fontname', 'arial', 'fontsize', 9);
    
    if options.save.modelcomparison && options.overwrite.modelcomparison
        if options.verbose.modelcomparison
            disp(' '); disp('Figure ED2A was overwritten.');
        end;
        export_fig([outputDir filesep options.figs.figED2A.name], '-r800', '-nocrop', '-tiff', '-transparent');
        print([outputDir filesep options.figs.figED2A.name], '-r800', '-depsc', '-tiff');
        close(f);
    end;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    f = figure();
    set(f, 'name', options.figs.figED2B.name, 'units', 'centimeters', 'position', options.figs.figED2B.dimensions, ...
        'paperunits', 'centimeters', 'paperposition', options.figs.figED2B.dimensions);
    
    reorderedPEPs = peps([1:8, 17:24, 25:32, 9:16]); % to plot the models in the following order: S-R, S-R_{alpha(T)}, S-R_{StimStick}, and S-S-R
    
    nModels = numel(reorderedPEPs);
    
    hold all;
    
    patch([1 1 10 10],        [0 1 1 0], 'k', 'facecolor', [0.86 0.86 0.86], 'edgecolor', [0.86 0.86 0.86]);
    patch([1 1 10 10] + 9,    [0 1 1 0], 'k', 'facecolor', [0.94 0.94 0.94], 'edgecolor', [0.94 0.94 0.94]);
    patch([1 1 10 10] + 18,   [0 1 1 0], 'k', 'facecolor', [0.86 0.86 0.86], 'edgecolor', [0.86 0.86 0.86]);
    patch([1 1 10 10] + 27,   [0 1 1 0], 'k', 'facecolor', [0.94 0.94 0.94], 'edgecolor', [0.94 0.94 0.94]);
    
    b = bar(2:9, reorderedPEPs(1:8), 'k');
    b = bar(11:18, reorderedPEPs(9:16), 'k');
    b = bar(20:27, reorderedPEPs(17:24), 'k');
    b = bar(29:36, reorderedPEPs(25:32), 'k');
    
    plot([0.5, nModels + 5.5], [options.figs.figED2B.yThreshold, options.figs.figED2B.yThreshold], options.figs.figED2B.thresholdLine);
    axis([0.5, nModels + 5.5, 0, 1]);
    
    set(gca, 'ytick', 0:0.2:1, 'xtick', 1:(nModels + 5), 'xticklabel', options.figs.figED2B.xTickLabel, ...
        'XTickLabelRotation', options.figs.figED2B.xTickAngle, 'fontname', 'arial', 'fontsize', 8);
    
    ylabel('PEP', 'fontname', 'arial', 'fontsize', 9);
    
    if options.save.modelcomparison && options.overwrite.modelcomparison
        if options.verbose.modelcomparison
            disp(' '); disp('Figure ED2B was overwritten.');
        end;
        export_fig([outputDir filesep options.figs.figED2B.name], '-r800', '-nocrop', '-tiff', '-transparent');
        print([outputDir filesep options.figs.figED2B.name], '-r800', '-depsc', '-tiff');
        close(f);
    end;
end;

end

