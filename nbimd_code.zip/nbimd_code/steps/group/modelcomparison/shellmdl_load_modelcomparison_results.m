function [] = shellmdl_load_modelcomparison_results(options, paths)
% [] = shellmdl_load_modelcomparison_results(options, paths)
%
% shellmdl_load_modelcomparison_results is a function called by
% shellmdl_master, which copies the previously obtained results from
% paths.previousresultsdir (the folder where those files should be stored)
% into paths.resultsdir (the new results folder). In doing so, this
% function generates (or overwrites) the results (that would be) obtained
% by running the model-comparison pipeline, allowing to minimize
% computation time. To run this function, instead of the full
% model-comparison pipeline, options.load.modelcomparison and
% options.run.modelcomparison should be set to 1 and 0, respectively, in
% shellmdl_set_analysis_options.
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  shellmdl_paths
%
% Author: Vasco A. Concei��o
%
% Last modified: April 2024

%% Settings
prDir = [paths.previousresultsdir filesep 'modelcomparison'];               % previous results folder

prDir_all       = [prDir filesep 'all'];
prDir_all_figs  = [prDir_all filesep 'figures'];

%% Main Code - Initialization
if ~exist(prDir, 'dir')
    mkdir(prDir);
end;
if ~exist(prDir_all, 'dir')
    mkdir(prDir_all);
end;
if ~exist(prDir_all_figs, 'dir')
    mkdir(prDir_all_figs);
end;

if options.verbose.modelcomparison
    disp(' ');
    disp('--------------------------------------------------------------');
    disp('Running shellmdl_load_modelcomparison_results...');
end;

%% Main Code - Copy the output files from shellmdl_calculate_difference_in_log_model_evidences
paths   = shellmdl_paths(paths, 1);

rDir    = paths.results.group.modelcomparison.tempsession.alldir;               % results folder
rFile   = paths.results.group.modelcomparison.tempsession.all.deltaLogMEfile;   % results file 1
% copyfile(rFile, prDir_all); % this line is commented intentionally; it was ran to obtain the previous results files

prFile  = [prDir_all filesep 'deltaLogME.mat'];
if ~exist(rDir, 'dir')
    mkdir(rDir);
end;
copyfile(prFile, rDir);

%% Main Code - Copy the output files from shellmdl_plot_model_frequencies_and_protected_EPs
rDir = paths.results.group.modelcomparison.tempsession.all.figuresdir;

rFig11 = [rDir filesep options.figs.fig4A.name '.tif'];
rFig12 = [rDir filesep options.figs.fig4A.name '.eps'];
rFig21 = [rDir filesep options.figs.fig4B.name '.tif'];
rFig22 = [rDir filesep options.figs.fig4B.name '.eps'];
rFig31 = [rDir filesep options.figs.figED2A.name '.tif'];
rFig32 = [rDir filesep options.figs.figED2A.name '.eps'];
rFig41 = [rDir filesep options.figs.figED2B.name '.tif'];
rFig42 = [rDir filesep options.figs.figED2B.name '.eps'];

% copyfile(rFig11, prDir_all_figs); % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFig12, prDir_all_figs); % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFig21, prDir_all_figs); % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFig22, prDir_all_figs); % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFig31, prDir_all_figs); % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFig32, prDir_all_figs); % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFig41, prDir_all_figs); % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFig42, prDir_all_figs); % this line is commented intentionally; it was ran to obtain the previous results files

prFig11 = [prDir_all_figs filesep options.figs.fig4A.name '.tif'];
prFig12 = [prDir_all_figs filesep options.figs.fig4A.name '.eps'];
prFig21 = [prDir_all_figs filesep options.figs.fig4B.name '.tif'];
prFig22 = [prDir_all_figs filesep options.figs.fig4B.name '.eps'];
prFig31 = [prDir_all_figs filesep options.figs.figED2A.name '.tif'];
prFig32 = [prDir_all_figs filesep options.figs.figED2A.name '.eps'];
prFig41 = [prDir_all_figs filesep options.figs.figED2B.name '.tif'];
prFig42 = [prDir_all_figs filesep options.figs.figED2B.name '.eps'];

if ~exist(rDir, 'dir')
    mkdir(rDir);
end;

copyfile(prFig11, rDir);
copyfile(prFig12, rDir);
copyfile(prFig21, rDir);
copyfile(prFig22, rDir);
copyfile(prFig31, rDir);
copyfile(prFig32, rDir);
copyfile(prFig41, rDir);
copyfile(prFig42, rDir);

end