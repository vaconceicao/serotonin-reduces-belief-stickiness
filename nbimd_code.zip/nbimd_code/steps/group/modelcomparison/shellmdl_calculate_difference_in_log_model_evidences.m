function [deltaLogME] = shellmdl_calculate_difference_in_log_model_evidences(options, paths)
% [] = shellmdl_calculate_difference_in_log_model_evidences(options, paths)
%
% shellmdl_calculate_difference_in_log_model_evidences is a function that 
% calculates the difference in log model evidence between the selected 
% model and its nested SR equivalent.
%
% Called in: 
%  shellmdl_master
%
% List of key auxiliary functions:
%  [none]
%
% Author: Vasco A. Concei��o
%
% Last modified: September 2023

%% Settings:
paths = shellmdl_paths(paths, 1);
load(paths.results.group.modelcomparison.tempsession.all.modelEvidencesFile);

%% Main Code:
if options.verbose.modelcomparison
    disp(' '); 
    disp('Running shellmdl_calculate_difference_in_log_model_evidences...');
end;

deltaLogME = (modelEvidences(options.rl.selectedModel, :) - modelEvidences(options.rl.nestedSRModel, :))';

if options.save.modelcomparison && options.overwrite.modelcomparison
    save(paths.results.group.modelcomparison.tempsession.all.deltaLogMEfile, 'deltaLogME');
end;

end