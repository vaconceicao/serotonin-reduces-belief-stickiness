function [] = shellmdl_load_modelfitting_results(options, paths)
% [] = shellmdl_load_modelfitting_results(options, paths)
%
% shellmdl_load_modelfitting_results is a function called by
% shellmdl_master, which copies the previously obtained results from
% paths.previousresultsdir (the folder where those files should be stored)
% into paths.resultsdir (the new results folder). In doing so, this
% function generates (or overwrites) the results (that would be) obtained
% by running the model-fitting pipeline, allowing to minimize computation
% time. To run this function, instead of the full model-fitting pipeline,
% options.load.modelfitting and options.run.modelfitting should be set to 1
% and 0, respectively, in shellmdl_set_analysis_options.
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  shellmdl_paths
%
% Author: Vasco A. Concei��o
%
% Last modified: November 2023

%% Settings
prDir = [paths.previousresultsdir filesep 'modelfitting'];                      % previous results folder
prDir_individ_model = [prDir filesep 'individ_model'];

%% Main Code - Initialization
if ~exist(prDir, 'dir')
    mkdir(prDir);
end;
if ~exist(prDir_individ_model, 'dir')
    mkdir(prDir_individ_model);
end;

if options.verbose.modelfitting
    disp(' ');
    disp('--------------------------------------------------------------');
    disp('Running shellmdl_load_modelfitting_results...');
end;

%% Main Code - Copy the output files from shellmdl_loop_subj_invert_model
for iProcedure = 1:options.mcmc.nProcedures
    
    if options.verbose.modelfitting
        if iProcedure < options.mcmc.nProcedures
            disp(['... for ' options.mcmc.fileNames{options.mcmc.procedures(iProcedure)} options.mcmc.modelNames{iProcedure} ';']);
        else
            disp(['... for ' options.mcmc.fileNames{options.mcmc.procedures(iProcedure)} options.mcmc.modelNames{iProcedure} '.']);
        end;
    end;
    
    prDir_individ_model_spec = [prDir_individ_model filesep options.mcmc.modelNames{iProcedure}];                                           % previous results folder
    if ~exist(prDir_individ_model_spec, 'dir')
        mkdir(prDir_individ_model_spec);
    end;
    
    for iSubject = 1:options.dataset.nEffSubjects
        subject = options.dataset.subjects(iSubject);
        paths = shellmdl_paths(paths, 1, subject, options.mcmc.iModelNumbers(iProcedure), options);
        
        rDir    = getfield(paths.results.subjects.tempsubject.models.tempsession.tempmodel, 'modelfitdir');                                 % results folder
        rFile   = [rDir filesep options.mcmc.fileNames{options.mcmc.procedures(iProcedure)} num2str(subject) '.mat'];                       % results file
        % copyfile(rFile, prDir_individ_model_spec); % this line is commented intentionally; it was ran to obtain the previous results files
        
        prFile  = [prDir_individ_model_spec filesep options.mcmc.fileNames{options.mcmc.procedures(iProcedure)} num2str(subject) '.mat']; 	% previous results file
        if ~exist(rDir, 'dir')
            mkdir(rDir);
        end;
        copyfile(prFile, rDir);
    end;
end;

end