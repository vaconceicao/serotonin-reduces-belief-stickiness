function [] = shellmdl_plot_fitted_p_go_per_season(options, paths)
% [] = shellmdl_plot_fitted_p_go_per_season(options, paths)
%
% shellmdl_plot_fitted_p_go_per_season is a function that creates Figure 
% 6A and Extended Data Figure 1A of the paper, based on the output from:
% - shellmdl_predict_group_behavior;
% - shellmdl_calc_p_go_per_season.
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  [none]
%
% Author: Vasco A. Concei��o
%
% Last modified: April 2024

%% Settings
outputDir   = paths.results.group.modelinspection.tempsession.all.figuresdir;
load(paths.results.group.behavior.tempsession.all.pgofigurefile);

%% Main Code
if options.verbose.selectedmodelsanalysis
    disp(' ');
    disp('Running shellmdl_plot_fitted_p_go_per_season...');
end;

for iFigure = 1:options.figs.fig6A.nPanels
    f = figure();
    switch iFigure
        case {1, 3} % in iFigure 3 (the one used in the article), the model-based data is shown together with the raw one; in iFigure 1, it is not
            load(paths.results.group.modelinspection.tempsession.all.predictedMeanPGoFile);
            set(f, 'name', options.figs.fig6A.name, 'units', 'centimeters', 'position', options.figs.fig6A.dimensions + [0 0 2 0]*(iFigure == 3), ...
                'paperunits', 'centimeters', 'paperposition', options.figs.fig6A.dimensions + [0 0 2 0]*(iFigure == 3));
        case {2, 4} % in iFigure 4 (the one used in the article), the model-based data is shown together with the raw one; in iFigure 2, it is not
            load(paths.results.group.modelinspection.tempsession.all.predictedMeanPGoSuppFile);
            set(f, 'name', options.figs.figED1A.name, 'units', 'centimeters', 'position', options.figs.fig6A.dimensions + [0 0 2 0]*(iFigure == 4), ...
                'paperunits', 'centimeters', 'paperposition', options.figs.fig6A.dimensions + [0 0 2 0]*(iFigure == 4));
    end;
    
    p_go_by_season = -Inf * ones(options.dataset.nSeasons, options.dataset.nEffSubjects);
    for iSubj = 1:options.dataset.nEffSubjects
        p_go_by_season(1, iSubj) = predictedGoPerSeason(1, iSubj);
        p_go_by_season(2, iSubj) = predictedGoPerSeason(2, iSubj);
        p_go_by_season(3, iSubj) = predictedGoPerSeason(3, iSubj);
    end;
    
    auxData = mean(p_go_by_season, 2);
    
    auxData2 = p_go_by_season;                                  
    sem = std(auxData2, 0, 2);                                  % in auxData2, dimension 2 refers to subjects
    sem = sem / sqrt(options.dataset.nEffSubjects);             % calculate the standard error of the mean
    
    hold on;
    
    if iFigure <= 2 % to show the model-based data only (not in the article)
        for iSeason = 1:options.dataset.nSeasons
            b = bar(iSeason:options.dataset.nSeasons, auxData(iSeason:end));
            b.FaceColor = options.figs.fig6A.modelSeasonColors(iSeason, :);
            
            % plot error bars:
            plot([iSeason, iSeason], auxData(iSeason) + [sem(iSeason), -sem(iSeason)], '-k');
        end;
        
    else % to show the combined raw and model-based data (in the article)
        for iSeason = 1:options.dataset.nSeasons
            % plot raw data %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            b = bar((iSeason:options.dataset.nSeasons) - 0.18, MF_panel_A_data.mean(iSeason:end), 0.3);
            b.FaceColor = options.figs.fig6A.seasonColors(iSeason, :);
            % b.barWidth  = 0.3;
            
            % show individual datapoints:
            for iSubj = 1:options.dataset.nEffSubjects
                plot(iSeason - 0.32 + 0.28 * (iSubj - 1) / (options.dataset.nEffSubjects - 1), MF_panel_A_data.all(iSeason, iSubj), ...
                    'o', 'markerfacecolor', options.figs.fig6A.seasonColors(iSeason, :) * 0.75, 'markeredgecolor', options.figs.fig6A.markerColor, ...
                    'markersize', options.figs.fig6A.markerSize, 'linewidth', 0.1);
            end;
            
            % plot error bars:
            plot([iSeason, iSeason] - 0.18, MF_panel_A_data.mean(iSeason) + [MF_panel_A_data.sem(iSeason), -MF_panel_A_data.sem(iSeason)], '-k', 'linewidth', 2);
            
            % plot model-based data %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            b = bar((iSeason:options.dataset.nSeasons) + 0.18, auxData(iSeason:end), 0.3);
            b.FaceColor = options.figs.fig6A.modelSeasonColors(iSeason, :);
            % b.barWidth  = 0.3;
            
            % show individual datapoints:
            for iSubj = 1:options.dataset.nEffSubjects
                plot(iSeason + 0.04 + 0.28 * (iSubj - 1) / (options.dataset.nEffSubjects - 1), predictedGoPerSeason(iSeason, iSubj), ...
                    'o', 'markerfacecolor', options.figs.fig6A.modelSeasonColors(iSeason, :), 'markeredgecolor', options.figs.fig6A.markerColor, ...
                    'markersize', options.figs.fig6A.markerSize, 'linewidth', 0.1);
            end;
            
            % plot error bars:
            plot([iSeason, iSeason] + 0.18, auxData(iSeason) + [sem(iSeason), -sem(iSeason)], '-k', 'linewidth', 2);
        end;
        
        % plot significance from repeated contrasts:
        significance_string = '***';                    % for all cases; this was calculated in Jamovi
        plot([1 - 0.18, 2 - 0.18], [0.98 0.98] + 0.17, '-k');
        plot([1 + 0.18, 2 + 0.18], [0.93 0.93] + 0.17, '-k');
        text(1.5 - 0.18, 0.985 + 0.17, significance_string, 'fontname', options.figs.fontName, 'fontSize', options.figs.labelFontSize - 1, ...
            'horizontalalignment', 'center', 'verticalalignment', 'middle');
        text(1.5 + 0.18, 0.935 + 0.17, significance_string, 'fontname', options.figs.fontName, 'fontSize', options.figs.labelFontSize - 1, ...
            'horizontalalignment', 'center', 'verticalalignment', 'middle');
        plot([2 - 0.18, 3 - 0.18], [0.83 0.83] + 0.17, '-k');
        plot([2 + 0.18, 3 + 0.18], [0.78 0.78] + 0.17, '-k');
        text(2.5 - 0.18, 0.835 + 0.17, significance_string, 'fontname', options.figs.fontName, 'fontSize', options.figs.labelFontSize - 1, ...
            'horizontalalignment', 'center', 'verticalalignment', 'middle');
        text(2.5 + 0.18, 0.785 + 0.17, significance_string, 'fontname', options.figs.fontName, 'fontSize', options.figs.labelFontSize - 1, ...
            'horizontalalignment', 'center', 'verticalalignment', 'middle');
    end;
    
    set(gca, 'xtick', options.figs.fig6A.xTick, 'xticklabel', options.figs.fig6A.xTickLabel, ...
        'ytick', options.figs.fig6A.yTick, ...
        'fontname', options.figs.fontName, 'fontsize', options.figs.fontSize);
    axis(options.figs.fig6A.axis);
    xlabel(options.figs.fig6A.xLabel, 'fontname', options.figs.fontName, 'fontsize', options.figs.labelFontSize);
    ylabel([options.figs.fig6A.yLabel '       '], 'fontname', options.figs.fontName, 'fontsize', options.figs.labelFontSize);
    
    % Save:
    if options.save.selectedmodelsanalysis && options.overwrite.selectedmodelsanalysis
        
        MB_panel_A_data.mean    = auxData;
        MB_panel_A_data.sem     = sem;
        
        if ~exist(outputDir, 'dir')
            mkdir(outputDir);
        end;
        switch iFigure
            case 1
                if options.verbose.selectedmodelsanalysis
                    % disp('Figure 6A_not_used was overwritten.');
                end;
                export_fig([outputDir filesep options.figs.fig6A.name ' - not_used'], '-tiff', ['-r' num2str(options.figs.res)], '-transparent'); % , '-nocrop'
                print([outputDir filesep options.figs.fig6A.name ' - not_used'], '-r800', '-depsc', '-tiff');
            case 2
                if options.verbose.selectedmodelsanalysis
                    % disp('Figure ED1A_not_used was overwritten.');
                end;
                export_fig([outputDir filesep options.figs.figED1A.name ' - not_used'], '-tiff', ['-r' num2str(options.figs.res)], '-transparent'); % , '-nocrop'
                print([outputDir filesep options.figs.figED1A.name ' - not_used'], '-r800', '-depsc', '-tiff');
            case 3
                if options.verbose.selectedmodelsanalysis
                    disp('Figure 6A was overwritten.');
                end;
                export_fig([outputDir filesep options.figs.fig6A.name], '-tiff', ['-r' num2str(options.figs.res)], '-transparent'); % , '-nocrop'
                print([outputDir filesep options.figs.fig6A.name], '-r800', '-depsc', '-tiff');
            case 4
                if options.verbose.selectedmodelsanalysis
                    disp('Figure ED1A was overwritten.');
                end;
                export_fig([outputDir filesep options.figs.figED1A.name], '-tiff', ['-r' num2str(options.figs.res)], '-transparent'); % , '-nocrop'
                print([outputDir filesep options.figs.figED1A.name], '-r800', '-depsc', '-tiff');
        end;
        close(f);
    end;
end;
