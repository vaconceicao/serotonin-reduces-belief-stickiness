function [] = shellmdl_plot_predicted_group_behavior(options, paths)
% [] = shellmdl_plot_predicted_group_behavior(options, paths)
%
% shellmdl_plot_predicted_group_behavior is the function that creates
% Figure 6B and Extended Data Figure 1B of the paper.
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  [none]
%
% Author: Vasco A. Concei��o
%
% Last modified: April 2024

%% Init
modelNumbers    = options.selectedmodelsanalysis.iModelNumbers;
nFigures        = numel(modelNumbers);

outputDir = paths.results.group.modelinspection.tempsession.all.figuresdir;

% To plot the acquired data too:
load(paths.results.group.behavior.tempsession.all.procfile);
p_go_by_stim_by_phase_t = all_behav_data.p_go_by_stim_by_phase_t;

%% Main Code
if options.verbose.selectedmodelsanalysis
    disp(' ');
    disp('Running shellmdl_plot_predicted_group_behavior...');
end;

for iFigure = 1:nFigures
    f = figure();
    paths = shellmdl_paths(paths, 1);
    if iFigure == 1
        load(paths.results.group.modelinspection.tempsession.all.predictedMeanPGoSuppFile);
        set(f, 'name', options.figs.figED1B.name, 'units', 'centimeters', 'position', options.figs.fig6B.dimensions, ...
            'paperunits', 'centimeters', 'paperposition', options.figs.fig6B.dimensions);
    elseif iFigure == 2
        load(paths.results.group.modelinspection.tempsession.all.predictedMeanPGoFile);
        set(f, 'name', options.figs.fig6B.name, 'units', 'centimeters', 'position', options.figs.fig6B.dimensions, ...
            'paperunits', 'centimeters', 'paperposition', options.figs.fig6B.dimensions);
    end;
    
    for iStim = 1:options.dataset.nStim
        sp = options.figs.shellSubPlots(iStim);
        subplot(2, options.dataset.nStim/2, sp);
        hold on;
        
        % draw seasons as line segments:
        for iPhase = 1:options.dataset.nPhases
            season = options.dataset.state2seasons(iStim, iPhase);
            plot(options.figs.fig6B.seasonXPositions(iPhase, :), ...
                repmat(options.figs.fig6B.seasonYPositions(season), 1, 2), ...
                'color', options.figs.seasonColors(season, :), ...
                'linewidth', options.figs.fig6B.seasonLineWidth);
        end;
        
        % To plot acquired data:
        auxData_acq     = mean(p_go_by_stim_by_phase_t(:, iStim, :), 1);
        auxData_acq     = reshape(auxData_acq, 1, options.dataset.nPhases);
        
        sem_acq     = std(p_go_by_stim_by_phase_t(:, iStim, :), 0, 1); % dimension 1 refers to subjects
        sem_acq     = reshape(sem_acq, 1, options.dataset.nPhases);
        sem_acq     = sem_acq / sqrt(options.dataset.nEffSubjects); % calculate the standard error of the mean
        
        plot(1:options.dataset.nPhases, auxData_acq, options.figs.fig6B.auxLine, ...
            'color', options.figs.fig6B.auxLineColor, 'linewidth', options.figs.fig6B.auxLineWidth);
        
        % plot error bars:
        for iPhase = 1:options.dataset.nPhases
            plot([iPhase iPhase], auxData_acq(iPhase) + [sem_acq(iPhase), - sem_acq(iPhase)], options.figs.fig6B.auxLine, ...
                'color', options.figs.fig6B.auxLineColor, 'linewidth', max(1, options.figs.fig6B.auxLineWidth));
        end;
        
        % to plot model fits:
        auxData = mean(predictedGoPerPhase(iStim, :, :), 3);
        sem = std(predictedGoPerPhase(iStim, :, :), 0, 3);  % dimension 3 refers to subjects
        sem = sem / sqrt(options.dataset.nEffSubjects);     % calculate the standard error of the mean
        
        MB_panel_B_data.mean_per_shell_per_phase{iStim}     = auxData;
        MB_panel_B_data.sem_per_shell_per_phase{iStim}      = sem;
        
        plot(1:options.dataset.nPhases, auxData, options.figs.fig6B.line, ...
            'color', options.figs.fig6B.lineColor, 'linewidth', options.figs.fig6B.lineWidth);
        
        % plot error bars:
        for iPhase = 1:options.dataset.nPhases
            plot([iPhase iPhase], auxData(iPhase) + [sem(iPhase), - sem(iPhase)], options.figs.fig6B.line, ...
                'color', options.figs.fig6B.lineColor, 'linewidth', max(1, options.figs.fig6B.lineWidth));
        end;
        
        % configure the subplots according to the predefined options:
        set(gca, 'xtick', options.figs.fig6B.xTick, 'ytick', options.figs.fig6B.yTick, ...
            'fontname', options.figs.fontName, 'fontsize', options.figs.fontSize);
        if sp > options.dataset.nStim/2
            xlabel(options.figs.fig6B.xLabel, 'fontname', options.figs.fontName, 'fontsize', options.figs.labelFontSize);
        end;
        if ismember(sp, [1, options.dataset.nStim/2 + 1])
            ylabel(options.figs.fig6B.yLabel, 'fontname', options.figs.fontName, 'fontsize', options.figs.labelFontSize);
        end;
        title(options.dataset.stimNames{iStim}, 'fontName', options.figs.fontName, 'fontSize', options.figs.titleFontSize - 1);
        axis(options.figs.fig6B.axis);
    end;
    
    % Save:
    if options.save.selectedmodelsanalysis && options.overwrite.selectedmodelsanalysis
        if ~exist(outputDir, 'dir')
            mkdir(outputDir);
        end;
        if iFigure == 1
            if options.verbose.selectedmodelsanalysis
                disp('Figure ED1B was overwritten.');
            end;
            export_fig([outputDir filesep options.figs.figED1B.name], '-tiff', ['-r' num2str(options.figs.res)], '-transparent'); % , '-nocrop'
            print([outputDir filesep options.figs.figED1B.name], '-r800', '-depsc', '-tiff');
        elseif iFigure == 2
            if options.verbose.selectedmodelsanalysis
                disp('Figure 6B was overwritten.');
            end;
            export_fig([outputDir filesep options.figs.fig6B.name], '-tiff', ['-r' num2str(options.figs.res)], '-transparent'); % , '-nocrop'
            print([outputDir filesep options.figs.fig6B.name], '-r800', '-depsc', '-tiff');
        end;
        close(f);
    end;
end;
end