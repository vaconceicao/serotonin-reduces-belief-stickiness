function [] = shellmdl_predict_group_behavior(options, paths)
% [] = shellmdl_predict_group_behavior(options, paths)
%
% shellmdl_predict_group_behavior is a function that should be used to 
% calculate the average model predictions per shell phase and season. It 
% creates several output files, including a file that is needed for data 
% analysis in Jamovi (Figure 6A and Extended Data Figure 1A).
% It requires that shellmdl_loop_predict_subj_behavior is previously ran.
% Unless shellmdl_set_analysis_options is changed, the prediction is made
% both for the selected model (S-S-R-8) and its nested S-R equivalent 
% (S-R-8).
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  [none]
%
% Author: Vasco A. Concei��o
%
% Last modified: September 2023

%% Init
modelNumbers    = options.selectedmodelsanalysis.iModelNumbers;
nFigures        = numel(modelNumbers);

soi             = options.dataset.subjects;
nEffSubj        = numel(soi);

nStims          = options.dataset.nStim;
nPhases         = options.dataset.nPhases;
nTrials         = options.dataset.nTrials;

nSeasons        = options.dataset.nSeasons;

load([paths.results.group.behavior2modeldir filesep 'stim_m']);
load([paths.results.group.behavior2modeldir filesep 'states_m']);
load([paths.results.group.behavior2modeldir filesep 'phases_m']);

outputDirJamovi         = paths.results.group.modelinspection.tempsession.all.pgojamovidir;

pgoDataForJamovi1       = -Inf * ones(options.dataset.nEffSubjects * options.dataset.nSeasons, 3); % subject, season, p(go) on each season for the first model
pgoDataForJamovi1File   = paths.results.group.modelinspection.tempsession.all.pgojamovi1file;

pgoDataForJamovi2       = -Inf * ones(options.dataset.nEffSubjects * options.dataset.nSeasons, 3); % subject, season, p(go) on each season for the second model
pgoDataForJamovi2File   = paths.results.group.modelinspection.tempsession.all.pgojamovi2file;

%% Main Code
if options.verbose.selectedmodelsanalysis
    disp(' ');
    disp('Running shellmdl_predict_group_behavior_per_phase...');
end;

predictedGoPerPhase     = -Inf * ones(nStims, nPhases, nEffSubj);   % will store the mean predicted p(go) in each shell phase for all subjects
predictedGoPerSeason    = -Inf * ones(nSeasons, nEffSubj);          % will store the mean predicted p(go) in each season for all subjects

predictedCorrPerPhase   = -Inf * ones(nPhases, nEffSubj);           % will store the predicted p(correct) in each phase for all subjects

for iFigure = 1:nFigures
    modelNumber = modelNumbers(iFigure);
    for s = 1:nEffSubj
        subj = options.dataset.subjects(s);
        
        paths = shellmdl_paths(paths, 1, subj, modelNumber, options);
        load(paths.results.subjects.tempsubject.models.tempsession.tempmodel.predictedModelVariablesfile);
        
        predictedGoPerPhase_aux     = cell(nStims, nPhases);
        for iStim = 1:nStims
            for iPhase = 1:nPhases
                predictedGoPerPhase_aux{iStim, iPhase} = [];
            end;
        end;
        
        predictedGoPerSeason_aux    = cell(nSeasons, 1);
        for iSeason = 1:nSeasons
            predictedGoPerSeason_aux{iSeason, 1} = [];
        end;
        
        predictedCorrPerPhase_aux     = cell(nPhases, 1);
        for iPhase = 1:nPhases
            predictedCorrPerPhase_aux{iPhase, 1} = [];
        end;
        
        for iTrial = 1:nTrials
            predictedGoPerPhase_aux{stim_m(subj, iTrial), phases_m(subj, iTrial)} = [predictedGoPerPhase_aux{stim_m(subj, iTrial), phases_m(subj, iTrial)}; prob_v(iTrial)];
            
            season_aux      = options.dataset.state2seasons(stim_m(subj, iTrial), phases_m(subj, iTrial));
            predictedGoPerSeason_aux{season_aux, 1} = [predictedGoPerSeason_aux{season_aux, 1}; prob_v(iTrial)];
            
            corrAnswer_aux  = options.dataset.state2correctaction(stim_m(subj, iTrial), phases_m(subj, iTrial));
            if corrAnswer_aux == 1      % Go
                prob_aux = prob_v(iTrial);
                predictedCorrPerPhase_aux{phases_m(subj, iTrial), 1} = [predictedCorrPerPhase_aux{phases_m(subj, iTrial), 1}; prob_aux];
            elseif corrAnswer_aux == 2  % NoGo
                prob_aux = 1 - prob_v(iTrial);
                predictedCorrPerPhase_aux{phases_m(subj, iTrial), 1} = [predictedCorrPerPhase_aux{phases_m(subj, iTrial), 1}; prob_aux];
            end;
        end;
        
        for iStim = 1:nStims
            for iPhase = 1:nPhases
                predictedGoPerPhase(iStim, iPhase, s) = mean(predictedGoPerPhase_aux{iStim, iPhase});
            end;
        end;
        
        for iSeason = 1:nSeasons
            predictedGoPerSeason(iSeason, s) = mean(predictedGoPerSeason_aux{iSeason, 1});
        end;
        
        for iPhase = 1:nPhases
            predictedCorrPerPhase(iPhase, s) = mean(predictedCorrPerPhase_aux{iPhase, 1});
        end;  
    end;
    
    if iFigure == 1
        pgoDataForJamovi1(:, 1) = repmat(options.dataset.subjects', options.dataset.nSeasons, 1);
        pgoDataForJamovi1(:, 2) = [ones(options.dataset.nEffSubjects, 1); 2 * ones(options.dataset.nEffSubjects, 1); 3 * ones(options.dataset.nEffSubjects, 1)];
        t_predictedGoPerSeason  = predictedGoPerSeason';
        pgoDataForJamovi1(:, 3) = t_predictedGoPerSeason(:);    % [p(go) on R seasons for all subjects; p(go) on N seasons for all subjects; p(go) on P seasons for all subjects]
    elseif iFigure == 2
        pgoDataForJamovi2(:, 1) = repmat(options.dataset.subjects', options.dataset.nSeasons, 1);
        pgoDataForJamovi2(:, 2) = [ones(options.dataset.nEffSubjects, 1); 2 * ones(options.dataset.nEffSubjects, 1); 3 * ones(options.dataset.nEffSubjects, 1)];
        t_predictedGoPerSeason  = predictedGoPerSeason';
        pgoDataForJamovi2(:, 3) = t_predictedGoPerSeason(:);    % [p(go) on R seasons for all subjects; p(go) on N seasons for all subjects; p(go) on P seasons for all subjects]
    end;
    
    if options.save.selectedmodelsanalysis && options.overwrite.selectedmodelsanalysis
        if options.verbose.selectedmodelsanalysis
            disp(['The results from shellmdl_predict_group_behavior_per_phase for model ' options.rl.modelNames{modelNumber} ' were overwritten.']);
        end;
        outputDir = paths.results.group.modelinspection.tempsession.alldir;
        if ~exist(outputDir, 'dir')
            mkdir(outputDir);
        end;
        if ~exist(outputDirJamovi, 'dir')
            mkdir(outputDirJamovi);
        end;
        if iFigure == 1         % SR8, the nested equivalent of the selected model
            save(paths.results.group.modelinspection.tempsession.all.predictedMeanPGoSuppFile, ...
                'predictedGoPerPhase', 'predictedGoPerSeason', 'predictedCorrPerPhase');
            xlswrite(pgoDataForJamovi1File, pgoDataForJamovi1);
        elseif iFigure == 2     % SSR8, the selected model
            save(paths.results.group.modelinspection.tempsession.all.predictedMeanPGoFile, ...
                'predictedGoPerPhase', 'predictedGoPerSeason', 'predictedCorrPerPhase');
            xlswrite(pgoDataForJamovi2File, pgoDataForJamovi2);
        end;
    end;
end;
end

