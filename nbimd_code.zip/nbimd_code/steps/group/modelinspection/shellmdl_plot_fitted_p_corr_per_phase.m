function [] = shellmdl_plot_fitted_p_corr_per_phase(options, paths)
% [] = shellmdl_plot_fitted_p_corr_per_phase(options, paths)
%
% shellmdl_plot_fitted_p_corr_per_phase is the function that creates 
% Figures 5C and Extended Data Figure 1C of the paper, based on the output 
% from:
% - shellmdl_predict_group_behavior;
% - shellmdl_calc_p_corr_per_phase.
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions
%  [none]
%
% Author: Vasco A. Concei��o
%
% Last modified: September 2023

%% Settings
outputDir = paths.results.group.modelinspection.tempsession.all.figuresdir;
load(paths.results.group.behavior.tempsession.all.pcorrfigurefile);

%% Main Code
if options.verbose.selectedmodelsanalysis
    disp(' ');
    disp('Running shellmdl_plot_fitted_p_corr_per_phase...');
end;

for iFigure = 1:options.figs.fig5C.nPanels
    switch iFigure
        case {1, 3} % in figure 3 (the one used in the article), the model-based data is shown together with the raw one; in figure 1, it is not
            load(paths.results.group.modelinspection.tempsession.all.predictedMeanPGoFile);
            f = figure();
            set(f, 'name', options.figs.fig5C.name, 'units', 'centimeters', 'position', options.figs.fig5C.dimensions + [0 0 2 0]*(iFigure == 3), ...
                'paperunits', 'centimeters', 'paperposition', options.figs.fig5C.dimensions + [0 0 2 0]*(iFigure == 3));
        case {2, 4} % in figure 4 (the one used in the article), the model-based data is shown together with the raw one; in figure 2, it is not
            load(paths.results.group.modelinspection.tempsession.all.predictedMeanPGoSuppFile);
            f = figure();
            set(f, 'name', options.figs.fig5C_Supp.name, 'units', 'centimeters', 'position', options.figs.fig5C.dimensions + [0 0 2 0]*(iFigure == 4), ...
                'paperunits', 'centimeters', 'paperposition', options.figs.fig5C.dimensions + [0 0 2 0]*(iFigure == 4));
    end;
    
    p_corr_by_phase = -Inf * ones(options.dataset.nPhases, options.dataset.nEffSubjects);
    for iSubj = 1:options.dataset.nEffSubjects
        p_corr_by_phase(1, iSubj) = predictedCorrPerPhase(1, iSubj);
        p_corr_by_phase(2, iSubj) = predictedCorrPerPhase(2, iSubj);
        p_corr_by_phase(3, iSubj) = predictedCorrPerPhase(3, iSubj);
        p_corr_by_phase(4, iSubj) = predictedCorrPerPhase(4, iSubj);
    end;
    
    auxData = mean(p_corr_by_phase, 2);
    
    auxData2 = p_corr_by_phase';
    sem = std(auxData2, 0, 1);                                  % in auxData2, which was created from transposed p_corr_by_phase, dimension 1 refers to subjects
    sem = sem / sqrt(options.dataset.nEffSubjects);             % calculate the standard error of the mean

    [h_ttest_24, p_ttest_24, ci_ttest_24, stats_ttest_24] = ttest(auxData2(:, 4), auxData2(:, 2)); 	% yields 0.01 < p < 0.05
    
    if options.verbose.selectedmodelsanalysis
        if iFigure > 2
            disp(' ');
            if iFigure == 3
                disp('When using model S-S-R-8...');
            else
                disp('When using model S-R-8...');
            end;
            disp(['The mean p(corr) in phase 2 was ' num2str(round(mean(auxData2(:, 2)), 2)) ' and the corresponding std was ' num2str(round(std(auxData2(:, 2)), 2))]);
            disp(['The mean p(corr) in phase 4 was ' num2str(round(mean(auxData2(:, 4)), 2)) ' and the corresponding std was ' num2str(round(std(auxData2(:, 4)), 2))]);
            disp(['The mean difference in p(corr) from phase 2 to 4 was ' num2str(round(mean(auxData2(:, 4)) - mean(auxData2(:, 2)), 2))]);
            disp(['The p-value for the corresponding one-sample t-test was: ' num2str(round(p_ttest_24, 3))]);
            disp(['The Cohen''s'' d for the corresponding one-sample t-test was: ' num2str(round((mean(auxData2(:, 4)) - mean(auxData2(:, 2))) / stats_ttest_24.sd, 2))]);
            disp(' ');
            disp('Regarding the respective t-statistic and confidence interval:');
            stats_ttest_24
            ci_ttest_24
        end;
    end;

    hold on;
    
    if iFigure <= 2
        b = bar(1, auxData(2)); % x_axis is divided by 2
        b.FaceColor = options.figs.fig5C.barColors(1, :);
        b = bar(2, auxData(4)); % x_axis is divided by 2
        b.FaceColor = options.figs.fig5C.barColors(2, :);
        
        % plot error bars:
        for iPhase = 2:2:4
            plot([iPhase, iPhase]/2, auxData(iPhase) + [sem(iPhase), -sem(iPhase)], '-k'); % x_axis is divided by 2
        end;
        
    else
        % plot raw data:
        b = bar(1 - 0.15, MF_panel_C_data.mean(2), 0.3); % x_axis is divided by 2
        b.FaceColor = options.figs.fig5C.auxBarColors(1, :);
        b = bar(2 - 0.15, MF_panel_C_data.mean(4), 0.3); % x_axis is divided by 2
        b.FaceColor = options.figs.fig5C.auxBarColors(2, :);
        
        % plot error bars:
        for iPhase = 2:2:4
            plot([iPhase, iPhase]/2 - 0.15, MF_panel_C_data.mean(iPhase) + [MF_panel_C_data.sem(iPhase), -MF_panel_C_data.sem(iPhase)], '-k'); % x_axis is divided by 2
        end;
        
        % plot model-based data:
        b = bar(1 + 0.15, auxData(2), 0.3); % x_axis is divided by 2
        b.FaceColor = options.figs.fig5C.barColors(1, :);
        b = bar(2 + 0.15, auxData(4), 0.3); % x_axis is divided by 2
        b.FaceColor = options.figs.fig5C.barColors(2, :);
        
        % plot error bars:
        for iPhase = 2:2:4
            plot([iPhase, iPhase]/2 + 0.15, auxData(iPhase) + [sem(iPhase), -sem(iPhase)], '-k'); % x_axis is divided by 2
        end;
        
        plot([2 4]/2 - 0.15, [0.80 0.80], 'k', 'linewidth', 1);
        plot([2 4]/2 + 0.15, [0.84 0.84], 'k', 'linewidth', 1);
        
        text(3/2 - 0.15, 0.81, '*', 'horizontalalignment', 'center', ...
            'verticalalignment', 'middle', ...
            'fontname', options.figs.fontName, 'fontsize', options.figs.labelFontSize);
        
        if iFigure == 3
            text(3/2 + 0.15, 0.85, '*', 'horizontalalignment', 'center', ...
                'verticalalignment', 'middle', ...
                'fontname', options.figs.fontName, 'fontsize', options.figs.labelFontSize);
        else
            text(3/2 + 0.15, 0.8625, 'ns', 'horizontalalignment', 'center', ...
                'verticalalignment', 'middle', ...
                'fontname', options.figs.fontName, 'fontsize', options.figs.labelFontSize);
        end;
    end;
        
    set(gca, 'xtick', options.figs.fig5C.xTick, 'xticklabel', options.figs.fig5C.xTickLabel, ...
        'ytick', options.figs.fig5C.yTick, ...
        'fontname', options.figs.fontName, 'fontsize', options.figs.fontSize);
    axis(options.figs.fig5C.axis);
    xlabel(options.figs.fig5C.xLabel, 'fontname', options.figs.fontName, 'fontsize', options.figs.labelFontSize);
    ylabel(options.figs.fig5C.yLabel, 'fontname', options.figs.fontName, 'fontsize', options.figs.labelFontSize);
    
    %% Save
    if options.save.selectedmodelsanalysis && options.overwrite.selectedmodelsanalysis
        if ~exist(outputDir, 'dir')
            mkdir(outputDir);
        end;
        
        switch iFigure
            case 1
                if options.verbose.selectedmodelsanalysis
                    % disp('Figure 5C_not_used was overwritten.');
                end;
                export_fig([outputDir filesep options.figs.fig5C.name ' - not_used'], '-tiff', ['-r' num2str(options.figs.res)], '-transparent'); % , '-nocrop'
            case 2
                if options.verbose.selectedmodelsanalysis
                    % disp('Figure 5C_Supp_not_used was overwritten.');
                end;
                export_fig([outputDir filesep options.figs.fig5C_Supp.name ' - not_used'], '-tiff', ['-r' num2str(options.figs.res)], '-transparent'); % , '-nocrop'
            case 3
                if options.verbose.selectedmodelsanalysis
                    disp('Figure 5C was overwritten.');
                end;
                export_fig([outputDir filesep options.figs.fig5C.name], '-tiff', ['-r' num2str(options.figs.res)], '-transparent'); % , '-nocrop'
            case 4
                if options.verbose.selectedmodelsanalysis
                    disp(' '); disp('Extended Data Figure 1C was overwritten.');
                end;
                export_fig([outputDir filesep options.figs.fig5C_Supp.name], '-tiff', ['-r' num2str(options.figs.res)], '-transparent'); % , '-nocrop'
        end;
        close(f);
    end;
end;
