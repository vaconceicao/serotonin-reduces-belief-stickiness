function [] = shellmdl_load_modelinspection_results(options, paths)
% [] = shellmdl_load_modelinspection_results(options, paths)
%
% shellmdl_load_modelinspection_results is a function called by
% shellmdl_master, which copies the previously obtained results from
% paths.previousresultsdir (the folder where those files should be stored)
% into paths.resultsdir (the new results folder). In doing so, this
% function generates (or overwrites) the results (that would be) obtained
% by running the model-inspection pipeline, allowing to minimize
% computation time. To run this function, instead of the full
% model-inspection pipeline, options.load.modelinspection and
% options.run.modelinspection should be set to 1 and 0, respectively, in
% shellmdl_set_analysis_options.
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  shellmdl_paths
%
% Author: Vasco A. Concei��o
%
% Last modified: November 2023

%% Settings
prDir = [paths.previousresultsdir filesep 'modelinspection'];                   	% previous results folder

prDir_all           = [prDir filesep 'all'];
prDir_individ_model = [prDir filesep 'individ_model'];

%% Main Code - Initialization
if ~exist(prDir, 'dir')
    mkdir(prDir);
end;
if ~exist(prDir_all, 'dir')
    mkdir(prDir_all);
end;
if ~exist(prDir_individ_model, 'dir')
    mkdir(prDir_individ_model);
end;

if options.verbose.modelinspection
    disp(' ');
    disp('--------------------------------------------------------------');
    disp('Running shellmdl_load_modelinspection_results...');
end;

%% Main Code - Copy the output files from shellmdl_master
paths   = shellmdl_paths(paths, 1);

rDir    = paths.results.group.modelcomparison.tempsession.alldir;                   % results folder
rFile1  = paths.results.group.modelcomparison.tempsession.all.modelEvidencesFile;   % results file 1
rFile2  = paths.results.group.modelcomparison.tempsession.all.McFaddenPseudoR2File; % results file 2
% copyfile(rFile1, prDir_all); % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFile2, prDir_all); % this line is commented intentionally; it was ran to obtain the previous results files

prFile1 = [prDir_all filesep 'modelEvidences.mat'];
prFile2 = [prDir_all filesep 'McFaddenPseudoR2.mat'];
if ~exist(rDir, 'dir')
    mkdir(rDir);
end;
copyfile(prFile1, rDir);
copyfile(prFile2, rDir);

%% Main Code - Copy the output files from shellmdl_loop_assess_TI_fit_and_get_me_and_gof_estimates
for iModel = options.modelinspection.firstModel:options.modelinspection.lastModel
    if options.verbose.modelinspection
        disp(['... for model ' options.mcmc.modelNames{iModel} ';']);
    end;
    
    prDir_individ_model_spec = [prDir_individ_model filesep options.mcmc.modelNames{iModel}];  % previous results folder
    if ~exist(prDir_individ_model_spec, 'dir')
        mkdir(prDir_individ_model_spec);
    end;
    
    for subject = options.dataset.subjects
        paths                   = shellmdl_paths(paths, 1, subject, iModel, options);
        rDir_individ_model_spec = paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelinspectiondir;
        
        rFile11 = [rDir_individ_model_spec filesep 'me_estimates.xls'];
        rFile12 = [rDir_individ_model_spec filesep 'max_me_variation.xls'];
        
        prDir_individ_model_spec_subj = [prDir_individ_model_spec filesep ['subject-' num2str(subject)]];
        if ~exist(prDir_individ_model_spec_subj, 'dir')
            mkdir(prDir_individ_model_spec_subj);
        end;
        
        % copyfile(rFile11, prDir_individ_model_spec_subj); % this line is commented intentionally; it was ran to obtain the previous results files
        % copyfile(rFile12, prDir_individ_model_spec_subj); % this line is commented intentionally; it was ran to obtain the previous results files
        
        prFile11 = [prDir_individ_model_spec_subj filesep 'me_estimates.xls'];
        prFile12 = [prDir_individ_model_spec_subj filesep 'max_me_variation.xls'];
        
        copyfile(prFile11, rDir_individ_model_spec);
        copyfile(prFile12, rDir_individ_model_spec);
    end;
    
    rDir2 = paths.results.group.modelinspection.tempsession.tempmodeldir;
    
    rFile21 = [rDir2 filesep 'me_estimates.xls'];
    rFile22 = [rDir2 filesep 'max_me_variation.xls'];
    rFile23 = [rDir2 filesep 'ME_TI_m.mat'];
    rFile24 = [rDir2 filesep 'AIC_m.mat'];
    rFile25 = [rDir2 filesep 'BIC_m.mat'];
    rFile26 = [rDir2 filesep 'maxLLH_m.mat'];
    rFile27 = [rDir2 filesep 'avgLLHTrial_m.mat'];
    rFile28 = [rDir2 filesep 'McFaddenPseudoR2_m.mat'];
    
    % copyfile(rFile21, prDir_individ_model_spec); % this line is commented intentionally; it was ran to obtain the previous results files
    % copyfile(rFile22, prDir_individ_model_spec); % this line is commented intentionally; it was ran to obtain the previous results files
    % copyfile(rFile23, prDir_individ_model_spec); % this line is commented intentionally; it was ran to obtain the previous results files
    % copyfile(rFile24, prDir_individ_model_spec); % this line is commented intentionally; it was ran to obtain the previous results files
    % copyfile(rFile25, prDir_individ_model_spec); % this line is commented intentionally; it was ran to obtain the previous results files
    % copyfile(rFile26, prDir_individ_model_spec); % this line is commented intentionally; it was ran to obtain the previous results files
    % copyfile(rFile27, prDir_individ_model_spec); % this line is commented intentionally; it was ran to obtain the previous results files
    % copyfile(rFile28, prDir_individ_model_spec); % this line is commented intentionally; it was ran to obtain the previous results files
    
    prFile21 = [prDir_individ_model_spec filesep 'me_estimates.xls'];
    prFile22 = [prDir_individ_model_spec filesep 'max_me_variation.xls'];
    prFile23 = [prDir_individ_model_spec filesep 'ME_TI_m.mat'];
    prFile24 = [prDir_individ_model_spec filesep 'AIC_m.mat'];
    prFile25 = [prDir_individ_model_spec filesep 'BIC_m.mat'];
    prFile26 = [prDir_individ_model_spec filesep 'maxLLH_m.mat'];
    prFile27 = [prDir_individ_model_spec filesep 'avgLLHTrial_m.mat'];
    prFile28 = [prDir_individ_model_spec filesep 'McFaddenPseudoR2_m.mat'];
    
    copyfile(prFile21, rDir2);
    copyfile(prFile22, rDir2);
    copyfile(prFile23, rDir2);
    copyfile(prFile24, rDir2);
    copyfile(prFile25, rDir2);
    copyfile(prFile26, rDir2);
    copyfile(prFile27, rDir2);
    copyfile(prFile28, rDir2);
end;

end