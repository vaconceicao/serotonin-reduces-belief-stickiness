function [] = shellmdl_assess_plot_relations_state_inference_stickiness(options, paths)
% [] = shellmdl_assess_plot_relations_state_inference_stickiness(options, paths)
%
% shellmdl_assess_plot_relations_state_inference_stickiness is a function 
% called by shellmdl_master that performs several analyses regarding the 
% relations between 1) belief stickiness or state inference and 2) 
% escitalopram levels or OCI-R obsessing scores. In doing so, it creates 
% Figures 7 and 8 of the paper.
% In addition, this function creates several files that are necessary for
% complementary R or SPSS analyses, and it calls 
% shellmdl_assess_btw_group_differences_in_model_frequencies to perform
% complementary comparisons of model frequencies across groups.
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  shellmdl_paths
%  shellmdl_assess_btw_group_differences_in_model_frequencies
%
% Author: Vasco A. Concei��o
%
% Last modified: April 2024

%% Init - Get all necessary variables and create all necessary folders and files (for analyses in R):
if options.verbose.selectedmodelsanalysis
    disp(' ');
    disp('--------------------------------------------------------------');
    disp('Running shellmdl_assess_plot_relations_state_inference_stickiness...');
end;

subjIndicesOfInterest   = ~ismember(options.dataset.subjects, options.questionnaires.additionalExcludedSubjects); % to exclude the subject without OCI-R data

escitalopramOutputDir   = paths.results.group.drugdir;
load([escitalopramOutputDir filesep 'escitalopramLevels.mat']);
load([escitalopramOutputDir filesep 'escitalopramGroup.mat']);

ocirOutputDir        	= paths.results.group.questionnairesdir;
load([ocirOutputDir filesep 'ocirObsessingScores.mat']);
load([ocirOutputDir filesep 'ocirOtherScores.mat']);

load(paths.results.group.cca.tempsession.all.resultsfile);
scores1stCV             = U(:, 1);

load(paths.results.group.modelcomparison.tempsession.all.deltaLogMEfile);

data_of_interest        = [escitalopramLevels(subjIndicesOfInterest), escitalopramGroup(subjIndicesOfInterest), ...
    ocirObsessingScores(subjIndicesOfInterest), ocirOtherScores(subjIndicesOfInterest), ...
    scores1stCV, deltaLogME(subjIndicesOfInterest)];
nAnalyzedSubjects       = size(data_of_interest, 1);

if options.save.selectedmodelsanalysis && options.overwrite.selectedmodelsanalysis
    lmOutputDir = paths.results.group.linearmodels.tempsession.alldir;
    if ~exist(lmOutputDir, 'dir')
        mkdir(lmOutputDir);
    end;
    xlswrite(paths.results.group.linearmodels.tempsession.all.datafile, data_of_interest);
    csvwrite(paths.results.group.linearmodels.tempsession.all.csvdatafile, data_of_interest);
    
    disp(' ');
    disp('The first .csv file necessary to run perform_lms_and_bcx_transfs_in_R was overwritten.');
    disp('If you did not do so yet, please run perform_lms_and_bcx_transfs_in_R until the end of Section 2.');
    disp('Then, convert the .csv output into an .xls file (with the respective numerical values disposed in 1 column & 2 rows), so that shellmdl_plot_relations_state_inference_stickiness can proceed.');
    disp(' ');
    
    readyToProceed = input('Did you already generate lambdasBCxDeltaLogME.xls?\nPlease introduce 1 if so, so that shellmdl_assess_plot_relations_state_inference_stickiness can proceed.\n');
    disp(' ');
    while ~readyToProceed
        readyToProceed = input('Did you already generate lambdasBCxDeltaLogME.xls?\nPlease introduce 1 if so, so that shellmdl_assess_plot_relations_state_inference_stickiness can proceed.\n');
        disp(' ');
    end;
end;

try
    LambdaHats = xlsread(paths.results.group.modelcomparison.tempsession.all.lambdasBCxDeltaLogMEfile);
    bcxDeltaLogME = boxcox(LambdaHats(1), (LambdaHats(2) + deltaLogME(subjIndicesOfInterest)));
    data_of_interest = [data_of_interest, bcxDeltaLogME];

    if options.save.selectedmodelsanalysis && options.overwrite.selectedmodelsanalysis
        xlswrite(paths.results.group.linearmodels.tempsession.all.datafile, data_of_interest);
        csvwrite(paths.results.group.linearmodels.tempsession.all.csvdatafile, data_of_interest);
        
        disp('The .csv file necessary to run perform_lms_and_bcx_transfs_in_R was overwritten again.');
        disp('It now includes the Box-Cox-transformed deltaLogME values.');
        disp('You may now run Section 3 of perform_lms_and_bcx_transfs_in_R.');
        disp(' ');
    end;
    
catch
    disp('ERROR: The Box-Cox transformation of deltaLogME could not be performed. Please run perform_lms_and_bcx_transfs_in_R first.');
    disp(' ');
end;

outputDir                       = paths.results.group.selectedmodelsanalysis.tempsession.alldir;
figuresOutputDir                = paths.results.group.selectedmodelsanalysis.tempsession.all.figuresdir;

if ~exist(outputDir, 'dir')
    mkdir(outputDir);
end;
if ~exist(figuresOutputDir, 'dir')
    mkdir(figuresOutputDir);
end;

showEscitalopramMedian  = 1;                            % Default: 1
markerSize              = 4;                            % Default: 4

%% Main Code
x                       = data_of_interest(:, 1);       % escitalopram levels
x2                      = data_of_interest(:, 3);       % OCI-R obsessing scores levels
y                       = data_of_interest(:, 5);       % scores on the 1st CV
y2                      = data_of_interest(:, 7);       % Box-Cox-transformed deltaLogME values

lowEscitalSubjects  = find(x <= median(x(x>0)));
highEscitalSubjects = find(x > median(x(x>0)));
lowEscitalSubjects  = intersect(lowEscitalSubjects, find(x>0));
placeboSubjects     = find(x == 0);

lowEscital_v        = zeros(nAnalyzedSubjects, 1);
offEscital_v        = zeros(nAnalyzedSubjects, 1);
highEscital_v       = zeros(nAnalyzedSubjects, 1);

lowEscital_v(lowEscitalSubjects)    = 1;
offEscital_v(placeboSubjects)       = 1;
highEscital_v(highEscitalSubjects)  = 1;

%% Main Code - Figure 7 - Panel A:
f = figure(); figName = 'Figure 7 - Panel A';
set(f, 'units', 'centimeters', 'position', [0 0 5.1 5.1], ...
    'paperunits', 'centimeters', 'paperposition', [0 0 5.1 5.1]);

hold all;

plot(x(lowEscitalSubjects), y(lowEscitalSubjects), 'o', 'markersize', markerSize, 'markerfacecolor', 'k', 'markeredgecolor', 'k');
plot(x(highEscitalSubjects), y(highEscitalSubjects), 'o', 'markersize', markerSize, 'markerfacecolor', 'k', 'markeredgecolor', 'k');

set(gca, 'xtick', 0:10:90, 'ytick', -2.5:1:2.5, 'fontsize', 7, 'fontname', 'arial');

xlabel('Escitalopram Level', 'fontsize', 8, 'fontname', 'arial');
ylabel('Belief Stickiness (1^{st} CV)', 'fontsize', 8, 'fontname', 'arial');

axis([0 90 -2.5 2.5]);

% Save:
if options.save.selectedmodelsanalysis && options.overwrite.selectedmodelsanalysis
    export_fig([figuresOutputDir filesep figName], '-r800', '-nocrop', '-tiff', '-transparent'); print([figuresOutputDir filesep figName], '-r800', '-depsc', '-tiff');
end;

%% Main Code - Figure 7 - Panel B:
f = figure(); figName = 'Figure 7 - Panel B';
set(f, 'units', 'centimeters', 'position', [0 0 5.1 5.1], ...
    'paperunits', 'centimeters', 'paperposition', [0 0 5.1 5.1]);

hold all;

plot(x2, y, 'o', 'markersize', markerSize, 'markerfacecolor', 'k', 'markeredgecolor', 'k');

set(gca, 'xtick', 0:2:10, 'ytick', -2.5:1:2.5, 'yticklabel', [], 'fontsize', 7, 'fontname', 'arial');

xlabel('OCI-R Obsessing', 'fontsize', 8, 'fontname', 'arial');

axis([0 10 -2.5 2.5]);

% Save:
if options.save.selectedmodelsanalysis && options.overwrite.selectedmodelsanalysis
    export_fig([figuresOutputDir filesep figName], '-r800', '-nocrop', '-tiff', '-transparent'); print([figuresOutputDir filesep figName], '-r800', '-depsc', '-tiff');
end;

%% Main Code - Figure 7 - Panel C:
f = figure(); figName = 'Figure 7 - Panel C';
set(f, 'units', 'centimeters', 'position', [0 0 5.1 5.1], ...
    'paperunits', 'centimeters', 'paperposition', [0 0 5.1 5.1]);

hold all;

if showEscitalopramMedian
    plot(repmat(median(x(x>0)), 2, 1), [-2.5, 2.5], '--', 'color', [0 0.5 0]); % [0.3 0.4 0]);
end;

plot(x(lowEscitalSubjects), y(lowEscitalSubjects), 'o', 'markersize', markerSize, 'markerfacecolor', [0 0.7 0], 'markeredgecolor', [0 0.7 0]); % [0.7 0 0], 'markeredgecolor', [0.7 0 0]);
plot(x(highEscitalSubjects), y(highEscitalSubjects), 'o', 'markersize', markerSize, 'markerfacecolor', [0 0.32 0], 'markeredgecolor', [0 0.32 0]); % [0 0.7 0], 'markeredgecolor', [0 0.7 0]);

plot([0 90], repmat(mean(y(x == 0)), 2, 1), '--', 'color', [0.7 0.7 0.7]);

set(gca, 'xtick', 0:10:90, 'ytick', -2.5:1:2.5, 'yticklabel', [], 'fontsize', 7, 'fontname', 'arial');

xlabel('Escitalopram Level', 'fontsize', 8, 'fontname', 'arial');

axis([0 90 -2.5 2.5]);

% Save:
if options.save.selectedmodelsanalysis && options.overwrite.selectedmodelsanalysis
    export_fig([figuresOutputDir filesep figName], '-r800', '-nocrop', '-tiff', '-transparent'); print([figuresOutputDir filesep figName], '-r800', '-depsc', '-tiff');
end;

%% Main Code - Figure 7 - Panel D:
f = figure(); figName = 'Figure 7 - Panel D';
set(f, 'units', 'centimeters', 'position', [0 0 5.4 5.1], ...
    'paperunits', 'centimeters', 'paperposition', [0 0 5.4 5.1]);

hold all;
bar(3, mean(y(lowEscitalSubjects)),     'facecolor', [0 0.7 0]);
bar(2, mean(y(placeboSubjects)),        'facecolor', [0.7 0.7 0.7]);
bar(1, mean(y(highEscitalSubjects)),    'facecolor', [0 0.32 0]);

% depict individual datapoints:
plot(2 + (0.64:((1.36 - 0.64)/(numel(lowEscitalSubjects) - 1)):1.36), y(lowEscitalSubjects), 'o', ...
    'markersize', 2.5, 'markerfacecolor', [0 0.60 0], 'markeredgecolor', 'k', 'linewidth', 0.1);

plot(1 + (0.64:((1.36 - 0.64)/(numel(placeboSubjects) - 1)):1.36), y(placeboSubjects), 'o', ...
    'markersize', 2.5, 'markerfacecolor', [0.7 0.7 0.7] * 0.85, 'markeredgecolor', 'k', 'linewidth', 0.1);

plot(0.64:((1.36 - 0.64)/(numel(highEscitalSubjects) - 1)):1.36, y(highEscitalSubjects), 'o', ...
    'markersize', 2.5, 'markerfacecolor', [0 0.45 0], 'markeredgecolor', 'k', 'linewidth', 0.1);

% depict error bars:
sem_low         = std(y(lowEscitalSubjects))/sqrt(numel(lowEscitalSubjects));
plot([3, 3], mean(y(lowEscitalSubjects)) + sem_low * [-1, 1], 'k');

sem_placebo     = std(y(placeboSubjects))/sqrt(numel(placeboSubjects));
plot([2, 2], mean(y(placeboSubjects)) + sem_placebo * [-1, 1], 'k');

sem_high        = std(y(highEscitalSubjects))/sqrt(numel(highEscitalSubjects));
plot([1, 1], mean(y(highEscitalSubjects)) + sem_high * [-1, 1], 'k');

% identify significant differences:
plot([2, 3], [0.85, 0.85] + 1.40, '-k'); text(2.5, 0.95 + 1.52, 'ns', 'fontname', 'arial', 'fontsize', 7, 'horizontalalignment', 'center');
plot([2, 1], [1.20, 1.20] + 1.40, '-k'); text(1.5, 1.27 + 1.40, '**', 'fontname', 'arial', 'fontsize', 8, 'horizontalalignment', 'center');

set(gca, 'xtick', 1:1:3, 'xticklabel', [], ...
    'ytick', -2.7:0.9:2.7, 'fontsize', 7, 'fontname', 'arial');

text(1, -1.62 - 1.40, 'High', 'fontsize', 7.5, 'fontname', 'arial', 'horizontalalignment', 'center');
text(1, -1.80 - 1.56, 'Escitalopram', 'fontsize', 7.5, 'fontname', 'arial', 'horizontalalignment', 'center');

text(2, -1.71 - 1.48, 'Placebo', 'fontsize', 7.5, 'fontname', 'arial', 'horizontalalignment', 'center');

text(3, -1.62 - 1.40, 'Low', 'fontsize', 7.5, 'fontname', 'arial', 'horizontalalignment', 'center');
text(3, -1.80 - 1.56, 'Escitalopram', 'fontsize', 7.5, 'fontname', 'arial', 'horizontalalignment', 'center');

axis([0.5 3.5 -2.8 2.8]);

% Save:
if options.save.selectedmodelsanalysis && options.overwrite.selectedmodelsanalysis
    export_fig([figuresOutputDir filesep figName], '-r800', '-nocrop', '-tiff', '-transparent'); print([figuresOutputDir filesep figName], '-r800', '-depsc', '-tiff');
end;

%% Main Code - Figure 8 - Panel A:
f = figure(); figName = 'Figure 8 - Panel A';
set(f, 'units', 'centimeters', 'position', [0 0 5.1 5.1], ...
    'paperunits', 'centimeters', 'paperposition', [0 0 5.1 5.1]);

hold all;

plot(x(lowEscitalSubjects), y2(lowEscitalSubjects), 'o', 'markersize', markerSize, 'markerfacecolor', 'k', 'markeredgecolor', 'k');
plot(x(highEscitalSubjects), y2(highEscitalSubjects), 'o', 'markersize', markerSize, 'markerfacecolor', 'k', 'markeredgecolor', 'k');

set(gca, 'xtick', 0:10:90, 'ytick', 0.65:0.03:0.80, 'fontsize', 7, 'fontname', 'arial');

xlabel('Escitalopram Level', 'fontsize', 8, 'fontname', 'arial');
ylabel('\DeltaLME''', 'fontsize', 8, 'fontname', 'arial');

axis([0 90 0.65 0.80]);

% Save:
if options.save.selectedmodelsanalysis && options.overwrite.selectedmodelsanalysis
    export_fig([figuresOutputDir filesep figName], '-r800', '-nocrop', '-tiff', '-transparent'); print([figuresOutputDir filesep figName], '-r800', '-depsc', '-tiff');
end;

%% Main Code - Figure 8 - Panel B:
f = figure(); figName = 'Figure 8 - Panel B';
set(f, 'units', 'centimeters', 'position', [0 0 5.1 5.1], ...
    'paperunits', 'centimeters', 'paperposition', [0 0 5.1 5.1]);

hold all;

plot(x2, y2, 'o', 'markersize', markerSize, 'markerfacecolor', 'k', 'markeredgecolor', 'k');

set(gca, 'xtick', 0:2:10, 'ytick', 0.65:0.03:0.80, 'yticklabel', [], 'fontsize', 7, 'fontname', 'arial');

xlabel('OCI-R Obsessing', 'fontsize', 8, 'fontname', 'arial');

axis([0 10 0.65 0.80]);

% Save:
if options.save.selectedmodelsanalysis && options.overwrite.selectedmodelsanalysis
    export_fig([figuresOutputDir filesep figName], '-r800', '-nocrop', '-tiff', '-transparent'); print([figuresOutputDir filesep figName], '-r800', '-depsc', '-tiff');
end;

%% Main Code - Figure 8 - Panel C:
f = figure(); figName = 'Figure 8 - Panel C';
set(f, 'units', 'centimeters', 'position', [0 0 5.1 5.1], ...
    'paperunits', 'centimeters', 'paperposition', [0 0 5.1 5.1]);

hold all;

if showEscitalopramMedian
    plot(repmat(median(x(x>0)), 2, 1), [-1 5], '--', 'color', [0 0.5 0]); % [0.3 0.4 0]);
end;

plot(x(lowEscitalSubjects), y2(lowEscitalSubjects), 'o', 'markersize', markerSize, 'markerfacecolor', [0 0.7 0], 'markeredgecolor', [0 0.7 0]); % [0.7 0 0], 'markeredgecolor', [0.7 0 0]);
plot(x(highEscitalSubjects), y2(highEscitalSubjects), 'o', 'markersize', markerSize, 'markerfacecolor', [0 0.32 0], 'markeredgecolor', [0 0.32 0]); % [0 0.7 0], 'markeredgecolor', [0 0.7 0]);

plot([0 90], repmat(mean(y2(x == 0)), 2, 1), '--', 'color', [0.7 0.7 0.7]);

set(gca, 'xtick', 0:10:90, 'ytick', 0.65:0.03:0.80, 'yticklabel', [], 'fontsize', 7, 'fontname', 'arial');

xlabel('Escitalopram Level', 'fontsize', 8, 'fontname', 'arial');

axis([0 90 0.65 0.80]);

% Save:
if options.save.selectedmodelsanalysis && options.overwrite.selectedmodelsanalysis
    export_fig([figuresOutputDir filesep figName], '-r800', '-nocrop', '-tiff', '-transparent'); print([figuresOutputDir filesep figName], '-r800', '-depsc', '-tiff');
end;

%% Main Code - Figure 8 - Panel D:
f = figure(); figName = 'Figure 8 - Panel D';
set(f, 'units', 'centimeters', 'position', [0 0 5.4 5.1], ...
    'paperunits', 'centimeters', 'paperposition', [0 0 5.4 5.1]);

hold all;
bar(3, mean(y2(lowEscitalSubjects)),     'facecolor', [0 0.7 0]);
bar(2, mean(y2(placeboSubjects)),        'facecolor', [0.7 0.7 0.7]);
bar(1, mean(y2(highEscitalSubjects)),    'facecolor', [0 0.32 0]);

% depict individual datapoints:
plot(2 + (0.64:((1.36 - 0.64)/(numel(lowEscitalSubjects) - 1)):1.36), y2(lowEscitalSubjects), 'o', ...
    'markersize', 2.5, 'markerfacecolor', [0 0.60 0], 'markeredgecolor', 'k', 'linewidth', 0.1);

plot(1 + (0.64:((1.36 - 0.64)/(numel(placeboSubjects) - 1)):1.36), y2(placeboSubjects), 'o', ...
    'markersize', 2.5, 'markerfacecolor', [0.7 0.7 0.7] * 0.85, 'markeredgecolor', 'k', 'linewidth', 0.1);

plot(0.64:((1.36 - 0.64)/(numel(highEscitalSubjects) - 1)):1.36, y2(highEscitalSubjects), 'o', ...
    'markersize', 2.5, 'markerfacecolor', [0 0.45 0], 'markeredgecolor', 'k', 'linewidth', 0.1);

% depict error bars:
sem_low         = std(y2(lowEscitalSubjects))/sqrt(numel(lowEscitalSubjects));
plot([3, 3], mean(y2(lowEscitalSubjects)) + sem_low * [-1, 1], 'k');

sem_placebo     = std(y2(placeboSubjects))/sqrt(numel(placeboSubjects));
plot([2, 2], mean(y2(placeboSubjects)) + sem_placebo * [-1, 1], 'k');

sem_high        = std(y2(highEscitalSubjects))/sqrt(numel(highEscitalSubjects));
plot([1, 1], mean(y2(highEscitalSubjects)) + sem_high * [-1, 1], 'k');

% identify significant differences:
plot([3, 2], [0.745, 0.745] + 0.06, '-k'); text(2.5, 0.745 + 0.068, 'ns', 'fontname', 'arial', 'fontsize', 7, 'horizontalalignment', 'center');
plot([2, 1], [0.770, 0.770] + 0.06, '-k'); text(1.5, 0.770 + 0.062, '*', 'fontname', 'arial', 'fontsize', 8, 'horizontalalignment', 'center');

set(gca, 'xtick', 1:1:3, 'xticklabel', [], ...
    'ytick', 0.64:0.04:0.84, 'fontsize', 7, 'fontname', 'arial');

text(1, 0.676 - 0.044, 'High', 'fontsize', 7.5, 'fontname', 'arial', 'horizontalalignment', 'center');
text(1, 0.67 - 0.050, 'Escitalopram', 'fontsize', 7.5, 'fontname', 'arial', 'horizontalalignment', 'center');

text(2, 0.673 - 0.047, 'Placebo', 'fontsize', 7.5, 'fontname', 'arial', 'horizontalalignment', 'center');

text(3, 0.676 - 0.044, 'Low', 'fontsize', 7.5, 'fontname', 'arial', 'horizontalalignment', 'center');
text(3, 0.67 - 0.050, 'Escitalopram', 'fontsize', 7.5, 'fontname', 'arial', 'horizontalalignment', 'center');

axis([0.5 3.5 0.64 0.84]);

% Save:
if options.save.selectedmodelsanalysis && options.overwrite.selectedmodelsanalysis
    export_fig([figuresOutputDir filesep figName], '-r800', '-nocrop', '-tiff', '-transparent'); print([figuresOutputDir filesep figName], '-r800', '-depsc', '-tiff');
end;

if options.save.selectedmodelsanalysis && options.overwrite.selectedmodelsanalysis && options.verbose.selectedmodelsanalysis
    disp('All panels of Figures 7 and 8 were overwritten.');
end;

%% Save data for analysis in SPSS
recoded_group       = lowEscital_v * 3 + offEscital_v * 2 + highEscital_v * 1;  % 3 (low escitalopram levels); 2 (placebo); 1 (high escitalopram levels)
data_for_anovas     = [y, y2, recoded_group];                                   % scores on the 1st CV, Box-Cox-transformed deltaLogME values, group recoded as above

if options.save.selectedmodelsanalysis && options.overwrite.selectedmodelsanalysis
    xlswrite([paths.results.group.selectedmodelsanalysis.tempsession.alldir filesep 'data_for_anovas'], data_for_anovas);
    if options.verbose.selectedmodelsanalysis
        disp('Data for ANOVAs in SPSS was overwritten.');
    end;
end;

%% Perform additional comparisons of the model frequencies between the three groups (low escitalopram levels; placebo; high escitalopram levels)
groupInfo.highEscitalSubjects   = highEscitalSubjects;
groupInfo.placeboSubjects       = placeboSubjects;
groupInfo.lowEscitalSubjects    = lowEscitalSubjects;
shellmdl_assess_btw_group_differences_in_model_frequencies(options, paths, 'main', groupInfo); % only the 43 subjects with OCI-R data are included in this analysis (see Manuscript for the rationale)

%% Assess the relation between the Box-Cox-transformed values of deltaLogME and the predictors of interest
if options.verbose.selectedmodelsanalysis
    disp(' ');
    disp('Assessing the relation between 1) state inference and 2) escitalopram levels, group, OCI-R obsessing scores, and OCI-R other scores...)');
    disp(' ');
end;

% to center escitalopram levels:
onEscital                       = data_of_interest(:, 1) > 0; 
data_of_interest(onEscital, 1)  = data_of_interest(onEscital, 1) - mean(data_of_interest(onEscital, 1));

state_inference_model       = fitglm(data_of_interest(:, 1:4), y2); % predictors: escitalopram levels, group, OCI-R obsessing scores, OCI-R other scores
state_inference_model_CIs   = coefCI(state_inference_model);

if options.verbose.selectedmodelsanalysis
    state_inference_model
    state_inference_model_CIs
end;
end
