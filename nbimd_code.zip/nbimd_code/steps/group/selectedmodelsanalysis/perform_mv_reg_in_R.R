cat("\014")
rm(list = ls())

library(heplots)

################################################################################
# Obtain the parameter estimates for the 43 subjects with OCI-R data:
data_for_mv_reg             = read.csv('C:/Users/User/OneDrive/Área de Trabalho/nbimd_results/group/modelinspection/session1/SSR8/param_estimates.csv', header = FALSE, sep = ",", dec = ".") # adjust accordingly
subjsWithOCIR               = c(2:44)
data_for_mv_reg             = data_for_mv_reg[subjsWithOCIR, ]

# Obtain the escitalopram levels, group, OCI-R obsessing scores, and OCI-R other scores:
additional_data_for_mv_reg  = read.csv('C:/Users/User/OneDrive/Área de Trabalho/nbimd_results/group/linearmodels/session1/all/linear_models_data.csv', header = FALSE, sep = ",", dec = ".") # adjust accordingly

# Get all necessary data into a single table:
data_for_mv_reg             = cbind(data_for_mv_reg, additional_data_for_mv_reg)

################################################################################
# Perform the multivariate regression:
Y     = cbind(data_for_mv_reg[, 2], data_for_mv_reg[, 3], data_for_mv_reg[, 4], data_for_mv_reg[, 5], data_for_mv_reg[, 6])  # S-R parameters
X     = cbind(data_for_mv_reg[, 9], data_for_mv_reg[, 10], data_for_mv_reg[, 11], data_for_mv_reg[, 12]) # predictors of interest

maov  = manova(Y ~ X, data = data_for_mv_reg)
print(summary(maov, test = "Wilks"))

################################################################################
# Get the respective adjusted Multivariate R-squared:

rSquared = 1 - 0.5889 # 1 - Wilk's lambda
print(rSquared)

v = 113.72            # v = denominator df; v = m * s + 1 - (kY * kX)/2 = 37 * 3.317 + 1 - 10 = 113.72
m = 37                # m = N - max(kA, kC) - (kY + KX + 3)/2 = 43 - 0 - (5 + 4 +3)/2 = 43 - 12/2 = 43 - 6 = 37
s = sqrt(11)          # s = sqrt((KY^2 * KX^2 - 4) / (KY^2 + KX^2 - 5)) = sqrt((396)/(36)) = sqrt(11)
u = 20                # u = numerator df

adjusted_rSquared = 1 - (1 - rSquared) * ((v + u)/v)^s
print(adjusted_rSquared)

