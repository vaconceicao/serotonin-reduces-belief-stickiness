function [] = shellmdl_load_selectedmodelsanalysis_results(options, paths)
% [] = shellmdl_load_selectedmodelsanalysis_results(options, paths)
%
% shellmdl_load_selectedmodelsanalysis_results is a function called by 
% shellmdl_master, which copies the previously obtained results from 
% paths.previousresultsdir (the folder where those files should be stored) 
% into paths.resultsdir (the new results folder). In doing so, this 
% function generates (or overwrites) the results (that would be) obtained 
% by running the pipeline targeted at inspecting (in detail) the selected 
% model(s), allowing to minimize computation time. To run this function, 
% instead of the respective model-inspection pipeline,
% options.load.modelsimulations.selectedmodelsanalysis and
% options.run.modelsimulations.selectedmodelsanalysis should be set to 1
% and 0, respectively, in shellmdl_set_analysis_options.
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  shellmdl_paths
%
% Author: Vasco A. Concei��o
%
% Last modified: April 2024

%% Settings
prDir = [paths.previousresultsdir filesep 'selectedmodelsanalysis'];        % previous results folder

prDir_all           = [prDir filesep 'all'];
prDir_individ_model = [prDir filesep 'individ_model'];
prDir_all_figs      = [prDir_all filesep 'figures'];

%% Main Code - Initialization
if ~exist(prDir, 'dir')
    mkdir(prDir);
end;
if ~exist(prDir_all, 'dir')
    mkdir(prDir_all);
end;
if ~exist(prDir_individ_model, 'dir')
    mkdir(prDir_individ_model);
end;
if ~exist(prDir_all_figs, 'dir')
    mkdir(prDir_all_figs);
end;

if options.verbose.modelsimulations
    disp(' ');
    disp('--------------------------------------------------------------');
    disp('Running shellmdl_load_selectedmodelsanalysis_results...');
end;

%% Main Code - Copy the output files from shellmdl_loop_assess_diag_fit_and_get_param_estimates & shellmdl_loop_predict_subj_behavior
for iProcedure = 1:options.selectedmodelsanalysis.nProcedures
    iModel = options.selectedmodelsanalysis.iModelNumbers(iProcedure);

    prDir_individ_model_spec = [prDir_individ_model filesep options.mcmc.modelNames{iModel}];
    if ~exist(prDir_individ_model_spec, 'dir')
        mkdir(prDir_individ_model_spec);
    end;

    for subject = options.dataset.subjects
        paths           = shellmdl_paths(paths, 1, subject, iModel, options);
        rDir_individ    = paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelinspectiondir;

        % shellmdl_loop_assess_diag_fit_and_get_param_estimates:
        rFile1          = [rDir_individ filesep 'R_hat_assessment.xls'];
        rFile2          = [rDir_individ filesep 'param_estimates.xls'];

        prDir_individ_model_spec_subj = [prDir_individ_model_spec filesep ['subject-' num2str(subject)]];
        if ~exist(prDir_individ_model_spec_subj, 'dir')
            mkdir(prDir_individ_model_spec_subj);
        end;

        % copyfile(rFile1, prDir_individ_model_spec_subj); % this line is commented intentionally; it was ran to obtain the previous results files
        % copyfile(rFile2, prDir_individ_model_spec_subj); % this line is commented intentionally; it was ran to obtain the previous results files

        prFile1         = [prDir_individ_model_spec_subj filesep 'R_hat_assessment.xls'];
        prFile2         = [prDir_individ_model_spec_subj filesep 'param_estimates.xls'];

        if ~exist(rDir_individ, 'dir')
            mkdir(rDir_individ);
        end;

        copyfile(prFile1, rDir_individ);
        copyfile(prFile2, rDir_individ);

        % shellmdl_loop_predict_subj_behavior:
        rFile3          = [rDir_individ filesep ['predictedModelVariables-' num2str(subject) '.mat']];
        % copyfile(rFile3, prDir_individ_model_spec_subj); % this line is commented intentionally; it was ran to obtain the previous results files

        prFile3         = [prDir_individ_model_spec_subj filesep ['predictedModelVariables-' num2str(subject) '.mat']];
        copyfile(prFile3, rDir_individ);
    end;

    rDir    = paths.results.group.modelinspection.tempsession.tempmodeldir;

    % shellmdl_loop_assess_diag_fit_and_get_param_estimates:
    rFile1  = [rDir filesep 'R_hat_assessment.xls'];
    rFile2  = [rDir filesep 'param_estimates.xls'];
    rFile3  = [rDir filesep 'param_estimates.csv'];
    rFile4  = [rDir filesep 'params_m.mat'];

    % copyfile(rFile1, prDir_individ_model_spec); % this line is commented intentionally; it was ran to obtain the previous results files
    % copyfile(rFile2, prDir_individ_model_spec); % this line is commented intentionally; it was ran to obtain the previous results files
    % copyfile(rFile3, prDir_individ_model_spec); % this line is commented intentionally; it was ran to obtain the previous results files
    % copyfile(rFile4, prDir_individ_model_spec); % this line is commented intentionally; it was ran to obtain the previous results files

    prFile1 = [prDir_individ_model_spec filesep 'R_hat_assessment.xls'];
    prFile2 = [prDir_individ_model_spec filesep 'param_estimates.xls'];
    prFile3 = [prDir_individ_model_spec filesep 'param_estimates.csv'];
    prFile4 = [prDir_individ_model_spec filesep 'params_m.mat'];

    if ~exist(rDir, 'dir')
        mkdir(rDir);
    end;

    copyfile(prFile1, rDir);
    copyfile(prFile2, rDir);
    copyfile(prFile3, rDir);
    copyfile(prFile4, rDir);

    % shellmdl_loop_predict_subj_behavior:
    rDir2   = paths.results.group.modelinspection.tempsession.alldir;

    rFile5  = [rDir2 filesep 'predictedModelVariables.mat'];
    % copyfile(rFile5, prDir_all); % this line is commented intentionally; it was ran to obtain the previous results files

    prFile5 = [prDir_all filesep 'predictedModelVariables.mat'];
    copyfile(prFile5, rDir2);
end;

%% Main Code - Copy the output files from shellmdl_plot_predicted_subj_behavior
for s = 1:options.figs.fig5.nSubjects
    subj = options.figs.fig5.subjects(s);
    if subj == options.figs.fig5.subjectInUse % only being run for one subject (the subject whose data was placed in the article)
        paths       = shellmdl_paths(paths, 1, subj, options.rl.selectedModel, options);
        rDir_figs   = paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelinspection.figuresdir;

        if ~exist(rDir_figs, 'dir')
            mkdir(rDir_figs);
        end;

        for fig = 1:options.figs.fig5.nPanels
            if fig == 1
                rFig1   = [rDir_figs filesep options.figs.fig5A.name '.tif'];
                rFig2   = [rDir_figs filesep options.figs.fig5A.name '.eps'];

                prFig1  = [prDir_all_figs filesep options.figs.fig5A.name '.tif'];
                prFig2  = [prDir_all_figs filesep options.figs.fig5A.name '.eps'];
            else
                rFig1   = [rDir_figs filesep options.figs.fig5B.name '.tif'];
                rFig2   = [rDir_figs filesep options.figs.fig5B.name '.eps'];

                prFig1  = [prDir_all_figs filesep options.figs.fig5B.name '.tif'];
                prFig2  = [prDir_all_figs filesep options.figs.fig5B.name '.eps'];
            end;

            % copyfile(rFig1, prDir_all_figs); % this line is commented intentionally; it was ran to obtain the previous results files
            % copyfile(rFig2, prDir_all_figs); % this line is commented intentionally; it was ran to obtain the previous results files

            copyfile(prFig1, rDir_figs);
            copyfile(prFig2, rDir_figs);
        end;
    end;
end;

%% Main Code - Copy the output files from shellmdl_predict_group_behavior
modelNumbers    = options.selectedmodelsanalysis.iModelNumbers;
nFigures        = numel(modelNumbers);

rDir1           = paths.results.group.modelinspection.tempsession.alldir;
rDir2           = paths.results.group.modelinspection.tempsession.all.pgojamovidir;
if ~exist(rDir1, 'dir')
    mkdir(rDir1);
end;
if ~exist(rDir2, 'dir')
    mkdir(rDir2);
end;

for iFigure = 1:nFigures
    if iFigure == 1         % SR8, the nested equivalent of the selected model
        rFile1  = [rDir1 filesep 'predictedMeanPGoSupp.mat'];
        rFile2  = [rDir2 filesep 'group_pgo_sr8_jamovi_data.xls'];

        prFile1 = [prDir_all filesep 'predictedMeanPGoSupp.mat'];
        prFile2 = [prDir_all filesep 'group_pgo_sr8_jamovi_data.xls'];
    elseif iFigure == 2     % SSR8, the selected model
        rFile1  = [rDir1 filesep 'predictedMeanPGo.mat'];
        rFile2  = [rDir2 filesep 'group_pgo_ssr8_jamovi_data.xls'];

        prFile1 = [prDir_all filesep 'predictedMeanPGo.mat'];
        prFile2 = [prDir_all filesep 'group_pgo_ssr8_jamovi_data.xls'];
    end;

    % copyfile(rFile1, prDir_all); % this line is commented intentionally; it was ran to obtain the previous results files
    % copyfile(rFile2, prDir_all); % this line is commented intentionally; it was ran to obtain the previous results files

    copyfile(prFile1, rDir1);
    copyfile(prFile2, rDir2);
end;

%% Main Code - Copy the output files from shellmdl_plot_fitted_p_go_per_season
rDir_figs = paths.results.group.modelinspection.tempsession.all.figuresdir;
if ~exist(rDir_figs, 'dir')
    mkdir(rDir_figs);
end;

for iFigure = 1:options.figs.fig6A.nPanels
    switch iFigure
        case 1
            rFig    = [rDir_figs filesep options.figs.fig6A.name ' - not_used.tif'];
            prFig   = [prDir_all_figs filesep options.figs.fig6A.name ' - not_used.tif'];
        case 2
            rFig    = [rDir_figs filesep options.figs.figED1A.name ' - not_used.tif'];
            prFig   = [prDir_all_figs filesep options.figs.figED1A.name ' - not_used.tif'];
        case 3
            rFig    = [rDir_figs filesep options.figs.fig6A.name '.tif'];
            prFig   = [prDir_all_figs filesep options.figs.fig6A.name '.tif'];
        case 4
            rFig    = [rDir_figs filesep options.figs.figED1A.name '.tif'];
            prFig   = [prDir_all_figs filesep options.figs.figED1A.name '.tif'];
    end;

    % copyfile(rFig, prDir_all_figs); % this line is commented intentionally; it was ran to obtain the previous results files
    
    copyfile(prFig, rDir_figs);
end;

%% Main Code - Copy the output files from shellmdl_plot_predicted_group_behavior
modelNumbers    = options.selectedmodelsanalysis.iModelNumbers;
nFigures        = numel(modelNumbers);

rDir_figs       = paths.results.group.modelinspection.tempsession.all.figuresdir;
if ~exist(rDir_figs, 'dir')
    mkdir(rDir_figs);
end;

for iFigure = 1:nFigures
    if iFigure == 1
        rFig1   = [rDir_figs filesep options.figs.figED1B.name '.tif'];
        rFig2   = [rDir_figs filesep options.figs.figED1B.name '.eps'];
        
        prFig1  = [prDir_all_figs filesep options.figs.figED1B.name '.tif'];
        prFig2  = [prDir_all_figs filesep options.figs.figED1B.name '.eps'];
    elseif iFigure == 2
        rFig1   = [rDir_figs filesep options.figs.fig6B.name '.tif'];
        rFig2   = [rDir_figs filesep options.figs.fig6B.name '.eps'];
        
        prFig1  = [prDir_all_figs filesep options.figs.fig6B.name '.tif'];
        prFig2  = [prDir_all_figs filesep options.figs.fig6B.name '.eps'];
    end;
    
    % copyfile(rFig1, prDir_all_figs); % this line is commented intentionally; it was ran to obtain the previous results files
    % copyfile(rFig2, prDir_all_figs); % this line is commented intentionally; it was ran to obtain the previous results files
    
    copyfile(prFig1, rDir_figs);
    copyfile(prFig2, rDir_figs);
end;

%% Main Code - Copy the output files from shellmdl_plot_fitted_p_corr_per_phase
rDir_figs = paths.results.group.modelinspection.tempsession.all.figuresdir;
if ~exist(rDir_figs, 'dir')
    mkdir(rDir_figs);
end;

for iFigure = 1:options.figs.fig6C.nPanels
    switch iFigure
        case 1
            rFig    = [rDir_figs filesep options.figs.fig6C.name ' - not_used.tif'];
            prFig   = [prDir_all_figs filesep options.figs.fig6C.name ' - not_used.tif'];
        case 2
            rFig    = [rDir_figs filesep options.figs.figED1C.name ' - not_used.tif'];
            prFig   = [prDir_all_figs filesep options.figs.figED1C.name ' - not_used.tif'];
        case 3
            rFig    = [rDir_figs filesep options.figs.fig6C.name '.tif'];
            prFig   = [prDir_all_figs filesep options.figs.fig6C.name '.tif'];
        case 4
            rFig    = [rDir_figs filesep options.figs.figED1C.name '.tif'];
            prFig   = [prDir_all_figs filesep options.figs.figED1C.name '.tif'];
    end;

    % copyfile(rFig, prDir_all_figs); % this line is commented intentionally; it was ran to obtain the previous results files
    
    copyfile(prFig, rDir_figs);
end;

%% Main Code - Copy the output files from shellmdl_aggreg_data_for_cca
rDir    = paths.results.group.cca.tempsession.alldir;

rFile   = [rDir filesep 'cca_data.xls'];
% copyfile(rFile, prDir_all); % this line is commented intentionally; it was ran to obtain the previous results files

prFile  = [prDir_all filesep 'cca_data.xls'];
if ~exist(rDir, 'dir')
    mkdir(rDir);
end;
copyfile(prFile, rDir);

%% Main Code - Copy the output files from shellmdl_perform_cca_permutations
rDir    = paths.results.group.cca.tempsession.alldir;

rFile   = [rDir filesep 'cca_results.mat'];
% copyfile(rFile, prDir_all); % this line is commented intentionally; it was ran to obtain the previous results files

prFile  = [prDir_all filesep 'cca_results.mat'];
if ~exist(rDir, 'dir')
    mkdir(rDir);
end;
copyfile(prFile, rDir);

%% Main Code - Copy the output files from shellmdl_assess_plot_relations_state_inference_stickiness
rDir1   = paths.results.group.linearmodels.tempsession.alldir;
rDir2   = paths.results.group.selectedmodelsanalysis.tempsession.alldir;

rFile1  = [rDir1 filesep 'linear_models_data.xls'];
rFile2  = [rDir1 filesep 'linear_models_data.csv'];
rFile3  = [rDir2 filesep 'data_for_anovas.xls'];

rDir_figs   = paths.results.group.selectedmodelsanalysis.tempsession.all.figuresdir;

rFig11 = [rDir_figs filesep 'Figure 7 - Panel A.tif'];
rFig12 = [rDir_figs filesep 'Figure 7 - Panel A.eps'];
rFig21 = [rDir_figs filesep 'Figure 7 - Panel B.tif'];
rFig22 = [rDir_figs filesep 'Figure 7 - Panel B.eps'];
rFig31 = [rDir_figs filesep 'Figure 7 - Panel C.tif'];
rFig32 = [rDir_figs filesep 'Figure 7 - Panel C.eps'];
rFig41 = [rDir_figs filesep 'Figure 7 - Panel D.tif'];
rFig42 = [rDir_figs filesep 'Figure 7 - Panel D.eps'];
rFig51 = [rDir_figs filesep 'Figure 8 - Panel A.tif'];
rFig52 = [rDir_figs filesep 'Figure 8 - Panel A.eps'];
rFig61 = [rDir_figs filesep 'Figure 8 - Panel B.tif'];
rFig62 = [rDir_figs filesep 'Figure 8 - Panel B.eps'];
rFig71 = [rDir_figs filesep 'Figure 8 - Panel C.tif'];
rFig72 = [rDir_figs filesep 'Figure 8 - Panel C.eps'];
rFig81 = [rDir_figs filesep 'Figure 8 - Panel D.tif'];
rFig82 = [rDir_figs filesep 'Figure 8 - Panel D.eps'];

% copyfile(rFile1, prDir_all);        % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFile2, prDir_all);        % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFile3, prDir_all);        % this line is commented intentionally; it was ran to obtain the previous results files

% copyfile(rFig11, prDir_all_figs);   % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFig12, prDir_all_figs);   % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFig21, prDir_all_figs);   % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFig22, prDir_all_figs);   % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFig31, prDir_all_figs);   % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFig32, prDir_all_figs);   % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFig41, prDir_all_figs);   % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFig42, prDir_all_figs);   % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFig51, prDir_all_figs);   % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFig52, prDir_all_figs);   % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFig61, prDir_all_figs);   % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFig62, prDir_all_figs);   % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFig71, prDir_all_figs);   % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFig72, prDir_all_figs);   % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFig81, prDir_all_figs);   % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFig82, prDir_all_figs);   % this line is commented intentionally; it was ran to obtain the previous results files

if ~exist(rDir1, 'dir')
    mkdir(rDir1);
end;
if ~exist(rDir2, 'dir')
    mkdir(rDir2);
end;

prFile1 = [prDir_all filesep 'linear_models_data.xls'];
prFile2 = [prDir_all filesep 'linear_models_data.csv'];
prFile3 = [prDir_all filesep 'data_for_anovas.xls'];

prFig11 = [prDir_all_figs filesep 'Figure 7 - Panel A.tif'];
prFig12 = [prDir_all_figs filesep 'Figure 7 - Panel A.eps'];
prFig21 = [prDir_all_figs filesep 'Figure 7 - Panel B.tif'];
prFig22 = [prDir_all_figs filesep 'Figure 7 - Panel B.eps'];
prFig31 = [prDir_all_figs filesep 'Figure 7 - Panel C.tif'];
prFig32 = [prDir_all_figs filesep 'Figure 7 - Panel C.eps'];
prFig41 = [prDir_all_figs filesep 'Figure 7 - Panel D.tif'];
prFig42 = [prDir_all_figs filesep 'Figure 7 - Panel D.eps'];
prFig51 = [prDir_all_figs filesep 'Figure 8 - Panel A.tif'];
prFig52 = [prDir_all_figs filesep 'Figure 8 - Panel A.eps'];
prFig61 = [prDir_all_figs filesep 'Figure 8 - Panel B.tif'];
prFig62 = [prDir_all_figs filesep 'Figure 8 - Panel B.eps'];
prFig71 = [prDir_all_figs filesep 'Figure 8 - Panel C.tif'];
prFig72 = [prDir_all_figs filesep 'Figure 8 - Panel C.eps'];
prFig81 = [prDir_all_figs filesep 'Figure 8 - Panel D.tif'];
prFig82 = [prDir_all_figs filesep 'Figure 8 - Panel D.eps'];

copyfile(prFile1, rDir1);
copyfile(prFile2, rDir1);
copyfile(prFile3, rDir2);

copyfile(prFig11, rDir_figs);
copyfile(prFig12, rDir_figs);
copyfile(prFig21, rDir_figs);
copyfile(prFig22, rDir_figs);
copyfile(prFig31, rDir_figs);
copyfile(prFig32, rDir_figs);
copyfile(prFig41, rDir_figs);
copyfile(prFig42, rDir_figs);
copyfile(prFig51, rDir_figs);
copyfile(prFig52, rDir_figs);
copyfile(prFig61, rDir_figs);
copyfile(prFig62, rDir_figs);
copyfile(prFig71, rDir_figs);
copyfile(prFig72, rDir_figs);
copyfile(prFig81, rDir_figs);
copyfile(prFig82, rDir_figs);

rDir3   = paths.results.group.modelcomparison.tempsession.alldir;

rFile4  = [rDir3 filesep 'lambdasBCxDeltaLogME.xls'];
rFile5  = [rDir3 filesep 'lambdasBCxDeltaLogME.csv'];

% copyfile(rFile4, prDir_all);        % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFile5, prDir_all);        % this line is commented intentionally; it was ran to obtain the previous results files

if ~exist(rDir3, 'dir')
    mkdir(rDir3);
end;

prFile4 = [prDir_all filesep 'lambdasBCxDeltaLogME.xls'];
prFile5 = [prDir_all filesep 'lambdasBCxDeltaLogME.csv'];

copyfile(prFile4, rDir3);
copyfile(prFile5, rDir3);
