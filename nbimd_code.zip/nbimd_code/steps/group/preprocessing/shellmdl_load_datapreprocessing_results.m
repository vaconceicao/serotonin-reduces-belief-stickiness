function [] = shellmdl_load_datapreprocessing_results(options, paths)
% [] = shellmdl_load_datapreprocessing_results(options, paths)
%
% shellmdl_load_datapreprocessing_results is a function called by
% shellmdl_master, which copies the previously obtained results from
% paths.previousresultsdir (the folder where those files should be stored)
% into paths.resultsdir (the new results folder). In doing so, this
% function generates (or overwrites) the results (that would be) obtained
% by running the data-preprocessing pipeline, allowing to minimize
% computation time. To run this function, instead of the full
% data-preprocessing pipeline, options.load.datapreprocessing and
% options.run.datapreprocessing should be set to 1 and 0, respectively, in
% shellmdl_set_analysis_options.
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  shellmdl_paths
%
% Author: Vasco A. Concei��o
%
% Last modified: November 2023

%% Settings
prDir = [paths.previousresultsdir filesep 'datapreprocessing'];                     % previous results folder

prDir_individ   = [prDir filesep 'individ'];
prDir_all       = [prDir filesep 'all'];
prDir_drug      = [prDir filesep 'drug'];
prDir_placebo   = [prDir filesep 'placebo'];

%% Main Code - Initialization
if ~exist(prDir, 'dir')
    mkdir(prDir);
end;
if ~exist(prDir_individ, 'dir')
    mkdir(prDir_individ);
end;
if ~exist(prDir_all, 'dir')
    mkdir(prDir_all);
end;
if ~exist(prDir_drug, 'dir')
    mkdir(prDir_drug);
end;
if ~exist(prDir_placebo, 'dir')
    mkdir(prDir_placebo);
end;

if options.verbose.datapreprocessing
    disp(' ');
    disp('--------------------------------------------------------------');
    disp('Running shellmdl_load_datapreprocessing_results...');
end;

%% Main Code - Copy the output files from shellmdl_(loop_)preprocess_subj_behav_data
for iSubject = 1:options.dataset.nEffSubjects
    subject = options.dataset.subjects(iSubject);
    paths   = shellmdl_paths(paths, 1, subject);
    
    rDir    = paths.results.subjects.tempsubject.behavior.tempsession.preprocdir;   % results folder
    rFile   = paths.results.subjects.tempsubject.behavior.tempsession.preprocfile;  % results file
    % copyfile(rFile, prDir_individ); % this line is commented intentionally; it was ran to obtain the previous results files
    
    prFile  = [prDir_individ filesep ['behav_data_' num2str(subject) '.mat']];    	% previous results file
    if ~exist(rDir, 'dir')
        mkdir(rDir);
    end;
    copyfile(prFile, rDir);
end;

%% Main Code - Copy the output files from shellmdl_aggreg_preprocess_subj_behav_data
paths = shellmdl_paths(paths, 1);

rDir_all        = paths.results.group.behavior.tempsession.all.preprocdir;
rDir_drug       = paths.results.group.behavior.tempsession.drug.preprocdir;
rDir_placebo    = paths.results.group.behavior.tempsession.placebo.preprocdir;
rFile_all       = paths.results.group.behavior.tempsession.all.preprocfile;
rFile_drug      = paths.results.group.behavior.tempsession.drug.preprocfile;
rFile_placebo   = paths.results.group.behavior.tempsession.placebo.preprocfile;
% copyfile(rFile_all, prDir_all);         % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFile_drug, prDir_drug);       % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFile_placebo, prDir_placebo); % this line is commented intentionally; it was ran to obtain the previous results files

prFile_all      = [prDir_all filesep 'group_behav_data.mat'];
prFile_drug     = [prDir_drug filesep 'group_behav_data.mat'];
prFile_placebo  = [prDir_placebo filesep 'group_behav_data.mat'];
if ~exist(rDir_all, 'dir')
    mkdir(rDir_all);
end;
if ~exist(rDir_drug, 'dir')
    mkdir(rDir_drug);
end;
if ~exist(rDir_placebo, 'dir')
    mkdir(rDir_placebo);
end;
copyfile(prFile_all, rDir_all);
copyfile(prFile_drug, rDir_drug);
copyfile(prFile_placebo, rDir_placebo);

rDir2          	= paths.results.group.behavior2model.tempsessiondir;
rFileStim       = paths.results.group.behavior2model.tempsession.stimfile;  	%%% before, this file was named stims_m; errors may occur until this is replaced everywhere
rFileActions    = paths.results.group.behavior2model.tempsession.actionsfile;
rFileReinfs     = paths.results.group.behavior2model.tempsession.reinfsfile;
rFileReinfsIfGo = paths.results.group.behavior2model.tempsession.reinfsIfGofile;
rFileRTs       	= paths.results.group.behavior2model.tempsession.RTsfile;
% copyfile(rFileStim, prDir_all);       % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFileActions, prDir_all);    % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFileReinfs, prDir_all);     % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFileReinfsIfGo, prDir_all); % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFileRTs, prDir_all);        % this line is commented intentionally; it was ran to obtain the previous results files

prFileStim          = [prDir_all filesep 'stim_m.mat'];
prFileActions       = [prDir_all filesep 'actions_m.mat'];
prFileReinfs        = [prDir_all filesep 'reinfs_m.mat'];
prFileReinfsIfGo    = [prDir_all filesep 'reinfsIfGo_m.mat'];
prFileRTs           = [prDir_all filesep 'RTs_m.mat'];
if ~exist(rDir2, 'dir')
    mkdir(rDir2);
end;
copyfile(prFileStim, rDir2);
copyfile(prFileActions, rDir2);
copyfile(prFileReinfs, rDir2);
copyfile(prFileReinfsIfGo, rDir2);
copyfile(prFileRTs, rDir2);

%% Main Code - Copy the output files from shellmdl_loop_preprocess_trace_behav_data
for iSubject = 1:options.dataset.nEffSubjects
    subject = options.dataset.subjects(iSubject);
    paths   = shellmdl_paths(paths, 0, subject); % session is irrelevant; thus, the 0
    
    rDir    = paths.results.subjects.tempsubject.tracedir;
    rFile   = paths.results.subjects.tempsubject.tracefile;
    % copyfile(rFile, prDir_individ); % this line is commented intentionally; it was ran to obtain the previous results files
    
    prFile  = [prDir_individ filesep ['trace_data_' num2str(subject) '.mat']];
    if ~exist(rDir, 'dir')
        mkdir(rDir);
    end;
    copyfile(prFile, rDir);
end;

%% Main Code - Copy the output files from shellmdl_aggreg_preprocess_trace_behav_data
rDir            = paths.results.group.behavior2modeldir;
rFileStim       = [rDir filesep 'stim_m.mat'];          % overwrites stim_m generated by shellmdl_aggreg_preprocess_subj_behav_data; not a problem, as they are equal
rFileStates     = [rDir filesep 'states_m.mat'];
rFilePhases     = [rDir filesep 'phases_m.mat'];
rFileReinfsIfGo = [rDir filesep 'reinfsIfGo_m.mat'];    % overwrites reinfsIfGo_m generated by shellmdl_aggreg_preprocess_subj_behav_data; not a problem, as they are equal
% copyfile(rFileStim, prDir_all);       % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFileStates, prDir_all);     % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFilePhases, prDir_all);     % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFileReinfsIfGo, prDir_all); % this line is commented intentionally; it was ran to obtain the previous results files

prFileStim          = [prDir_all filesep 'stim_m.mat'];
prFileStates        = [prDir_all filesep 'states_m.mat'];
prFilePhases        = [prDir_all filesep 'phases_m.mat'];
prFileReinfsIfGo    = [prDir_all filesep 'reinfsIfGo_m.mat'];
if ~exist(rDir, 'dir')
    mkdir(rDir);
end;
copyfile(prFileStim, rDir);
copyfile(prFileStates, rDir);
copyfile(prFilePhases, rDir);
copyfile(prFileReinfsIfGo, rDir);

%% Main Code - Copy the output files from shellmdl_preprocess_demog_drug_quest_info
rDirAges                    = paths.results.group.demographicsdir;
rDirEscitalopram            = paths.results.group.drugdir;
rDirOcir                    = paths.results.group.questionnairesdir;

rFileAges                   = [rDirAges filesep 'ages.mat'];
rFileEscitalopramLevels     = [rDirEscitalopram filesep 'escitalopramLevels.mat'];
rFileEscitalopramGroup      = [rDirEscitalopram filesep 'escitalopramGroup.mat'];
rFileOcirScores             = [rDirOcir filesep 'ocirScores.mat'];
rFileOcirObsessingScores    = [rDirOcir filesep 'ocirObsessingScores.mat'];
rFileOcirOtherScores        = [rDirOcir filesep 'ocirOtherScores.mat'];
% copyfile(rFileAges, prDir_all);                % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFileEscitalopramLevels, prDir_all);  % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFileEscitalopramGroup, prDir_all);   % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFileOcirScores, prDir_all);          % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFileOcirObsessingScores, prDir_all); % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFileOcirOtherScores, prDir_all);     % this line is commented intentionally; it was ran to obtain the previous results files

prFileAges                   = [prDir_all filesep 'ages.mat'];
prFileEscitalopramLevels     = [prDir_all filesep 'escitalopramLevels.mat'];
prFileEscitalopramGroup      = [prDir_all filesep 'escitalopramGroup.mat'];
prFileOcirScores             = [prDir_all filesep 'ocirScores.mat'];
prFileOcirObsessingScores    = [prDir_all filesep 'ocirObsessingScores.mat'];
prFileOcirOtherScores        = [prDir_all filesep 'ocirOtherScores.mat'];
if ~exist(rDirAges, 'dir')
    mkdir(rDirAges);
end;
if ~exist(rDirEscitalopram, 'dir')
    mkdir(rDirEscitalopram);
end;
if ~exist(rDirOcir, 'dir')
    mkdir(rDirOcir);
end;
copyfile(prFileAges, rDirAges);
copyfile(prFileEscitalopramLevels, rDirEscitalopram);
copyfile(prFileEscitalopramGroup, rDirEscitalopram);
copyfile(prFileOcirScores, rDirOcir);
copyfile(prFileOcirObsessingScores, rDirOcir);
copyfile(prFileOcirOtherScores, rDirOcir);

end