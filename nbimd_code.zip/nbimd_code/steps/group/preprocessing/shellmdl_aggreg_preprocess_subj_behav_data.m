function [] = shellmdl_aggreg_preprocess_subj_behav_data(options, paths)
% [] = shellmdl_aggreg_preprocess_subj_behav_data(options, paths)
% 
% shellmdl_aggreg_preprocess_subj_behav_data is a function called by 
% shellmdl_master, which loops across the previously created 
% subject-specific files with the preprocessed data. It creates several 
% output files, where such information is clustered by group. Those output 
% files are stored inside both the 'behavior' and 'behavior2model' folders, 
% so that they can then be used for both model-free behavioral analysis and 
% model fitting (and subsequent model-based behavioral analysis).
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  shellmdl_paths
%
% Author: Vasco A. Concei��o
%
% Last modified: September 2023

%% Main Code
if options.verbose.datapreprocessing
    disp(' ');
    disp('--------------------------------------------------------------');
    disp('Running shellmdl_aggreg_preprocess_subj_behav_data...');
end;

stim_m          = -Inf * ones(options.dataset.nSubjects, options.dataset.nTrials);
actions_m       = -Inf * ones(options.dataset.nSubjects, options.dataset.nTrials);
reinfs_m        = -Inf * ones(options.dataset.nSubjects, options.dataset.nTrials);
reinfsIfGo_m    = -Inf * ones(options.dataset.nSubjects, options.dataset.nTrials);
RTs_m           = -Inf * ones(options.dataset.nSubjects, options.dataset.nTrials);

paths = shellmdl_paths(paths, 1);

[onDrugSubjects_num, onDrugSubjects_txt] = xlsread(paths.data.preproc.maingroupdatafile);
onDrugSubjects_txt  = onDrugSubjects_txt(2:end, :);
offDrugSubjects_txt = onDrugSubjects_txt(find(onDrugSubjects_num(:, end) == 0), 1);
onDrugSubjects_txt  = onDrugSubjects_txt(find(onDrugSubjects_num(:, end)), 1);
offDrugSubjects     = -1 * ones(numel(offDrugSubjects_txt), 1);
onDrugSubjects      = -1 * ones(numel(onDrugSubjects_txt), 1);

for i = 1:numel(onDrugSubjects_txt)
    onDrugSubjects_txt{i}   = onDrugSubjects_txt{i}(2:end);
    onDrugSubjects(i)       = str2double(onDrugSubjects_txt{i});    
end;
for i = 1:numel(offDrugSubjects_txt)
    offDrugSubjects_txt{i}  = offDrugSubjects_txt{i}(2:end);
    offDrugSubjects(i)      = str2double(offDrugSubjects_txt{i});
end;

onDrugSubjects      = onDrugSubjects(~ismember(onDrugSubjects, options.dataset.excludedSubjects));
offDrugSubjects     = offDrugSubjects(~ismember(offDrugSubjects, options.dataset.excludedSubjects));

outputDirAll        = paths.results.group.behavior.tempsession.all.preprocdir;
outputDirDrug       = paths.results.group.behavior.tempsession.drug.preprocdir;
outputDirPlacebo    = paths.results.group.behavior.tempsession.placebo.preprocdir;

outputFileAll       = paths.results.group.behavior.tempsession.all.preprocfile;
outputFileDrug      = paths.results.group.behavior.tempsession.drug.preprocfile;
outputFilePlacebo   = paths.results.group.behavior.tempsession.placebo.preprocfile;

for iSubject = 1:options.dataset.nEffSubjects
    subject = options.dataset.subjects(iSubject);
    
    paths = shellmdl_paths(paths, 1, subject);
    
    inputFile   = paths.results.subjects.tempsubject.behavior.tempsession.preprocfile;
    load(inputFile);
    
    stim_m(subject, :)          = D.preproc.stim;
    actions_m(subject, :)       = options.dataset.nActions - D.preproc.gonogo;
    reinfs_m(subject, :)        = D.preproc.feedback;
    reinfsIfGo_m(subject, :)    = D.preproc.feedbackIfGo;
    RTs_m (subject, :)          = D.preproc.rt;
end;

all_behav_data.stim_m           = stim_m(options.dataset.subjects, :);
all_behav_data.actions_m        = actions_m(options.dataset.subjects, :);
all_behav_data.reinfs_m         = reinfs_m(options.dataset.subjects, :);
all_behav_data.reinfsIfGo_m     = reinfsIfGo_m(options.dataset.subjects, :);
all_behav_data.RTs_m            = RTs_m(options.dataset.subjects, :);

drug_behav_data.stim_m          = stim_m(onDrugSubjects, :);
drug_behav_data.actions_m       = actions_m(onDrugSubjects, :);
drug_behav_data.reinfs_m        = reinfs_m(onDrugSubjects, :);
drug_behav_data.reinfsIfGo_m    = reinfsIfGo_m(onDrugSubjects, :);
drug_behav_data.RTs_m           = RTs_m(onDrugSubjects, :);

placebo_behav_data.stim_m       = stim_m(offDrugSubjects, :);
placebo_behav_data.actions_m    = actions_m(offDrugSubjects, :);
placebo_behav_data.reinfs_m     = reinfs_m(offDrugSubjects, :);
placebo_behav_data.reinfsIfGo_m = reinfsIfGo_m(offDrugSubjects, :);
placebo_behav_data.RTs_m        = RTs_m(offDrugSubjects, :);

%% Saving
saveBool = options.save.datapreprocessing;
if saveBool
    if ~exist(paths.results.group.behavior2model.tempsessiondir, 'dir')
        mkdir(paths.results.group.behavior2model.tempsessiondir);
    end;
    if ~exist(outputDirAll, 'dir')
        mkdir(outputDirAll);
    end;
    if ~exist(outputDirDrug, 'dir')
        mkdir(outputDirDrug);
    end;
    if ~exist(outputDirPlacebo, 'dir')
        mkdir(outputDirPlacebo);
    end;
    
    overwriteBool = options.overwrite.datapreprocessing;
    if overwriteBool || ~exist([paths.results.group.behavior2model.tempsessiondir filesep 'stim_m.mat'], 'file')
        if options.verbose.datapreprocessing
            disp(' Results from shellmdl_aggreg_preprocess_subj_behav_data were overwritten.');
        end;
        save(paths.results.group.behavior2model.tempsession.stimfile,       'stim_m');
        save(paths.results.group.behavior2model.tempsession.actionsfile,    'actions_m');
        save(paths.results.group.behavior2model.tempsession.reinfsfile,     'reinfs_m');
        save(paths.results.group.behavior2model.tempsession.reinfsIfGofile, 'reinfsIfGo_m');
        save(paths.results.group.behavior2model.tempsession.RTsfile,        'RTs_m');
        
        save(outputFileAll,     'all_behav_data');
        save(outputFileDrug,    'drug_behav_data');
        save(outputFilePlacebo, 'placebo_behav_data');
        
    else %%% seems to be working well, but non-overwritten files won't be used in the ensuing analyses steps unless the code is further changed
        if options.verbose.datapreprocessing
            disp(' Results from shellmdl_aggreg_preprocess_subj_behav_data were saved, but not overwritten.');
        end;
        
        b = exist([paths.results.group.behavior2model.tempsessiondir filesep 'stim_m.mat'], 'file'); fileCounter = 1;
        while b
            b = exist([paths.results.group.behavior2model.tempsessiondir filesep 'stim_m' '_' num2str(fileCounter) '.mat'], 'file');
            fileCounter = fileCounter + 1;
        end;
        save([paths.results.group.behavior2model.tempsessiondir filesep 'stim_m_' num2str(fileCounter - 1) '.mat'], 'stim_m');
        save([paths.results.group.behavior2model.tempsessiondir filesep 'actions_m_' num2str(fileCounter - 1) '.mat'], 'actions_m');
        save([paths.results.group.behavior2model.tempsessiondir filesep 'reinfs_m_' num2str(fileCounter - 1) '.mat'], 'reinfs_m');
        save([paths.results.group.behavior2model.tempsessiondir filesep 'reinfsIfGo_m_' num2str(fileCounter - 1) '.mat'], 'reinfsIfGo_m');
        save([paths.results.group.behavior2model.tempsessiondir filesep 'RTs_m_' num2str(fileCounter - 1) '.mat'], 'RTs_m');
        
        save([outputFileAll(1:(end-4)) '_' num2str(fileCounter - 1) '.mat'], 'all_behav_data');
        save([outputFileDrug(1:(end-4)) '_' num2str(fileCounter - 1) '.mat'], 'drug_behav_data');
        save([outputFilePlacebo(1:(end-4)) '_' num2str(fileCounter - 1) '.mat'], 'placebo_behav_data');
    end;
    
else
    if options.verbose.datapreprocessing
        disp(' Results from shellmdl_aggreg_preprocess_subj_behav_data were not saved.');
    end;
end;
end