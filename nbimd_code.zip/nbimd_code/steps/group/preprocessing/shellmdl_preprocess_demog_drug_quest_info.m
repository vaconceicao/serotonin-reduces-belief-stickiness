function [] = shellmdl_preprocess_demog_drug_quest_info(options, paths)
% [] = shellmdl_preprocess_demog_drug_quest_info(options, paths)
%
% shellmdl_preprocess_demog_drug_quest_info is a function called in 
% shellmdl_master that preprocesses and saves demographic (age), drug 
% (escitalopram), and questionnaire (OCI-R) information, while confirming 
% that the two groups (on- and off-escitalopram) were balanced in terms of 
% age and OCI-R scores.
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  [none]
%
% Author: Vasco A. Concei��o
%
% Last modified: September 2023

%% Main Code
if options.verbose.datapreprocessing
    disp(' ');
    disp('--------------------------------------------------------------');
    disp('Running shellmdl_preprocess_demog_drug_quest_info...');
end;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[questAux, questAux_txt] = xlsread(paths.data.preproc.ocirgroupdatafile);

anonIDs_aux             = questAux_txt(2:end, 1);
anonIDs                 = -Inf * ones(numel(anonIDs_aux), 1);
for iSubj = 1:numel(anonIDs)
    anonIDs(iSubj) = str2double(anonIDs_aux{iSubj}(2:end));
end;

ocirScores_all          	= questAux(:, end);
ocirWashingScores_all       = questAux(:, end - 6);
ocirObsessingScores_all     = questAux(:, end - 5);
ocirHoardingScores_all      = questAux(:, end - 4);
ocirOrderingScores_all      = questAux(:, end - 3);
ocirCheckingScores_all      = questAux(:, end - 2);
ocirNeutralizingScores_all  = questAux(:, end - 1);

ocirScores                  = ocirScores_all(~ismember(anonIDs, options.dataset.excludedSubjects));
ocirWashingScores           = ocirWashingScores_all(~ismember(anonIDs, options.dataset.excludedSubjects));
ocirObsessingScores         = ocirObsessingScores_all(~ismember(anonIDs, options.dataset.excludedSubjects));
ocirHoardingScores          = ocirHoardingScores_all(~ismember(anonIDs, options.dataset.excludedSubjects));
ocirOrderingScores          = ocirOrderingScores_all(~ismember(anonIDs, options.dataset.excludedSubjects));
ocirCheckingScores          = ocirCheckingScores_all(~ismember(anonIDs, options.dataset.excludedSubjects));
ocirNeutralizingScores      = ocirNeutralizingScores_all(~ismember(anonIDs, options.dataset.excludedSubjects));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[dataAux, dataAux_txt]      = xlsread(paths.data.preproc.maingroupdatafile);

dataAux_txt                 = dataAux_txt(2:end, :);

anonIDs_aux                 = dataAux_txt(:, 1);
anonIDs                     = -Inf * ones(numel(anonIDs_aux), 1);
for iSubj = 1:numel(anonIDs)
    anonIDs(iSubj) = str2double(anonIDs_aux{iSubj}(2:end));
end;

ages_all                  	= dataAux(:, 1);
ages                        = ages_all(~ismember(anonIDs, options.dataset.excludedSubjects));

escitalopramLevels_t1       = -Inf * ones(numel(anonIDs), 1);
escitalopramLevels_t2       = -Inf * ones(numel(anonIDs), 1);

for iSubj = 1:numel(anonIDs)
    escitalopramLevels_t1(iSubj) = str2double(dataAux_txt{iSubj, 5});
    escitalopramLevels_t2(iSubj) = str2double(dataAux_txt{iSubj, 7});
    if isnan(escitalopramLevels_t1(iSubj))
        escitalopramLevels_t1(iSubj) = 2.5; %%% see manuscript for rationale
    end;
    if isnan(escitalopramLevels_t2(iSubj))
        escitalopramLevels_t2(iSubj) = 2.5; %%% see manuscript for rationale
    end;
end;

offDrugSubjects_indices = find(1 - dataAux(:, end));
onDrugSubjects_indices 	= find(dataAux(:, end));

escitalopramLevels_all  = escitalopramLevels_t1 + (escitalopramLevels_t2 - escitalopramLevels_t1) .* ...
    (dataAux(:, 2) - dataAux(:, 3)) ./ (dataAux(:, 5) - dataAux(:, 3));         % perform linear interpolation of escitalopram values
escitalopramLevels_all(offDrugSubjects_indices)	= 0;                            % correct for on-placebo subjects

offDrugSubjects_all     = anonIDs(offDrugSubjects_indices);
onDrugSubjects_all      = anonIDs(onDrugSubjects_indices);

offDrugSubjects         = offDrugSubjects_all(~ismember(offDrugSubjects_all, options.dataset.excludedSubjects));
onDrugSubjects          = onDrugSubjects_all(~ismember(onDrugSubjects_all, options.dataset.excludedSubjects));
escitalopramLevels      = escitalopramLevels_all(~ismember(anonIDs, options.dataset.excludedSubjects));

offDrugSubjects_indices = offDrugSubjects_indices(~ismember(offDrugSubjects_all, options.dataset.excludedSubjects));
onDrugSubjects_indices 	= onDrugSubjects_indices(~ismember(onDrugSubjects_all, options.dataset.excludedSubjects));

if options.verbose.datapreprocessing
    onDrugSubjects
    disp(['Group 1 had ' num2str(numel(onDrugSubjects)) ' subjects']);
end;

if options.verbose.datapreprocessing
    offDrugSubjects
    disp(['Group 2 had ' num2str(numel(offDrugSubjects)) ' subjects']);
end;

%% Assess drug-levels
if options.verbose.datapreprocessing
    disp(' ');
    disp(['The mean escitalopram levels of subjects from group 1 was: ' num2str(round(mean(escitalopramLevels_all(onDrugSubjects_indices)), 3))]);
    disp(['The std for escitalopram levels of subjects from group 1 was: ' num2str(round(std(escitalopramLevels_all(onDrugSubjects_indices)), 3))]);
end;

%% Assess OCI-R scores
onDrugSubjects2_indices     = onDrugSubjects_indices(~ismember(onDrugSubjects, options.questionnaires.additionalExcludedSubjects));
offDrugSubjects2_indices    = offDrugSubjects_indices(~ismember(offDrugSubjects, options.questionnaires.additionalExcludedSubjects));

% Total Scores
if options.verbose.datapreprocessing
    disp(' ');
    disp(['The mean OCI-R scores of subjects from groups 1 and 2 were respectively: ' num2str(round(mean(ocirScores_all(onDrugSubjects2_indices)), 3)) ...
        ' and ' num2str(round(mean(ocirScores_all(offDrugSubjects2_indices)), 3))]);
    disp(['The std for OCI-R scores of subjects from groups 1 and 2 were respectively: ' num2str(round(std(ocirScores_all(onDrugSubjects2_indices)), 3)) ...
        ' and ' num2str(round(std(ocirScores_all(offDrugSubjects2_indices)), 3))]);
    disp('When testing whether the 2 groups differed...');
end;

[h_0, p_0] = lillietest([ocirScores_all(onDrugSubjects2_indices); ocirScores_all(offDrugSubjects2_indices)]);
[h_1, p_1] = lillietest(ocirScores_all(onDrugSubjects2_indices));
[h_2, p_2] = lillietest(ocirScores_all(offDrugSubjects2_indices));
h_sum = h_0 + h_1 + h_2;

if h_sum % that is, if data is not normally distributed:
    [p_ranksum, ~] = ranksum(ocirScores_all(onDrugSubjects2_indices), ocirScores_all(offDrugSubjects2_indices));
    if options.verbose.datapreprocessing
        p_ranksum
    end;
    
else                    % if data is not normally distributed and...
    p_var = vartestn([ocirScores_all(onDrugSubjects2_indices); ocirScores_all(offDrugSubjects2_indices)], [ones(size(onDrugSubjects2_indices)); 2 * ones(size(offDrugSubjects2_indices))]);
    if p_var > 0.05     % ... the variances are similar:
        [~, p_ttest2] = ttest2(ocirScores_all(onDrugSubjects2_indices), ocirScores_all(offDrugSubjects2_indices));
        if options.verbose.datapreprocessing
            p_ttest2
        end;
    else                % ... the variances are unequal:
        [~, p_ttest2_unequal_var] = ttest2(ocirScores_all(onDrugSubjects2_indices), ocirScores_all(offDrugSubjects2_indices), 'Vartype', 'unequal');
        if options.verbose.datapreprocessing
            p_ttest2_unequal_var
        end;
    end;
end;

% Washing Scores
if options.verbose.datapreprocessing
    disp(' ');
    disp(['The mean OCI-R Washing scores of subjects from groups 1 and 2 were respectively: ' num2str(round(mean(ocirWashingScores_all(onDrugSubjects2_indices)), 3)) ...
        ' and ' num2str(round(mean(ocirWashingScores_all(offDrugSubjects2_indices)), 3))]);
    disp(['The std for OCI-R Washing scores of subjects from groups 1 and 2 were respectively: ' num2str(round(std(ocirWashingScores_all(onDrugSubjects2_indices)), 3)) ...
        ' and ' num2str(round(std(ocirWashingScores_all(offDrugSubjects2_indices)), 3))]);
    disp('When testing whether the 2 groups differed...');
end;

[h_0, p_0] = lillietest([ocirWashingScores_all(onDrugSubjects2_indices); ocirWashingScores_all(offDrugSubjects2_indices)]);
[h_1, p_1] = lillietest(ocirWashingScores_all(onDrugSubjects2_indices));
[h_2, p_2] = lillietest(ocirWashingScores_all(offDrugSubjects2_indices));
h_sum = h_0 + h_1 + h_2;

if h_sum % that is, if data is not normally distributed:
    [p_ranksum, ~] = ranksum(ocirWashingScores_all(onDrugSubjects2_indices), ocirWashingScores_all(offDrugSubjects2_indices));
    if options.verbose.datapreprocessing
        p_ranksum
    end;
    
else                    % if data is not normally distributed and...
    p_var = vartestn([ocirWashingScores_all(onDrugSubjects2_indices); ocirWashingScores_all(offDrugSubjects2_indices)], [ones(size(onDrugSubjects2_indices)); 2 * ones(size(offDrugSubjects2_indices))]);
    if p_var > 0.05     % ... the variances are similar:
        [~, p_ttest2] = ttest2(ocirWashingScores_all(onDrugSubjects2_indices), ocirWashingScores_all(offDrugSubjects2_indices));
        if options.verbose.datapreprocessing
            p_ttest2
        end;
    else                % ... the variances are unequal:
        [~, p_ttest2_unequal_var] = ttest2(ocirWashingScores_all(onDrugSubjects2_indices), ocirWashingScores_all(offDrugSubjects2_indices), 'Vartype', 'unequal');
        if options.verbose.datapreprocessing
            p_ttest2_unequal_var
        end;
    end;
end;

% Obsessing Scores
if options.verbose.datapreprocessing
    disp(' ');
    disp(['The mean OCI-R Obsessing scores of subjects from groups 1 and 2 were respectively: ' num2str(round(mean(ocirObsessingScores_all(onDrugSubjects2_indices)), 3)) ...
        ' and ' num2str(round(mean(ocirObsessingScores_all(offDrugSubjects2_indices)), 3))]);
    disp(['The std for OCI-R Obsessing scores of subjects from groups 1 and 2 were respectively: ' num2str(round(std(ocirObsessingScores_all(onDrugSubjects2_indices)), 3)) ...
        ' and ' num2str(round(std(ocirObsessingScores_all(offDrugSubjects2_indices)), 3))]);
    disp('When testing whether the 2 groups differed...');
end;

[h_0, p_0] = lillietest([ocirObsessingScores_all(onDrugSubjects2_indices); ocirObsessingScores_all(offDrugSubjects2_indices)]);
[h_1, p_1] = lillietest(ocirObsessingScores_all(onDrugSubjects2_indices));
[h_2, p_2] = lillietest(ocirObsessingScores_all(offDrugSubjects2_indices));
h_sum = h_0 + h_1 + h_2;

if h_sum % that is, if data is not normally distributed:
    [p_ranksum, ~] = ranksum(ocirObsessingScores_all(onDrugSubjects2_indices), ocirObsessingScores_all(offDrugSubjects2_indices));
    if options.verbose.datapreprocessing
        p_ranksum
    end;
    
else                    % if data is not normally distributed and...
    p_var = vartestn([ocirObsessingScores_all(onDrugSubjects2_indices); ocirObsessingScores_all(offDrugSubjects2_indices)], [ones(size(onDrugSubjects2_indices)); 2 * ones(size(offDrugSubjects2_indices))]);
    if p_var > 0.05     % ... the variances are similar:
        [~, p_ttest2] = ttest2(ocirObsessingScores_all(onDrugSubjects2_indices), ocirObsessingScores_all(offDrugSubjects2_indices));
        if options.verbose.datapreprocessing
            p_ttest2
        end;
    else                % ... the variances are unequal:
        [~, p_ttest2_unequal_var] = ttest2(ocirObsessingScores_all(onDrugSubjects2_indices), ocirObsessingScores_all(offDrugSubjects2_indices), 'Vartype', 'unequal');
        if options.verbose.datapreprocessing
            p_ttest2_unequal_var
        end;
    end;
end;

% Hoarding Scores
if options.verbose.datapreprocessing
    disp(' ');
    disp(['The mean OCI-R Hoarding scores of subjects from groups 1 and 2 were respectively: ' num2str(round(mean(ocirHoardingScores_all(onDrugSubjects2_indices)), 3)) ...
        ' and ' num2str(round(mean(ocirHoardingScores_all(offDrugSubjects2_indices)), 3))]);
    disp(['The std for OCI-R Hoarding scores of subjects from groups 1 and 2 were respectively: ' num2str(round(std(ocirHoardingScores_all(onDrugSubjects2_indices)), 3)) ...
        ' and ' num2str(round(std(ocirHoardingScores_all(offDrugSubjects2_indices)), 3))]);
    disp('When testing whether the 2 groups differed...');
end;

[h_0, p_0] = lillietest([ocirHoardingScores_all(onDrugSubjects2_indices); ocirHoardingScores_all(offDrugSubjects2_indices)]);
[h_1, p_1] = lillietest(ocirHoardingScores_all(onDrugSubjects2_indices));
[h_2, p_2] = lillietest(ocirHoardingScores_all(offDrugSubjects2_indices));
h_sum = h_0 + h_1 + h_2;

if h_sum % that is, if data is not normally distributed:
    [p_ranksum, ~] = ranksum(ocirHoardingScores_all(onDrugSubjects2_indices), ocirHoardingScores_all(offDrugSubjects2_indices));
    if options.verbose.datapreprocessing
        p_ranksum
    end;
    
else                    % if data is not normally distributed and...
    p_var = vartestn([ocirHoardingScores_all(onDrugSubjects2_indices); ocirHoardingScores_all(offDrugSubjects2_indices)], [ones(size(onDrugSubjects2_indices)); 2 * ones(size(offDrugSubjects2_indices))]);
    if p_var > 0.05     % ... the variances are similar:
        [~, p_ttest2] = ttest2(ocirHoardingScores_all(onDrugSubjects2_indices), ocirHoardingScores_all(offDrugSubjects2_indices));
        if options.verbose.datapreprocessing
            p_ttest2
        end;
    else                % ... the variances are unequal:
        [~, p_ttest2_unequal_var] = ttest2(ocirHoardingScores_all(onDrugSubjects2_indices), ocirHoardingScores_all(offDrugSubjects2_indices), 'Vartype', 'unequal');
        if options.verbose.datapreprocessing
            p_ttest2_unequal_var
        end;
    end;
end;

% Ordering Scores
if options.verbose.datapreprocessing
    disp(' ');
    disp(['The mean OCI-R Ordering scores of subjects from groups 1 and 2 were respectively: ' num2str(round(mean(ocirOrderingScores_all(onDrugSubjects2_indices)), 3)) ...
        ' and ' num2str(round(mean(ocirOrderingScores_all(offDrugSubjects2_indices)), 3))]);
    disp(['The std for OCI-R Ordering scores of subjects from groups 1 and 2 were respectively: ' num2str(round(std(ocirOrderingScores_all(onDrugSubjects2_indices)), 3)) ...
        ' and ' num2str(round(std(ocirOrderingScores_all(offDrugSubjects2_indices)), 3))]);
    disp('When testing whether the 2 groups differed...');
end;

[h_0, p_0] = lillietest([ocirOrderingScores_all(onDrugSubjects2_indices); ocirOrderingScores_all(offDrugSubjects2_indices)]);
[h_1, p_1] = lillietest(ocirOrderingScores_all(onDrugSubjects2_indices));
[h_2, p_2] = lillietest(ocirOrderingScores_all(offDrugSubjects2_indices));
h_sum = h_0 + h_1 + h_2;

if h_sum % that is, if data is not normally distributed:
    [p_ranksum, ~] = ranksum(ocirOrderingScores_all(onDrugSubjects2_indices), ocirOrderingScores_all(offDrugSubjects2_indices));
    if options.verbose.datapreprocessing
        p_ranksum
    end;
    
else                    % if data is not normally distributed and...
    p_var = vartestn([ocirOrderingScores_all(onDrugSubjects2_indices); ocirOrderingScores_all(offDrugSubjects2_indices)], [ones(size(onDrugSubjects2_indices)); 2 * ones(size(offDrugSubjects2_indices))]);
    if p_var > 0.05     % ... the variances are similar:
        [~, p_ttest2] = ttest2(ocirOrderingScores_all(onDrugSubjects2_indices), ocirOrderingScores_all(offDrugSubjects2_indices));
        if options.verbose.datapreprocessing
            p_ttest2
        end;
    else                % ... the variances are unequal:
        [~, p_ttest2_unequal_var] = ttest2(ocirOrderingScores_all(onDrugSubjects2_indices), ocirOrderingScores_all(offDrugSubjects2_indices), 'Vartype', 'unequal');
        if options.verbose.datapreprocessing
            p_ttest2_unequal_var
        end;
    end;
end;

% Checking Scores
if options.verbose.datapreprocessing
    disp(' ');
    disp(['The mean OCI-R Checking scores of subjects from groups 1 and 2 were respectively: ' num2str(round(mean(ocirCheckingScores_all(onDrugSubjects2_indices)), 3)) ...
        ' and ' num2str(round(mean(ocirCheckingScores_all(offDrugSubjects2_indices)), 3))]);
    disp(['The std for OCI-R Checking scores of subjects from groups 1 and 2 were respectively: ' num2str(round(std(ocirCheckingScores_all(onDrugSubjects2_indices)), 3)) ...
        ' and ' num2str(round(std(ocirCheckingScores_all(offDrugSubjects2_indices)), 3))]);
    disp('When testing whether the 2 groups differed...');
end;

[h_0, p_0] = lillietest([ocirCheckingScores_all(onDrugSubjects2_indices); ocirCheckingScores_all(offDrugSubjects2_indices)]);
[h_1, p_1] = lillietest(ocirCheckingScores_all(onDrugSubjects2_indices));
[h_2, p_2] = lillietest(ocirCheckingScores_all(offDrugSubjects2_indices));
h_sum = h_0 + h_1 + h_2;

if h_sum % that is, if data is not normally distributed:
    [p_ranksum, ~] = ranksum(ocirCheckingScores_all(onDrugSubjects2_indices), ocirCheckingScores_all(offDrugSubjects2_indices));
    if options.verbose.datapreprocessing
        p_ranksum
    end;
    
else                    % if data is not normally distributed and...
    p_var = vartestn([ocirCheckingScores_all(onDrugSubjects2_indices); ocirCheckingScores_all(offDrugSubjects2_indices)], [ones(size(onDrugSubjects2_indices)); 2 * ones(size(offDrugSubjects2_indices))]);
    if p_var > 0.05     % ... the variances are similar:
        [~, p_ttest2] = ttest2(ocirCheckingScores_all(onDrugSubjects2_indices), ocirCheckingScores_all(offDrugSubjects2_indices));
        if options.verbose.datapreprocessing
            p_ttest2
        end;
    else                % ... the variances are unequal:
        [~, p_ttest2_unequal_var] = ttest2(ocirCheckingScores_all(onDrugSubjects2_indices), ocirCheckingScores_all(offDrugSubjects2_indices), 'Vartype', 'unequal');
        if options.verbose.datapreprocessing
            p_ttest2_unequal_var
        end;
    end;
end;

% Neutralizing Scores
if options.verbose.datapreprocessing
    disp(' ');
    disp(['The mean OCI-R Neutralizing scores of subjects from groups 1 and 2 were respectively: ' num2str(round(mean(ocirNeutralizingScores_all(onDrugSubjects2_indices)), 3)) ...
        ' and ' num2str(round(mean(ocirNeutralizingScores_all(offDrugSubjects2_indices)), 3))]);
    disp(['The std for OCI-R Neutralizing scores of subjects from groups 1 and 2 were respectively: ' num2str(round(std(ocirNeutralizingScores_all(onDrugSubjects2_indices)), 3)) ...
        ' and ' num2str(round(std(ocirNeutralizingScores_all(offDrugSubjects2_indices)), 3))]);
    disp('When testing whether the 2 groups differed...');
end;

[h_0, p_0] = lillietest([ocirNeutralizingScores_all(onDrugSubjects2_indices); ocirNeutralizingScores_all(offDrugSubjects2_indices)]);
[h_1, p_1] = lillietest(ocirNeutralizingScores_all(onDrugSubjects2_indices));
[h_2, p_2] = lillietest(ocirNeutralizingScores_all(offDrugSubjects2_indices));
h_sum = h_0 + h_1 + h_2;

if h_sum % that is, if data is not normally distributed:
    [p_ranksum, ~] = ranksum(ocirNeutralizingScores_all(onDrugSubjects2_indices), ocirNeutralizingScores_all(offDrugSubjects2_indices));
    if options.verbose.datapreprocessing
        p_ranksum
    end;
    
else                    % if data is not normally distributed and...
    p_var = vartestn([ocirNeutralizingScores_all(onDrugSubjects2_indices); ocirNeutralizingScores_all(offDrugSubjects2_indices)], [ones(size(onDrugSubjects2_indices)); 2 * ones(size(offDrugSubjects2_indices))]);
    if p_var > 0.05     % ... the variances are similar:
        [~, p_ttest2] = ttest2(ocirNeutralizingScores_all(onDrugSubjects2_indices), ocirNeutralizingScores_all(offDrugSubjects2_indices));
        if options.verbose.datapreprocessing
            p_ttest2
        end;
    else                % ... the variances are unequal:
        [~, p_ttest2_unequal_var] = ttest2(ocirNeutralizingScores_all(onDrugSubjects2_indices), ocirNeutralizingScores_all(offDrugSubjects2_indices), 'Vartype', 'unequal');
        if options.verbose.datapreprocessing
            p_ttest2_unequal_var
        end;
    end;
end;

if options.verbose.datapreprocessing
    disp('PS: In the OCI-R-related analyses above, subject 3, who belonged to group 1 but did not fill the OCI-R questionnaire, was excluded!');
end;

%% Asess age
if options.verbose.datapreprocessing
    disp(' ');
    disp(['The mean ages of subjects from groups 1 and 2 were respectively: ' num2str(round(mean(ages_all(onDrugSubjects_indices)), 3)) ...
        ' and ' num2str(round(mean(ages_all(offDrugSubjects_indices)), 3))]);
    disp(['The std for ages of subjects from groups 1 and 2 were respectively: ' num2str(round(std(ages_all(onDrugSubjects_indices)), 3)) ...
        ' and ' num2str(round(std(ages_all(offDrugSubjects_indices)), 3))]);
    disp('When testing whether the 2 groups differed...');
end;

[h_0, p_0] = lillietest([ages_all(onDrugSubjects_indices); ages_all(offDrugSubjects_indices)]);
[h_1, p_1] = lillietest(ages_all(onDrugSubjects_indices));
[h_2, p_2] = lillietest(ages_all(offDrugSubjects_indices));
h_sum = h_0 + h_1 + h_2;

if h_sum % that is, if data is not normally distributed:
    [p_ranksum, ~]  = ranksum(ages_all(onDrugSubjects_indices), ages_all(offDrugSubjects_indices));
    if options.verbose.datapreprocessing
        p_ranksum
    end;
    
else                    % if data is not normally distributed and...
    p_var = vartestn([ages_all(onDrugSubjects_indices); ages_all(offDrugSubjects_indices)], [ones(size(onDrugSubjects_indices)); 2 * ones(size(offDrugSubjects_indices))]);
    if p_var > 0.05     % ... the variances are similar:
        [~, p_ttest2] = ttest2(ages_all(onDrugSubjects_indices), ages_all(offDrugSubjects_indices));
        if options.verbose.datapreprocessing
            p_ttest2
        end;
    else                % ... the variances are unequal:
        [~, p_ttest2_unequal_var] = ttest2(ages_all(onDrugSubjects_indices), ages_all(offDrugSubjects_indices), 'Vartype', 'unequal');
        if options.verbose.datapreprocessing
            p_ttest2_unequal_var
        end;
    end;
end;

if options.verbose.datapreprocessing
    disp(' ');
    disp(['Across all subjects, the mean age was: ' num2str(round(mean(ages_all([onDrugSubjects_indices; offDrugSubjects_indices])), 3))]);
    disp(['Across all subjects, the age std was: ' num2str(round(std(ages_all([onDrugSubjects_indices; offDrugSubjects_indices])), 3))]);
end;

%% Data saving
% Age
agesOutputDir           = paths.results.group.demographicsdir;
if ~exist(agesOutputDir, 'dir')
    mkdir(agesOutputDir);
end;
save([agesOutputDir filesep 'ages.mat'], 'ages');

% Escitalopram
escitalopramOutputDir   = paths.results.group.drugdir;
if ~exist(escitalopramOutputDir, 'dir')
    mkdir(escitalopramOutputDir);
end;
escitalopramGroup       = escitalopramLevels > 0;
save([escitalopramOutputDir filesep 'escitalopramLevels.mat'],  'escitalopramLevels');
save([escitalopramOutputDir filesep 'escitalopramGroup.mat'],   'escitalopramGroup');

% OCI-R
ocirOutputDir        	= paths.results.group.questionnairesdir;
if ~exist(ocirOutputDir, 'dir')
    mkdir(ocirOutputDir);
end;
ocirOtherScores         = ocirScores - ocirObsessingScores;
save([ocirOutputDir filesep 'ocirScores.mat'],      	'ocirScores');
save([ocirOutputDir filesep 'ocirObsessingScores.mat'],	'ocirObsessingScores');
save([ocirOutputDir filesep 'ocirOtherScores.mat'],    	'ocirOtherScores');

end