function [] = shellmdl_perform_cca_permutations(options, paths)
% [] = shellmdl_perform_cca_permutations(options, paths)
%
% shellmdl_perform_cca_permutations is a function called by
% shellmdl_master, which tests the significance of the canonical
% cross-loadings of the canonical correlation (CC) of interest. Such CC is
% implemented both in SPSS and here, and it uses data from the selected
% RL model only.
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  shellmdl_paths
%
% Author: Vasco A. Concei��o, with the help from Anderson Winkler
%
% Last modified: September 2023

%% Settings/Initialization:
nR  = options.selectedmodelsanalysis.nCCAIterations; % number of realisations/iterations
k   = 1; % index of the component for which we want to see the histogram of the loadings and cross-loadings (1, for the 1st canonical variate)

seedNR              = 1; % to ensure that the results will always be the same
rng(seedNR);

outputDir           = paths.results.group.cca.tempsession.alldir;
numData             = xlsread(paths.results.group.cca.tempsession.all.datafile);

state_inf_params    = numData(:, 1:2);          % gamma, zeta
cca_predictors      = numData(:, 3:6);          % escitalopram level, group, OCI-R obsessing, OCI-R other

nY                  = size(state_inf_params, 2);
nX                  = size(cca_predictors, 2);
nSubjects           = size(state_inf_params, 1); % should be 43 (44 - the subject with no OCI-R data)

% Initialise the variables to be populated during the realisations:
rLyu = zeros(nY, nR);
rLxv = zeros(nX, nR);
rLyv = zeros(nY, nR);
rLxu = zeros(nX, nR);

%% Main Code:
if options.verbose.selectedmodelsanalysis
    disp(' ');
    disp('--------------------------------------------------------------');
    disp('Running shellmdl_perform_cca_permutations...');
end;

for r = 0:nR
    if (r > 0) && (mod(r, nR/20) == 0)
        disp([' Running iteration/realisation ' num2str(r) ' out of ' num2str(nR) '...']);
    end;
    
    b = 1;          % this Boolean ensures that we are doing permutations without replacement
    while b
        if r == 0   % this ensures that the true values (obtained without any permutation) are saved too
            Y = state_inf_params;
            X = cca_predictors;
        else
            Y = state_inf_params;
            X = cca_predictors(randperm(nSubjects), :);
        end;
        
        [A_canon, B_canon, r_canon, V, U, stats] = canoncorr(cca_predictors, state_inf_params);
        
        % Loadings and cross-loadings:
        Lyu = corr(Y, U);
        Lxv = corr(X, V);
        Lyv = corr(Y, V);
        Lxu = corr(X, U);
        
        if (ismember(Lyu(1, k), rLyu(1, :)) && ismember(Lxv(1, k), rLxv(1, :)) && ismember(Lyv(1, k), rLyv(1, :)) && ismember(Lxu(1, k), rLxu(1, :)))
            b = 1; % repeat iteration, as the permutation might have been the same (very unlikely, but...)
            disp(['Permutation ' num2str(r) ' was repeated.']);
        else
            b = 0; % no need to repeat iteration, as this was a new permutation (as it should always be)
        end;
    end;
    
    % We want to save the loadings for the k-th component; thus, for the r-th realisation...
    if r > 0    % ... save the values obtained via permutations
        rLyu(:, r)  = Lyu(:, k);
        rLxv(:, r)  = Lxv(:, k);
        rLyv(:, r)  = Lyv(:, k);
        rLxu(:, r)  = Lxu(:, k);
        
    else        % In addition, save the true values (obtained without any permutation):
        tLyu        = Lyu(:,k);
        tLxv        = Lxv(:,k);
        tLyv        = Lyv(:,k);
        tLxu        = Lxu(:,k);
    end;
end;

if options.verbose.selectedmodelsanalysis
    % Display values of interest:
    disp(' ');
    disp('---------------------------------------------------------------------------------');
    disp('The scores on the 1st CV (U) were:'); disp(' ');
    disp(U(:, 1));
    
    disp('---------------------------------------------------------------------------------');
    disp('The loadings (Y, U) were:'); disp(' ');
    disp(tLyu);
    
    disp('---------------------------------------------------------------------------------');
    disp('The loadings (X, V) were:'); disp(' ');
    disp(tLxv);
    
    disp('---------------------------------------------------------------------------------');
    disp('The cross-loadings (Y, V) were:'); disp(' ');
    disp(tLyv);
    
    disp('---------------------------------------------------------------------------------');
    disp('The cross-loadings of interest (X, U) were:'); disp(' ');
    disp(tLxu);
    
    disp(['The mean cross-loadings of interest (X,U) obtained across ' num2str(nR) ' permutation iterations were:']); disp(' ');
    disp(mean(rLxu, 2));
    
    disp('The respective p-values were:');
    p = -Inf * ones(nX, 1);
    for i = 1:nX
        p(i) = sum(abs(rLxu(i, :)) > abs(tLxu(i)))/nR;
    end;
    disp(p);
end;

if options.save.selectedmodelsanalysis && options.overwrite.selectedmodelsanalysis
    if ~exist(outputDir, 'dir')
        mkdir(outputDir);
    end;
    
    results_info = 'The cross-loadings of interest (for escitalopram level, group, OCI-R obsessing, and OCI-R other) are shown in tLxu; p shows the respective p-values. U(:, 1) are the scores on the 1st CV.';
    
    save(paths.results.group.cca.tempsession.all.resultsfile, ...
        'results_info', 'U', ...
        'rLyu', 'rLxv', 'rLyv', 'rLxu', ...
        'tLyu', 'tLxv', 'tLyv', 'tLxu', ...
        'p');
    
    if options.verbose.selectedmodelsanalysis
        disp(' ');
        disp('The data for the CCA analysis was overwritten.');
    end;
end;
end