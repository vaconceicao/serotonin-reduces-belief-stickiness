﻿MANOVA gamma zeta WITH escitalopramLevel escitalopramGroup ocirObsessing ocirOther
/DISCRIM all alpha(1)
/print=SIGNIF(eigen dim)
