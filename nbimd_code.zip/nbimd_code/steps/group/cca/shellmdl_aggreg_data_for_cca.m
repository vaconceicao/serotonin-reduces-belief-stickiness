function [] = shellmdl_aggreg_data_for_cca(options, paths)
% [] = shellmdl_aggreg_data_for_cca(options, paths)
%
% shellmdl_aggreg_data_for_cca is a function called by shellmdl_master,
% which creates the .xls file that will be used to perform the canonical
% correlation analysis (CCA) of interest, using the data from the selected
% RL model. The CCA is implemented in both SPSS and MATLAB 
% (shellmdl_perform_cca_permutations).
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  shellmdl_paths
%
% Author: Vasco A. Concei��o
%
% Last modified: September 2023

%% Settings
agesDir     	= paths.results.group.demographicsdir;
escitalopramDir = paths.results.group.drugdir;
ocirDir         = paths.results.group.questionnairesdir;

paths        	= shellmdl_paths(paths, 1, -1, options.rl.selectedModel, options); % -1 is the subject error code
paramsDir    	= paths.results.group.modelinspection.tempsession.tempmodeldir;

outputDir       = paths.results.group.cca.tempsession.alldir;

%% Main Code
if options.verbose.selectedmodelsanalysis
    disp(' ');
    disp('--------------------------------------------------------------');
    disp('Running shellmdl_aggreg_data_for_cca...');
end;

load([agesDir           filesep     'ages']);
load([escitalopramDir   filesep     'escitalopramLevels']);
load([escitalopramDir   filesep     'escitalopramGroup']);
load([ocirDir           filesep     'ocirObsessingScores']);
load([ocirDir           filesep     'ocirOtherScores']);
load([paramsDir         filesep     'params_m']);

if options.verbose.selectedmodelsanalysis
    disp(' ');
    disp('The correlation between the two state-inference parameters was:');
    [r, p] = corr(params_m(:, 6), params_m(:, 7))           % gamma, zeta
end;

cca_data = -Inf * ones(options.dataset.nEffSubjects, 6);    % y variables: gamma, zeta; x variables: escitalopram level, group (1, if on escitalopram; 0, if not), OCI-R obsessing, OCI-R other

cca_data(:, 1)  = params_m(:, 6);       % gamma
cca_data(:, 2)  = params_m(:, 7);       % zeta

cca_data(:, 3)  = escitalopramLevels; 	% escitalopram level
cca_data(:, 4)  = escitalopramGroup;    % escitalopram group
cca_data(:, 5)  = ocirObsessingScores;  % OCI-R obsessing
cca_data(:, 6)  = ocirOtherScores;      % OCI-R other

cca_data        = cca_data(find(ocirOtherScores > 0), :);  	% remove subject with missing OCI-R data

if options.save.selectedmodelsanalysis && options.overwrite.selectedmodelsanalysis
    if ~exist(outputDir, 'dir')
        mkdir(outputDir);
    end;
    
    if options.overwrite.selectedmodelsanalysis
        try
            delete(paths.results.group.cca.tempsession.all.datafile);
        end;
    end;
    xlswrite(paths.results.group.cca.tempsession.all.datafile, cca_data);
    
    if options.verbose.selectedmodelsanalysis
        disp(' ');
        disp('The data for the CCA analysis was overwritten.');
    end;
end;