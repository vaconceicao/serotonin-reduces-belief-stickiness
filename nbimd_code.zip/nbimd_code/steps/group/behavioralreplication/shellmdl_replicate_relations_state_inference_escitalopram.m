function [] = shellmdl_replicate_relations_state_inference_escitalopram(options, paths)
% [] = shellmdl_replicate_relations_state_inference_escitalopram(options, paths)
%
% shellmdl_replicate_relations_state_inference_escitalopram is a function
% that plots two state-inference behavioral indices [1, the increase in
% p(corr) from phase 2 to phase 4; 2, p(corr) during state revisiting (that
% is, during phases 3 and 4)] as a function of escitalopram plasma levels.
% Such plots correspond to panels A and B of the Supplementary Results
% Figure 3 of the paper.
% In addition, this function executes some analyses regarding the relation 
% between the aforementioned state-inference behavioral indices and the 
% predictors of interest (escitalopram levels, group, OCI-R obsessing 
% scores, and OCI-R other scores), which are complemented by analyses done 
% in R (whose input depends on this function).
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions
%  shellmdl_paths
%
% Author: Vasco A. Concei��o
%
% Last modified: September 2023

%% Init
paths                   = shellmdl_paths(paths, 1);
behavDataFile           = paths.results.group.behavior.tempsession.all.procfile;        % file with the behavioral data from all 44 subjects
escitalopramLevelsFile  = [paths.results.group.drugdir filesep 'escitalopramLevels'];   % file with the escitalopram levels from all 44 subjects
lmDataFile              = paths.results.group.linearmodels.tempsession.all.datafile;    % file with all data for CCA and linear-model analysis of the data (only includes the 43 subjects with OCI-R data)

figuresOutputDir        = paths.results.group.behavioralreplication.tempsession.all.figuresdir;

%% Main Code
if options.verbose.behavioralreplication
    disp(' ');
    disp('--------------------------------------------------------------');
    disp('Running shellmdl_replicate_relations_state_inference_escitalopram...');
end;

load(behavDataFile);
load(escitalopramLevelsFile);
data_of_interest = xlsread(lmDataFile);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Prepare data for the figure and perform linear models of interest
mean_escitalopram_on_drug   = mean(data_of_interest(data_of_interest(:, 1) > 0, 1));
for iSubj = 1:size(data_of_interest, 1) % to center escitalopram values
    if data_of_interest(iSubj, 1) > 0
        data_of_interest(iSubj, 1)  = data_of_interest(iSubj, 1) - mean_escitalopram_on_drug;
    end;
end;

subjIndicesOfInterest 	= ~ismember(options.dataset.subjects, options.questionnaires.additionalExcludedSubjects); % to exclude the subject without OCI-R data
onDrugSubjectIndices   	= escitalopramLevels > 0;

state_inference_behavioral_index        = all_behav_data.p_corr_by_phase_m(:, 4) - all_behav_data.p_corr_by_phase_m(:, 2);
second_state_inference_behavioral_index = mean(all_behav_data.p_corr_by_phase_m(:, 3:4), 2);

state_inference_behav_model     = fitglm(data_of_interest(:, 1:4), state_inference_behavioral_index(subjIndicesOfInterest)); % predictors: escitalopram levels, group, OCI-R obsessing scores, OCI-R other scores
state_inference_behav_model_CIs = coefCI(state_inference_behav_model);

second_state_inference_behav_model      = fitglm(data_of_interest(:, 1:4), second_state_inference_behavioral_index(subjIndicesOfInterest));
second_state_inference_behav_model_CIs  = coefCI(second_state_inference_behav_model);

% additional checks on the correlation between OCI-R obsessing and other
% scores, to see if the results change when one of those variables is
% excluded from the models:
[r, p] = corr(data_of_interest(:, 3), data_of_interest(:, 4));

ocir_vif1_model = fitglm(data_of_interest(:, [1 2 4]), data_of_interest(:, 3));
vif1_model      = 1 / (1 - ocir_vif1_model.Rsquared.Ordinary);

ocir_vif2_model = fitglm(data_of_interest(:, 1:3), data_of_interest(:, 4));
vif2_model      = 1 / (1 - ocir_vif2_model.Rsquared.Ordinary);

state_inf_no_ocir_other_behav_model         = fitglm(data_of_interest(:, 1:3), state_inference_behavioral_index(subjIndicesOfInterest)); % predictors: escitalopram levels, group, OCI-R obsessing scores, OCI-R other scores
state_inf_no_ocir_other_behav_model_CIs     = coefCI(state_inf_no_ocir_other_behav_model);

state_inf_no_ocir_obsess_behav_model        = fitglm(data_of_interest(:, [1 2 4]), state_inference_behavioral_index(subjIndicesOfInterest));
state_inf_no_ocir_obsess_behav_model_CIs    = coefCI(state_inf_no_ocir_obsess_behav_model);

second_state_inf_no_ocir_other_behav_model      = fitglm(data_of_interest(:, 1:3), second_state_inference_behavioral_index(subjIndicesOfInterest)); % predictors: escitalopram levels, group, OCI-R obsessing scores, OCI-R other scores
second_state_inf_no_ocir_other_behav_model_CIs  = coefCI(second_state_inf_no_ocir_other_behav_model);

second_state_inf_no_ocir_obsess_behav_model     = fitglm(data_of_interest(:, [1 2 4]), second_state_inference_behavioral_index(subjIndicesOfInterest));
second_state_inf_no_ocir_obsess_behav_model_CIs = coefCI(second_state_inf_no_ocir_obsess_behav_model);

if options.save.behavioralreplication && options.overwrite.behavioralreplication
    robustRegressionsOutputDir = paths.results.group.behavioralreplication.tempsession.alldir;
    if ~exist(robustRegressionsOutputDir, 'dir')
        mkdir(robustRegressionsOutputDir);
    end;
    
    robust_regs_data = [data_of_interest(:, 1:4), state_inference_behavioral_index(subjIndicesOfInterest), second_state_inference_behavioral_index(subjIndicesOfInterest)];
    xlswrite(paths.results.group.behavioralreplication.tempsession.all.robustregsdatafile, robust_regs_data);
    csvwrite(paths.results.group.behavioralreplication.tempsession.all.csvrobustregsdatafile, robust_regs_data);
    
    disp(' ');
    disp('The .xls file necessary to run perform_robust_regressions_in_R was overwritten.');
    disp('If you did not do so yet, please create the respective .csv and run perform_robust_regressions_in_R, to check for complementary results.');
end;

if options.verbose.behavioralreplication
    disp(' ');
    disp('In the models below:');
    disp(' - the first y variable is the increase in p(corr) from phase 2 to phase 4;');
    disp(' - the second y variable is the mean p(corr) in phases 3 and 4;');
    disp(' - x1, x2, x3, and x4 are the escitalopram levels, group, OCI-R obsessing scores, and OCI-R other scores, respectively.');
    
    state_inference_behav_model
    state_inference_behav_model_CIs
    
    second_state_inference_behav_model
    second_state_inference_behav_model_CIs
    
    disp(' ');
    disp(['In the first model, the Cooks distance of the possibly influential point was: ' ...
        num2str(round(state_inference_behav_model.Diagnostics.CooksDistance(data_of_interest(:, 1) == max(data_of_interest(:, 1))), 2)) '.']);
    disp('The results for the equivalent robust regression can be seen by running perform_robust_regressions_in_R.');
    
    disp(' ');
    disp(['In the second model, the Cooks distance of the possibly influential point was: ' ...
        num2str(round(second_state_inference_behav_model.Diagnostics.CooksDistance(data_of_interest(:, 1) == max(data_of_interest(:, 1))), 2)) '.']);
    disp('The results for the equivalent robust regression can be seen by running perform_robust_regressions_in_R.');
    
    disp(' ');
    disp(['The r and p of the correlation between OCI-R other and OCI-R obsessing scores were: ' num2str(round(r, 2)) ' and ' num2str(round(p, 7)) ', respectively.']);
    disp(['The variance inflation factors (VIFs) for OCI-R other and OCI-R obsessing scores were: ' num2str(round(vif1_model, 2)) ' and ' num2str(round(vif2_model, 2)) ', respectively.']);
    
    disp('The results of the first model without OCI-R other and OCI-R obsessing were, respectively:');
    
    state_inf_no_ocir_other_behav_model
    state_inf_no_ocir_other_behav_model_CIs
    
    state_inf_no_ocir_obsess_behav_model
    state_inf_no_ocir_obsess_behav_model_CIs
    
    disp('The results of the second model without OCI-R other and OCI-R obsessing were, respectively:');
    
    second_state_inf_no_ocir_other_behav_model
    second_state_inf_no_ocir_other_behav_model_CIs
    
    second_state_inf_no_ocir_obsess_behav_model
    second_state_inf_no_ocir_obsess_behav_model_CIs
end;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Panel A
f = figure();
set(f, 'name', options.figs.figSR3A.name, 'units', 'centimeters', 'position', options.figs.figSR3A.dimensions, ...
    'paperunits', 'centimeters', 'paperposition', options.figs.figSR3A.dimensions);

hold on;
plot(escitalopramLevels(onDrugSubjectIndices), state_inference_behavioral_index(onDrugSubjectIndices), 'o', ...
    'markerSize', options.figs.figSR3A.markerSize, ...
    'markerFaceColor', options.figs.figSR3A.markerFaceColor, ...
    'markerEdgeColor', options.figs.figSR3A.markerEdgeColor);

xlabel(options.figs.figSR3A.xLabel, 'fontname', options.figs.fontName, 'fontsize', options.figs.labelFontSize - 1);
ylabel(options.figs.figSR3A.yLabel, 'fontname', options.figs.fontName, 'fontsize', options.figs.labelFontSize - 1);
axis(options.figs.figSR3A.axis);
set(gca, 'xtick', options.figs.figSR3A.xTick, 'ytick', options.figs.figSR3A.yTick, 'fontname', ...
    options.figs.fontName, 'fontsize', options.figs.fontSize - 1);

% Save
if options.save.behavioralreplication
    if options.verbose.behavioralreplication
        disp(' '); disp('Supplementary Results Figure 3A was overwritten.');
    end;
    if ~exist(figuresOutputDir, 'dir')
        mkdir(figuresOutputDir);
    end;
    export_fig([figuresOutputDir filesep options.figs.figSR3A.name], '-tiff', ['-r' num2str(options.figs.res)], '-transparent'); % , '-nocrop'
    print([figuresOutputDir filesep options.figs.figSR3A.name], '-r1000', '-dpdf');
    close(f);
end;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Panel B
f = figure();
set(f, 'name', options.figs.figSR3B.name, 'units', 'centimeters', 'position', options.figs.figSR3B.dimensions, ...
    'paperunits', 'centimeters', 'paperposition', options.figs.figSR3B.dimensions);

hold on;
plot(escitalopramLevels(onDrugSubjectIndices), second_state_inference_behavioral_index(onDrugSubjectIndices), 'o', ...
    'markerSize', options.figs.figSR3B.markerSize, ...
    'markerFaceColor', options.figs.figSR3B.markerFaceColor, ...
    'markerEdgeColor', options.figs.figSR3B.markerEdgeColor);

xlabel(options.figs.figSR3B.xLabel, 'fontname', options.figs.fontName, 'fontsize', options.figs.labelFontSize - 1);
ylabel(options.figs.figSR3B.yLabel, 'fontname', options.figs.fontName, 'fontsize', options.figs.labelFontSize - 1);
axis(options.figs.figSR3B.axis);
set(gca, 'xtick', options.figs.figSR3B.xTick, 'ytick', options.figs.figSR3B.yTick, 'fontname', ...
    options.figs.fontName, 'fontsize', options.figs.fontSize - 1);

% Save
if options.save.behavioralreplication
    if options.verbose.behavioralreplication
        disp(' '); disp('Supplementary Results Figure 3B was overwritten.');
    end;
    export_fig([figuresOutputDir filesep options.figs.figSR3B.name], '-tiff', ['-r' num2str(options.figs.res)], '-transparent'); % , '-nocrop'
    print([figuresOutputDir filesep options.figs.figSR3B.name], '-r1000', '-dpdf');
    close(f);
end;

end

