function [] = shellmdl_load_behavioralreplication_results(options, paths)
% [] = shellmdl_load_behavioralreplication_results(options, paths)
%
% shellmdl_load_behavioralreplication_results is a function called by 
% shellmdl_master, which copies the previously obtained results from 
% paths.previousresultsdir (the folder where those files should be stored) 
% into paths.resultsdir (the new results folder). In doing so, this 
% function generates (or overwrites) the results (that would be) obtained 
% by running the pipeline targeted at replicating the findings from the 
% inspection of the selected model(s), allowing to minimize computation 
% time. To run this function, instead of the respective 
% behavioral-replication pipeline, 
% options.load.modelsimulations.behavioralreplication and
% options.run.modelsimulations.behavioralreplication should be set to 1
% and 0, respectively, in shellmdl_set_analysis_options.
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  shellmdl_paths
%
% Author: Vasco A. Concei��o
%
% Last modified: November 2023

%% Settings
prDir = [paths.previousresultsdir filesep 'behavioralreplication'];         % previous results folder

prDir_all           = [prDir filesep 'all'];
prDir_all_figs      = [prDir_all filesep 'figures'];

%% Main Code - Initialization
if ~exist(prDir, 'dir')
    mkdir(prDir);
end;
if ~exist(prDir_all, 'dir')
    mkdir(prDir_all);
end;
if ~exist(prDir_all_figs, 'dir')
    mkdir(prDir_all_figs);
end;

if options.verbose.modelsimulations
    disp(' ');
    disp('--------------------------------------------------------------');
    disp('Running shellmdl_load_behavioralreplication_results...');
end;

%% Main Code - Copy the output files from shellmdl_replicate_relations_state_inference_escitalopram
paths       = shellmdl_paths(paths, 1);
rDir        = paths.results.group.behavioralreplication.tempsession.alldir;
rDir_figs   = paths.results.group.behavioralreplication.tempsession.all.figuresdir;

rFile1  = [rDir filesep 'robust_regs_data.xls'];
rFile2  = [rDir filesep 'robust_regs_data.csv'];

rFig1   = [rDir_figs filesep options.figs.figSR3A.name '.tif'];
rFig2   = [rDir_figs filesep options.figs.figSR3A.name '.pdf'];
rFig3   = [rDir_figs filesep options.figs.figSR3B.name '.tif'];
rFig4   = [rDir_figs filesep options.figs.figSR3B.name '.pdf'];

% copyfile(rFile1, prDir_all);        % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFile2, prDir_all);        % this line is commented intentionally; it was ran to obtain the previous results files

% copyfile(rFig1, prDir_all_figs);    % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFig2, prDir_all_figs);    % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFig3, prDir_all_figs);    % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFig4, prDir_all_figs);    % this line is commented intentionally; it was ran to obtain the previous results files

prFile1 = [prDir_all filesep 'robust_regs_data.xls'];
prFile2 = [prDir_all filesep 'robust_regs_data.csv'];

prFig1  = [prDir_all_figs filesep options.figs.figSR3A.name '.tif'];
prFig2  = [prDir_all_figs filesep options.figs.figSR3A.name '.pdf'];
prFig3  = [prDir_all_figs filesep options.figs.figSR3B.name '.tif'];
prFig4  = [prDir_all_figs filesep options.figs.figSR3B.name '.pdf'];

if ~exist(rDir, 'dir')
    mkdir(rDir);
end;
if ~exist(rDir_figs, 'dir')
    mkdir(rDir_figs);
end;

copyfile(prFile1, rDir);
copyfile(prFile2, rDir);

copyfile(prFig1, rDir_figs);
copyfile(prFig2, rDir_figs);
copyfile(prFig3, rDir_figs);
copyfile(prFig4, rDir_figs);

%% Main Code - Copy the output files from shellmdl_assess_relations_sr_learning_escitalopram
rDir    = paths.results.group.behavioralreplication.tempsession.alldir;

rFile1  = [rDir filesep 'pgo_season_glmm_data.xls'];
rFile2  = [rDir filesep 'pgo_pun_first_phase_data.xls'];
rFile3  = [rDir filesep 'pgo_pun_inhib_data.xls'];

rDir_figs   = paths.results.group.behavioralreplication.tempsession.all.figuresdir;

rFig11  = [rDir_figs filesep options.figs.figSR4A.name '.tif'];
rFig12  = [rDir_figs filesep options.figs.figSR4A.name '.pdf'];
rFig21  = [rDir_figs filesep options.figs.figSR4B.name '.tif'];
rFig22  = [rDir_figs filesep options.figs.figSR4B.name '.pdf'];
rFig31  = [rDir_figs filesep options.figs.figSR4C.name '.tif'];
rFig32  = [rDir_figs filesep options.figs.figSR4C.name '.pdf'];

% copyfile(rFile1, prDir_all);        % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFile2, prDir_all);        % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFile3, prDir_all);        % this line is commented intentionally; it was ran to obtain the previous results files

% copyfile(rFig11, prDir_all_figs);   % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFig12, prDir_all_figs);   % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFig21, prDir_all_figs);   % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFig22, prDir_all_figs);   % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFig31, prDir_all_figs);   % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFig32, prDir_all_figs);   % this line is commented intentionally; it was ran to obtain the previous results files

prFile1  = [prDir_all filesep 'pgo_season_glmm_data.xls'];
prFile2  = [prDir_all filesep 'pgo_pun_first_phase_data.xls'];
prFile3  = [prDir_all filesep 'pgo_pun_inhib_data.xls'];

prFig11  = [prDir_all_figs filesep options.figs.figSR4A.name '.tif'];
prFig12  = [prDir_all_figs filesep options.figs.figSR4A.name '.pdf'];
prFig21  = [prDir_all_figs filesep options.figs.figSR4B.name '.tif'];
prFig22  = [prDir_all_figs filesep options.figs.figSR4B.name '.pdf'];
prFig31  = [prDir_all_figs filesep options.figs.figSR4C.name '.tif'];
prFig32  = [prDir_all_figs filesep options.figs.figSR4C.name '.pdf'];

if ~exist(rDir, 'dir')
    mkdir(rDir);
end;
if ~exist(rDir_figs, 'dir')
    mkdir(rDir_figs);
end;

copyfile(prFile1, rDir);
copyfile(prFile2, rDir);
copyfile(prFile3, rDir);

copyfile(prFig11, rDir_figs);
copyfile(prFig12, rDir_figs);
copyfile(prFig21, rDir_figs);
copyfile(prFig22, rDir_figs);
copyfile(prFig31, rDir_figs);
copyfile(prFig32, rDir_figs);
