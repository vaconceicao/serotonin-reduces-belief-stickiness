function [] = shellmdl_assess_relations_sr_learning_escitalopram(options, paths)
% [] = shellmdl_assess_relations_sr_learning_escitalopram(options, paths)
%
% shellmdl_assess_relations_sr_learning_escitalopram is a function that
% plots p(go) on each season as a function of escitalopram plasma levels.
% Such plots compose Supplementary Results Figure 4 of the paper.
% The respective analyses regarding the relation between p(go) on each
% season and escitalopram (level and group) were done in Jamovi, using the
% data files saved by this function.
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  shellmdl_paths
%
% Author: Vasco A. Concei��o
%
% Last modified: September 2023

%% Init
paths                   = shellmdl_paths(paths, 1);
escitalopramLevelsFile  = [paths.results.group.drugdir filesep 'escitalopramLevels'];   % file with the escitalopram levels from all 44 subjects
escitalopramGroupFile   = [paths.results.group.drugdir filesep 'escitalopramGroup'];    % file with the group info (1, if on escitalopram; 0, if not) from all 44 subjects
pgoFile                 = [paths.results.group.behavior.tempsession.all.procfile];
stimFile                = [paths.results.group.behavior2modeldir filesep 'stim_m'];     % needed to calculate the season on each trial
statesFile              = [paths.results.group.behavior2modeldir filesep 'states_m'];   % needed to calculate the season on each trial
phasesFile              = [paths.results.group.behavior2modeldir filesep 'phases_m'];   % needed to select trials for punishment-related analyses

outputDir               = paths.results.group.behavioralreplication.tempsession.alldir;
figuresOutputDir        = paths.results.group.behavioralreplication.tempsession.all.figuresdir;

data_for_jamovi_go_bias         = -Inf * ones(options.dataset.nEffSubjects * options.dataset.nTrials, 7); % 7 columns: subject, escitalopram levels (centered), group, p(go) on each trial, respective season, respective phase, respective stimulus

%% Main Code
if options.verbose.behavioralreplication
    disp(' ');
    disp('--------------------------------------------------------------');
    disp('Running shellmdl_assess_relations_sr_learning_escitalopram...');
end;

load(escitalopramLevelsFile);
load(escitalopramGroupFile);
load(pgoFile);
load(stimFile);
load(statesFile);
load(phasesFile);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Prepare data to perform the logistic regressions of interest in Jamovi
originalEscitalopramLevels  = escitalopramLevels; % non-centered values will be used below, to create the Supplementary Results Figure 4

mean_escitalopram_on_drug   = mean(escitalopramLevels(escitalopramLevels > 0, 1));
for iSubj = 1:numel(escitalopramLevels) % to center escitalopram values
    if escitalopramLevels(iSubj) > 0
        escitalopramLevels(iSubj)  = escitalopramLevels(iSubj) - mean_escitalopram_on_drug;
    end;
end;

for iSubj = 1:options.dataset.nEffSubjects
    subject = options.dataset.subjects(iSubj);
    
    auxIndex = (iSubj - 1) * options.dataset.nTrials;
    data_for_jamovi_go_bias((auxIndex + 1):(iSubj * options.dataset.nTrials), 1) = subject;
    data_for_jamovi_go_bias((auxIndex + 1):(iSubj * options.dataset.nTrials), 2) = escitalopramLevels(iSubj);
    data_for_jamovi_go_bias((auxIndex + 1):(iSubj * options.dataset.nTrials), 3) = escitalopramGroup(iSubj);
    data_for_jamovi_go_bias((auxIndex + 1):(iSubj * options.dataset.nTrials), 4) = all_behav_data.didgo_m(iSubj, :);
    for iTrial = 1:options.dataset.nTrials
        stim    = stim_m(subject, iTrial);
        state   = states_m(subject, iTrial);
        season  = options.dataset.state2seasons(stim, state);
        data_for_jamovi_go_bias(auxIndex + iTrial, 5) = season;
    end;
    data_for_jamovi_go_bias((auxIndex + 1):(iSubj * options.dataset.nTrials), 6) = phases_m(subject, :);
    data_for_jamovi_go_bias((auxIndex + 1):(iSubj * options.dataset.nTrials), 7) = stim_m(subject, :);
end;

data_for_jamovi_pun_first_phase = data_for_jamovi_go_bias(intersect(find(data_for_jamovi_go_bias(:, 5) == 3), ...   % P season
    find(data_for_jamovi_go_bias(:, 6) == 1)), :);                                                                  % phase 1

data_for_jamovi_pun_inhib       = data_for_jamovi_go_bias(intersect(find(data_for_jamovi_go_bias(:, 7) == 3), ...   % third shell (RPRP)
    find(data_for_jamovi_go_bias(:, 6) == 2)), :);                                                                  % phase 2

if options.save.behavioralreplication && options.overwrite.behavioralreplication
    if ~exist(outputDir, 'dir')
        mkdir(outputDir);
    end;
    
    xlswrite(paths.results.group.behavioralreplication.tempsession.all.jamovipgoglmmdatafile, data_for_jamovi_go_bias);
    xlswrite(paths.results.group.behavioralreplication.tempsession.all.jamovipunfirstphasedatafile, data_for_jamovi_pun_first_phase);
    xlswrite(paths.results.group.behavioralreplication.tempsession.all.jamovipuninhibdatafile, data_for_jamovi_pun_inhib);
    
    disp(' ');
    disp('The .xls file necessary to run the logistic regression related to Supplementary Results Figure 4 in Jamovi was overwritten.');
    disp('The two .xls files necessary to run the subsequent punishment-related logistic regressions were overwritten too.');
end;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create Supplementary Results Figure 4
p_go_by_season          = all_behav_data.p_go_by_season_m;
onDrugSubjects          = find(originalEscitalopramLevels > 0);

regressionArray = [...
    repmat(originalEscitalopramLevels(onDrugSubjects), options.dataset.nSeasons, 1), ...
    [p_go_by_season(onDrugSubjects, 1); p_go_by_season(onDrugSubjects, 2); p_go_by_season(onDrugSubjects, 3)], ...
    [ones(size(escitalopramLevels(onDrugSubjects))); 2 * ones(size(escitalopramLevels(onDrugSubjects))); 3 * ones(size(escitalopramLevels(onDrugSubjects)))], ...
    repmat((1:numel(onDrugSubjects))', options.dataset.nSeasons, 1), ...
    [repmat(options.dataset.seasonTrials(1), numel(onDrugSubjects), 1); repmat(options.dataset.seasonTrials(2), numel(onDrugSubjects), 1); repmat(options.dataset.seasonTrials(3), numel(onDrugSubjects), 1)], ...
    [p_go_by_season(onDrugSubjects, 1) .* repmat(options.dataset.seasonTrials(1), numel(onDrugSubjects), 1); p_go_by_season(onDrugSubjects, 2) .* repmat(options.dataset.seasonTrials(2), numel(onDrugSubjects), 1); p_go_by_season(onDrugSubjects, 3) .* repmat(options.dataset.seasonTrials(3), numel(onDrugSubjects), 1)]];

regressionTable = array2table(regressionArray, 'variableNames', ...
    {'escitalopram_levels', ...
    'p_go_by_season', ...
    'season', ...
    'subject_index', ...
    'n_season_trials', ...
    'n_go_per_season'});
regressionTable.season          = categorical(regressionTable.season);
regressionTable.subject_index   = categorical(regressionTable.subject_index);

pgo_regression_me_binomial_m = fitglme(regressionTable, 'n_go_per_season ~ 1 + escitalopram_levels + season + escitalopram_levels:season + (1|subject_index)', ...
    'distribution', 'binomial', 'binomialsize', regressionTable.n_season_trials, 'FitMethod', 'Laplace', 'CovarianceMethod', 'JointHessian');

for iSeason = 1:options.dataset.nSeasons 
    
    switch iSeason
        case 1 % R season
            f = figure();
            set(f, 'name', options.figs.figSR4A.name, 'units', 'centimeters', 'position', options.figs.figSR4A.dimensions, ...
                'paperunits', 'centimeters', 'paperposition', options.figs.figSR4A.dimensions);
            hold on;
            
            x_v = options.figs.figSR4A.axis(1):(options.figs.figSR4A.axis(2) - options.figs.figSR4A.axis(1))/200:options.figs.figSR4A.axis(2);
            aux_intercept   = table2array(pgo_regression_me_binomial_m.Coefficients(1, 2));
            aux_slope       = table2array(pgo_regression_me_binomial_m.Coefficients(2, 2));
            y_v             = ones(size(x_v)) ./ (1 + exp(-(aux_intercept + aux_slope * x_v)));
            plot(x_v, y_v, options.figs.figSR4A.regressionLine);
            
            plot(originalEscitalopramLevels(onDrugSubjects), p_go_by_season(onDrugSubjects, iSeason), 'o', ...
                'markerSize', options.figs.figSR4A.markerSize, ...
                'markerFaceColor', options.figs.figSR4A.markerFaceColor, ...
                'markerEdgeColor', options.figs.figSR4A.markerEdgeColor);
            
            xlabel(options.figs.figSR4A.xLabel, 'fontname', options.figs.fontName, 'fontsize', options.figs.figSR4A.labelFontSize);
            ylabel(options.figs.figSR4A.yLabel, 'fontname', options.figs.fontName, 'fontsize', options.figs.figSR4A.labelFontSize);
            title(options.figs.figSR4A.title, 'fontname', options.figs.fontName, 'fontsize', options.figs.titleFontSize - 1, 'color', options.figs.figSR4A.markerFaceColor);
            axis(options.figs.figSR4A.axis);
            set(gca, 'xtick', options.figs.figSR4A.xTick, 'ytick', options.figs.figSR4A.yTick, 'fontname', ...
                options.figs.fontName, 'fontsize', options.figs.figSR4A.fontSize);
            
            if options.save.behavioralreplication
                if options.verbose.behavioralreplication
                    disp(' '); disp('Supplementary Results Figure 4A was overwritten.');
                end;
                if ~exist(figuresOutputDir, 'dir')
                    mkdir(figuresOutputDir);
                end;
                export_fig([figuresOutputDir filesep options.figs.figSR4A.name], '-tiff', ['-r' num2str(options.figs.res)], '-transparent'); % , '-nocrop'
                print([figuresOutputDir filesep options.figs.figSR4A.name], '-r1000', '-dpdf');
                % close((f);
            end;
            
        case 2 % N season
            f = figure();
            set(f, 'name', options.figs.figSR4B.name, 'units', 'centimeters', 'position', options.figs.figSR4B.dimensions, ...
                'paperunits', 'centimeters', 'paperposition', options.figs.figSR4B.dimensions);
            hold on;
            
            x_v = options.figs.figSR4B.axis(1):(options.figs.figSR4B.axis(2) - options.figs.figSR4B.axis(1))/200:options.figs.figSR4B.axis(2);
            aux_intercept   = table2array(pgo_regression_me_binomial_m.Coefficients(1, 2)) + table2array(pgo_regression_me_binomial_m.Coefficients(3, 2));
            aux_slope       = table2array(pgo_regression_me_binomial_m.Coefficients(2, 2)) + table2array(pgo_regression_me_binomial_m.Coefficients(5, 2));
            y_v             = ones(size(x_v)) ./ (1 + exp(-(aux_intercept + aux_slope * x_v)));
            plot(x_v, y_v, options.figs.figSR4B.regressionLine);
            
            plot(originalEscitalopramLevels(onDrugSubjects), p_go_by_season(onDrugSubjects, iSeason), 'o', ...
                'markerSize', options.figs.figSR4B.markerSize, ...
                'markerFaceColor', options.figs.figSR4B.markerFaceColor, ...
                'markerEdgeColor', options.figs.figSR4B.markerEdgeColor);
            
            xlabel(options.figs.figSR4B.xLabel, 'fontname', options.figs.fontName, 'fontsize', options.figs.figSR4B.labelFontSize);
            ylabel(options.figs.figSR4B.yLabel, 'fontname', options.figs.fontName, 'fontsize', options.figs.figSR4B.labelFontSize);
            title(options.figs.figSR4B.title, 'fontname', options.figs.fontName, 'fontsize', options.figs.titleFontSize - 1, 'color', options.figs.figSR4B.markerFaceColor);
            axis(options.figs.figSR4B.axis);
            set(gca, 'xtick', options.figs.figSR4B.xTick, 'ytick', options.figs.figSR4B.yTick, 'yticklabel', options.figs.figSR4B.yTickLabel, 'fontname', ...
                options.figs.fontName, 'fontsize', options.figs.figSR4B.fontSize);
            
            if options.save.behavioralreplication
                if options.verbose.behavioralreplication
                    disp(' '); disp('Supplementary Results Figure 4B was overwritten.');
                end;
                export_fig([figuresOutputDir filesep options.figs.figSR4B.name], '-tiff', ['-r' num2str(options.figs.res)], '-transparent'); % , '-nocrop'
                print([figuresOutputDir filesep options.figs.figSR4B.name], '-r1000', '-dpdf');
                % close((f);
            end;
            
        case 3 % P season
            f = figure();
            set(f, 'name', options.figs.figSR4C.name, 'units', 'centimeters', 'position', options.figs.figSR4C.dimensions, ...
                'paperunits', 'centimeters', 'paperposition', options.figs.figSR4C.dimensions);
            hold on;
            
            x_v = options.figs.figSR4C.axis(1):(options.figs.figSR4C.axis(2) - options.figs.figSR4C.axis(1))/200:options.figs.figSR4C.axis(2);
            aux_intercept   = table2array(pgo_regression_me_binomial_m.Coefficients(1, 2)) + table2array(pgo_regression_me_binomial_m.Coefficients(4, 2));
            aux_slope       = table2array(pgo_regression_me_binomial_m.Coefficients(2, 2)) + table2array(pgo_regression_me_binomial_m.Coefficients(6, 2));
            y_v             = ones(size(x_v)) ./ (1 + exp(-(aux_intercept + aux_slope * x_v)));
            plot(x_v, y_v, options.figs.figSR4C.regressionLine);
            
            plot(originalEscitalopramLevels(onDrugSubjects), p_go_by_season(onDrugSubjects, iSeason), 'o', ...
                'markerSize', options.figs.figSR4C.markerSize, ...
                'markerFaceColor', options.figs.figSR4C.markerFaceColor, ...
                'markerEdgeColor', options.figs.figSR4C.markerEdgeColor);
            
            xlabel(options.figs.figSR4C.xLabel, 'fontname', options.figs.fontName, 'fontsize', options.figs.figSR4C.labelFontSize);
            ylabel(options.figs.figSR4C.yLabel, 'fontname', options.figs.fontName, 'fontsize', options.figs.figSR4C.labelFontSize);
            title(options.figs.figSR4C.title, 'fontname', options.figs.fontName, 'fontsize', options.figs.titleFontSize - 1, 'color', options.figs.figSR4C.markerFaceColor);
            axis(options.figs.figSR4C.axis);
            set(gca, 'xtick', options.figs.figSR4C.xTick, 'ytick', options.figs.figSR4C.yTick, 'yticklabel', options.figs.figSR4C.yTickLabel, 'fontname', ...
                options.figs.fontName, 'fontsize', options.figs.figSR4C.fontSize);
            
            if options.save.behavioralreplication
                if options.verbose.behavioralreplication
                    disp(' '); disp('Supplementary Results Figure 4C was overwritten.');
                end;
                export_fig([figuresOutputDir filesep options.figs.figSR4C.name], '-tiff', ['-r' num2str(options.figs.res)], '-transparent'); % , '-nocrop'
                print([figuresOutputDir filesep options.figs.figSR4C.name], '-r1000', '-dpdf');
                % close((f);
            end;
    end;
end;
end