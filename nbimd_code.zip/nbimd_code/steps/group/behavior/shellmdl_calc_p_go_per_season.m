function [] = shellmdl_calc_p_go_per_season(options, paths)
% [] = shellmdl_calc_p_go_per_season(options, paths)
%
% shellmdl_calc_p_go_per_season is a function that saves files that will be
% needed for the creation of Figure 6A and Extended Data Figure 1A of the 
% paper by shellmdl_plot_fitted_p_go_per_season.
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  [none]
%
% Author: Vasco A. Concei��o
%
% Last modified: April 2024

%% Settings
paths = shellmdl_paths(paths, 1);
load(paths.results.group.behavior.tempsession.all.procfile);
p_go_by_season_m = all_behav_data.p_go_by_season_m;

outputDir = paths.results.group.behavior.tempsession.all.pgofiguredir;

%% Main Code
if options.verbose.behavioralanalysis
    disp(' ');
    disp('--------------------------------------------------------------');
    disp('Running shellmdl_calc_p_go_per_season...');
end;

auxData = mean(p_go_by_season_m, 1);            % mean across subjects
auxData = reshape(auxData, options.dataset.nSeasons, 1);

auxData2 = p_go_by_season_m;
sem = std(auxData2, 0, 1);                      % in auxData2, dimension 1 refers to subjects
sem = sem / sqrt(options.dataset.nEffSubjects); % calculate the standard error of the mean

%% Save
if options.save.behavioralanalysis && options.overwrite.behavioralanalysis
    if options.verbose.behavioralanalysis
        disp('The file with model-free information necessary for Figure 6A and Extended Data Figure 1A was overwritten.');
    end;
    if ~exist(outputDir, 'dir')
        mkdir(outputDir);
    end;
    
    MF_panel_A_data.all     = p_go_by_season_m';
    MF_panel_A_data.mean    = auxData;
    MF_panel_A_data.sem     = sem;
    save(paths.results.group.behavior.tempsession.all.pgofigurefile, 'MF_panel_A_data');
end;
