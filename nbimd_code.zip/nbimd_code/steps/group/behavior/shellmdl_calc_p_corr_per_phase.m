function [] = shellmdl_calc_p_corr_per_phase(options, paths)
% [] = shellmdl_calc_p_corr_per_phase(options, paths)
% 
% shellmdl_calc_p_corr_per_phase is a function that saves all files that 
% will be needed for the creation of Figure 6C and Extended Data Figure 1C 
% of the paper by shellmdl_plot_fitted_p_corr_per_phase.
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  [none]
%
% Author: Vasco A. Concei��o
%
% Last modified: April 2024

%% Settings
paths = shellmdl_paths(paths, 1);
load(paths.results.group.behavior.tempsession.all.procfile);
p_corr_by_phase_m = all_behav_data.p_corr_by_phase_m;

outputDir = paths.results.group.behavior.tempsession.all.pcorrfiguredir;

%% Main Code
if options.verbose.behavioralanalysis
    disp(' ');
    disp('--------------------------------------------------------------');
    disp('Running shellmdl_calc_p_corr_per_phase...');
end;

auxData = mean(p_corr_by_phase_m, 1);
auxData = reshape(auxData, options.dataset.nPhases, 1);

auxData2 = p_corr_by_phase_m;
sem = std(auxData2, 0, 1);                          % in auxData2, dimension 1 refers to subjects
sem = sem / sqrt(options.dataset.nEffSubjects);     % calculate the standard error of the mean

% Perform within-subject comparisons across phases
[h_ttest_24, p_ttest_24, ci_24, stats_24] = ttest(auxData2(:, 4), auxData2(:, 2)); 	% yields 0.01 < p < 0.05

if options.verbose.behavioralanalysis
    disp(' ');
    disp(['The mean p(corr) in phase 2 was ' num2str(round(mean(auxData2(:, 2)), 2)) ' and the corresponding std was ' num2str(round(std(auxData2(:, 2)), 2))]);
    disp(['The mean p(corr) in phase 4 was ' num2str(round(mean(auxData2(:, 4)), 2)) ' and the corresponding std was ' num2str(round(std(auxData2(:, 4)), 2))]);
    disp(['The mean difference in p(corr) from phase 2 to 4 was ' num2str(round(mean(auxData2(:, 4)) - mean(auxData2(:, 2)), 2))]);
    disp(['The p-value for the corresponding one-sample t-test was: ' num2str(round(p_ttest_24, 3))]);
    disp(['The Cohen''s'' d for the corresponding one-sample t-test was: ' num2str(round((mean(auxData2(:, 4)) - mean(auxData2(:, 2))) / stats_24.sd, 2))]);
    disp(' ');
    disp('Regarding the respective t-statistic and confidence interval:');
    stats_24
    ci_24
end;

%% Save
if options.save.behavioralanalysis && options.overwrite.behavioralanalysis
    if options.verbose.behavioralanalysis
        disp('The file with model-free information necessary for Figure 6C and Extended Data Figure 1C was overwritten.');
    end;
    if ~exist(outputDir, 'dir')
        mkdir(outputDir);
    end;
    
    MF_panel_C_data.all     = p_corr_by_phase_m';
    MF_panel_C_data.mean    = auxData;
    MF_panel_C_data.sem     = sem;
    save(paths.results.group.behavior.tempsession.all.pcorrfigurefile, 'MF_panel_C_data');
end;
