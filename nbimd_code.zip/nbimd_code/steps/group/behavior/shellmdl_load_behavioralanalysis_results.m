function [] = shellmdl_load_behavioralanalysis_results(options, paths)
% [] = shellmdl_load_behavioralanalysis_results(options, paths)
%
% shellmdl_load_behavioralanalysis_results is a function called by
% shellmdl_master, which copies the previously obtained results from
% paths.previousresultsdir (the folder where those files should be stored)
% into paths.resultsdir (the new results folder). In doing so, this
% function generates (or overwrites) the results (that would be) obtained
% by running the behavioral-analysis pipeline, allowing to minimize
% computation time. To run this function, instead of the full
% behavioral-analysis pipeline, options.load.behavioralanalysis and
% options.run.behavioralanalysis should be set to 1 and 0, respectively, in
% shellmdl_set_analysis_options.
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  shellmdl_paths
%
% Author: Vasco A. Concei��o
%
% Last modified: November 2023

%% Settings
prDir = [paths.previousresultsdir filesep 'behavioralanalysis'];                    % previous results folder

prDir_individ   = [prDir filesep 'individ'];
prDir_all       = [prDir filesep 'all'];
prDir_drug      = [prDir filesep 'drug'];
prDir_placebo   = [prDir filesep 'placebo'];

%% Main Code - Initialization
if ~exist(prDir, 'dir')
    mkdir(prDir);
end;
if ~exist(prDir_individ, 'dir')
    mkdir(prDir_individ);
end;
if ~exist(prDir_all, 'dir')
    mkdir(prDir_all);
end;
if ~exist(prDir_drug, 'dir')
    mkdir(prDir_drug);
end;
if ~exist(prDir_placebo, 'dir')
    mkdir(prDir_placebo);
end;

if options.verbose.behavioralanalysis
    disp(' ');
    disp('--------------------------------------------------------------');
    disp('Running shellmdl_load_behavioralanalysis_results...');
end;

%% Main Code - Copy the output files from shellmdl_(loop_)analyze_subj_behav_data
for iSubject = 1:options.dataset.nEffSubjects
    subject = options.dataset.subjects(iSubject);
    paths   = shellmdl_paths(paths, 1, subject);
    
    rDir    = paths.results.subjects.tempsubject.behavior.tempsession.procdir;      % results folder
    rFile   = paths.results.subjects.tempsubject.behavior.tempsession.procfile;     % results file
    % copyfile(rFile, prDir_individ); % this line is commented intentionally; it was ran to obtain the previous results files
    
    prFile  = [prDir_individ filesep ['behav_data_' num2str(subject) '.mat']];    	% previous results file
    if ~exist(rDir, 'dir')
        mkdir(rDir);
    end;
    copyfile(prFile, rDir);
end;

%% Main Code - Copy the output files from shellmdl_aggreg_analyze_subj_behav_data
paths = shellmdl_paths(paths, 1);

rDir_all        = paths.results.group.behavior.tempsession.all.procdir;
rDir_drug       = paths.results.group.behavior.tempsession.drug.procdir;
rDir_placebo    = paths.results.group.behavior.tempsession.placebo.procdir;
rFile_all       = paths.results.group.behavior.tempsession.all.procfile;
rFile_drug      = paths.results.group.behavior.tempsession.drug.procfile;
rFile_placebo   = paths.results.group.behavior.tempsession.placebo.procfile;
% copyfile(rFile_all, prDir_all);         % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFile_drug, prDir_drug);       % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFile_placebo, prDir_placebo); % this line is commented intentionally; it was ran to obtain the previous results files

prFile_all      = [prDir_all filesep 'group_behav_data.mat'];
prFile_drug     = [prDir_drug filesep 'group_behav_data.mat'];
prFile_placebo  = [prDir_placebo filesep 'group_behav_data.mat'];
if ~exist(rDir_all, 'dir')
    mkdir(rDir_all);
end;
if ~exist(rDir_drug, 'dir')
    mkdir(rDir_drug);
end;
if ~exist(rDir_placebo, 'dir')
    mkdir(rDir_placebo);
end;
copyfile(prFile_all, rDir_all);
copyfile(prFile_drug, rDir_drug);
copyfile(prFile_placebo, rDir_placebo);

rDir2          	= paths.results.group.behavior.tempsession.all.pgojamovidir;
rFileForJamovi  = paths.results.group.behavior.tempsession.all.pgojamovifile;
% copyfile(rFileForJamovi, prDir_all); % this line is commented intentionally; it was ran to obtain the previous results files

prFileForJamovi = [prDir_all filesep 'group_pgo_season_jamovi_data.xls'];
if ~exist(rDir2, 'dir')
    mkdir(rDir2);
end;
copyfile(prFileForJamovi, rDir2);

%% Main Code - Copy the output files from shellmdl_calc_p_go_per_season
rDir    = paths.results.group.behavior.tempsession.all.pgofiguredir;
rFile   = paths.results.group.behavior.tempsession.all.pgofigurefile;
% copyfile(rFile, prDir_all); % this line is commented intentionally; it was ran to obtain the previous results files

prFile  = [prDir_all filesep 'group_pgo_season_data.mat'];
if ~exist(rDir, 'dir')
    mkdir(rDir);
end;
copyfile(prFile, rDir);

%% Main Code - Copy the output files from shellmdl_calc_p_corr_per_phase
rDir    = paths.results.group.behavior.tempsession.all.pcorrfiguredir;
rFile   = paths.results.group.behavior.tempsession.all.pcorrfigurefile;
% copyfile(rFile, prDir_all); % this line is commented intentionally; it was ran to obtain the previous results files

prFile  = [prDir_all filesep 'group_pcorr_season_data.mat'];
if ~exist(rDir, 'dir')
    mkdir(rDir);
end;
copyfile(prFile, rDir);

end