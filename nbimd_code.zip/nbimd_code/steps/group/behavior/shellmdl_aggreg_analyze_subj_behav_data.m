function [] = shellmdl_aggreg_analyze_subj_behav_data(options, paths)
% [] = shellmdl_aggreg_analyze_subj_behav_data(options, paths)
%
% shellmdl_aggreg_analyze_subj_behav_data is a function called by 
% shellmdl_master, which loops across the previously created 
% subject-specific files with the processed data. It creates several output 
% files, where such information is clustered by group, as well as a file 
% that is needed for data analysis in Jamovi (Figure 6A).
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  shellmdl_paths
%  shellmdl_format_processed_data_for_Jamovi
%
% Notes: '_t', '_m', and '_v' code tensors, matrices, and vectors,
% respectively.
%
% Author: Vasco A. Concei��o
%
% Last modified: April 2024

%% Settings / Initialization
paths                   = shellmdl_paths(paths, 1);
escitalopramOutputDir   = paths.results.group.drugdir;

load([escitalopramOutputDir filesep 'escitalopramGroup.mat']);

%% Main Code
if options.verbose.behavioralanalysis
    disp(' ');
    disp('--------------------------------------------------------------');
    disp('Running shellmdl_aggreg_analyze_subj_behav_data...');
end;

% P(correct)
acc_t                                   = -Inf * ones(options.dataset.nSubjects, options.dataset.nTrials, options.dataset.nSessions); % adapted code; in NBIMD, only session 1 should be analyzed
p_corr_by_session_m                     = -Inf * ones(options.dataset.nSubjects, options.dataset.nSessions);
p_corr_by_stim_by_session_t             = -Inf * ones(options.dataset.nSubjects, options.dataset.nStim, options.dataset.nSessions);
p_corr_by_stim_by_phase_by_session_t    = nan * ones(options.dataset.nSubjects, options.dataset.nStim, options.dataset.nPhases, options.dataset.nSessions); % init to nan was intentional, so that neutral phases were correctly used in ensuing steps
p_corr_by_phase_by_session_t            = zeros(options.dataset.nSubjects, options.dataset.nPhases, options.dataset.nSessions);                             % init to zero was intentional and related to the way these values are calculated below
p_corr_by_season_by_session_t           = zeros(options.dataset.nSubjects, options.dataset.nSeasons, options.dataset.nSessions);                            % init to zero was intentional and related to the way these values are calculated below

acc_m                                   = -Inf * ones(options.dataset.nSubjects, options.dataset.nTrials);
% p_corr_v                                = -Inf * ones(options.dataset.nSubjects);     % does not require initialization
p_corr_by_stim_m                        = -Inf * ones(options.dataset.nSubjects, options.dataset.nStim);
p_corr_by_stim_by_phase_t               = nan * ones(options.dataset.nSubjects, options.dataset.nStim, options.dataset.nPhases);
p_corr_by_phase_m                       = zeros(options.dataset.nSubjects, options.dataset.nPhases);
p_corr_by_season_m                      = zeros(options.dataset.nSubjects, options.dataset.nSeasons);

denom_p_corr_by_stim_by_phase_by_session_t  = zeros(options.dataset.nSubjects, options.dataset.nStim, options.dataset.nPhases, options.dataset.nSessions);  % aux variable
denom_p_corr_by_season_by_session_t         = zeros(options.dataset.nSubjects, options.dataset.nSeasons, options.dataset.nSessions);                        % aux variable

% P(Go)
didgo_t                             = -Inf * ones(options.dataset.nSubjects, options.dataset.nTrials, options.dataset.nSessions);
p_go_by_session_m                   = -Inf * ones(options.dataset.nSubjects, options.dataset.nSessions);
p_go_by_stim_by_session_t           = -Inf * ones(options.dataset.nSubjects, options.dataset.nStim, options.dataset.nSessions);
p_go_by_stim_by_phase_by_session_t  = nan * ones(options.dataset.nSubjects, options.dataset.nStim, options.dataset.nPhases, options.dataset.nSessions);
p_go_by_phase_by_session_t          = zeros(options.dataset.nSubjects, options.dataset.nPhases, options.dataset.nSessions);
p_go_by_season_by_session_t         = zeros(options.dataset.nSubjects, options.dataset.nSeasons, options.dataset.nSessions);

p_go_N_season_alt_with_R_season_by_session_m   = zeros(options.dataset.nSubjects, options.dataset.nSessions);
p_go_N_season_alt_with_P_season_by_session_m   = zeros(options.dataset.nSubjects, options.dataset.nSessions);

didgo_m                             = -Inf * ones(options.dataset.nSubjects, options.dataset.nTrials);
% p_go_v                              = -Inf * ones(options.dataset.nSubjects);         % does not require initialization
p_go_by_stim_m                      = -Inf * ones(options.dataset.nSubjects, options.dataset.nStim);
p_go_by_stim_by_phase_t             = nan * ones(options.dataset.nSubjects, options.dataset.nStim, options.dataset.nPhases);
p_go_by_phase_m                     = zeros(options.dataset.nSubjects, options.dataset.nPhases);
p_go_by_season_m                    = zeros(options.dataset.nSubjects, options.dataset.nSeasons);

denom_p_go_by_stim_by_phase_by_session_t  = zeros(options.dataset.nSubjects, options.dataset.nStim, options.dataset.nPhases, options.dataset.nSessions);    % aux variable
denom_p_go_by_season_by_session_t         = zeros(options.dataset.nSubjects, options.dataset.nSeasons, options.dataset.nSessions);                          % aux variable

denom_p_go_N_season_alt_with_R_season_by_session_m   = zeros(options.dataset.nSubjects, options.dataset.nSessions);
denom_p_go_N_season_alt_with_P_season_by_session_m   = zeros(options.dataset.nSubjects, options.dataset.nSessions);

onDrugSubjects      = options.dataset.subjects(escitalopramGroup == 1);
offDrugSubjects     = options.dataset.subjects(escitalopramGroup == 0);

outputDirAll        = paths.results.group.behavior.tempsession.all.procdir;
outputDirDrug       = paths.results.group.behavior.tempsession.drug.procdir;
outputDirPlacebo    = paths.results.group.behavior.tempsession.placebo.procdir;

outputFileAll       = paths.results.group.behavior.tempsession.all.procfile;
outputFileDrug      = paths.results.group.behavior.tempsession.drug.procfile;
outputFilePlacebo   = paths.results.group.behavior.tempsession.placebo.procfile;

outputDirJamovi         = paths.results.group.behavior.tempsession.all.pgojamovidir;
pgoDataForJamovi        = -Inf * ones(options.dataset.nEffSubjects * options.dataset.nSeasons, 3); % subject, season, p(go) on each season
pgoDataForJamoviFile    = paths.results.group.behavior.tempsession.all.pgojamovifile;

for iSubject = 1:options.dataset.nEffSubjects
    subject = options.dataset.subjects(iSubject);
    
    paths = shellmdl_paths(paths, 1, subject);
    inputFile1      = paths.results.subjects.tempsubject.behavior.tempsession.procfile;
    inputFile2      = paths.results.subjects.tempsubject.tracefile;
    load(inputFile1);
    load(inputFile2);
    
    acc_t(subject, :, 1) = D.proc.accuracy;
    p_corr_by_session_m(subject, 1) = nanmean(D.proc.accuracy);  % mean across all trials with R or P seasons (nan codes for N seasons)
    
    didgo_t(subject, :, 1) = D.preproc.gonogo;
    p_go_by_session_m(subject, 1) = mean(D.preproc.gonogo);      % mean across all trials
    
    for iStim = 1:options.dataset.nStim
        p_corr_by_stim_by_session_t(subject, iStim, 1) = nanmean(D.proc.accuracy(find(D.preproc.stim == iStim)));
        p_go_by_stim_by_session_t(subject, iStim, 1) = mean(D.preproc.gonogo(find(D.preproc.stim == iStim)));
        
        for iPhase = 1:options.dataset.nPhases
            season = options.dataset.state2seasons(iStim, iPhase);
            correctAction = options.dataset.state2correctaction(iStim, iPhase);
            
            if correctAction % that is, if the season is either R or P:
                p_corr_by_stim_by_phase_by_session_t(subject, iStim, iPhase, 1)          = sum(D.proc.accuracy(intersect(find(D.preproc.stim == iStim), find(traceInfo.phases == iPhase))));
                denom_p_corr_by_stim_by_phase_by_session_t(subject, iStim, iPhase, 1)    = denom_p_corr_by_stim_by_phase_by_session_t(subject, iStim, iPhase, 1) + numel(D.proc.accuracy(intersect(find(D.preproc.stim == iStim), find(traceInfo.phases == iPhase))));
                
                p_corr_by_season_by_session_t(subject, season, 1)                        = p_corr_by_season_by_session_t(subject, season, 1) + sum(D.proc.accuracy(intersect(find(D.preproc.stim == iStim), find(traceInfo.phases == iPhase))));
                denom_p_corr_by_season_by_session_t(subject, season, 1)                  = denom_p_corr_by_season_by_session_t(subject, season, 1) + numel(D.proc.accuracy(intersect(find(D.preproc.stim == iStim), find(traceInfo.phases == iPhase))));
            end;
            
            % for all seasons:
            p_go_by_stim_by_phase_by_session_t(subject, iStim, iPhase, 1)                = sum(D.preproc.gonogo(intersect(find(D.preproc.stim == iStim), find(traceInfo.phases == iPhase))));
            denom_p_go_by_stim_by_phase_by_session_t(subject, iStim, iPhase, 1)          = denom_p_go_by_stim_by_phase_by_session_t(subject, iStim, iPhase, 1) + numel(D.preproc.gonogo(intersect(find(D.preproc.stim == iStim), find(traceInfo.phases == iPhase))));
            
            p_go_by_season_by_session_t(subject, season, 1)                              = p_go_by_season_by_session_t(subject, season, 1) + sum(D.preproc.gonogo(intersect(find(D.preproc.stim == iStim), find(traceInfo.phases == iPhase))));
            denom_p_go_by_season_by_session_t(subject, season, 1)                        = denom_p_go_by_season_by_session_t(subject, season, 1) + numel(D.preproc.gonogo(intersect(find(D.preproc.stim == iStim), find(traceInfo.phases == iPhase))));
            
            if season == 2 % Neutral season
                if iStim == 1 || iStim == 2     % RNRN || NRNR
                    p_go_N_season_alt_with_R_season_by_session_m(subject, 1)           	= p_go_N_season_alt_with_R_season_by_session_m(subject, 1) + sum(D.preproc.gonogo(intersect(find(D.preproc.stim == iStim), find(traceInfo.phases == iPhase))));
                    denom_p_go_N_season_alt_with_R_season_by_session_m(subject, 1)      	= denom_p_go_N_season_alt_with_R_season_by_session_m(subject, 1) + numel(D.preproc.gonogo(intersect(find(D.preproc.stim == iStim), find(traceInfo.phases == iPhase))));
                elseif iStim == 5 || iStim == 6 % PNPN || NPNP
                    p_go_N_season_alt_with_P_season_by_session_m(subject, 1)           	= p_go_N_season_alt_with_P_season_by_session_m(subject, 1) + sum(D.preproc.gonogo(intersect(find(D.preproc.stim == iStim), find(traceInfo.phases == iPhase))));
                    denom_p_go_N_season_alt_with_P_season_by_session_m(subject, 1)     	= denom_p_go_N_season_alt_with_P_season_by_session_m(subject, 1) + numel(D.preproc.gonogo(intersect(find(D.preproc.stim == iStim), find(traceInfo.phases == iPhase))));
                end;
            end;
        end;
    end;
    
    % to account for the fact that the same phase might have different
    % durations (number of trials) in the different shells:
    p_corr_by_phase_by_session_t(subject, :, 1) = nansum(p_corr_by_stim_by_phase_by_session_t(subject, :, :, 1), 2) ./ sum(denom_p_corr_by_stim_by_phase_by_session_t(subject, :, :, 1), 2);
    p_go_by_phase_by_session_t(subject, :, 1) = sum(p_go_by_stim_by_phase_by_session_t(subject, :, :, 1), 2) ./ sum(denom_p_go_by_stim_by_phase_by_session_t(subject, :, :, 1), 2);
    
    for iPhase = 1:options.dataset.nPhases
        p_corr_by_stim_by_phase_by_session_t(subject, :, iPhase, 1) = p_corr_by_stim_by_phase_by_session_t(subject, :, iPhase, 1) ./ denom_p_corr_by_stim_by_phase_by_session_t(subject, :, iPhase, 1);
        p_go_by_stim_by_phase_by_session_t(subject, :, iPhase, 1) = p_go_by_stim_by_phase_by_session_t(subject, :, iPhase, 1) ./ denom_p_go_by_stim_by_phase_by_session_t(subject, :, iPhase, 1);
    end;
    
    for iSeason = 1:options.dataset.nSeasons
        p_corr_by_season_by_session_t(subject, iSeason, 1) = p_corr_by_season_by_session_t(subject, iSeason, 1) / denom_p_corr_by_season_by_session_t(subject, iSeason, 1);
        p_go_by_season_by_session_t(subject, iSeason, 1) = p_go_by_season_by_session_t(subject, iSeason, 1) / denom_p_go_by_season_by_session_t(subject, iSeason, 1);
        
        if iSeason == 2 % Neutral season
            p_go_N_season_alt_with_R_season_by_session_m(subject, 1) = p_go_N_season_alt_with_R_season_by_session_m(subject, 1) / denom_p_go_N_season_alt_with_R_season_by_session_m(subject, 1);
            p_go_N_season_alt_with_P_season_by_session_m(subject, 1) = p_go_N_season_alt_with_P_season_by_session_m(subject, 1) / denom_p_go_N_season_alt_with_P_season_by_session_m(subject, 1);
        end;
    end;
end;

% to avoid having to reshape the data:
acc_m(:, :)                         = acc_t(:, :, 1);
p_corr_v                            = p_corr_by_session_m(:, 1);
p_corr_by_stim_m(:, :)              = p_corr_by_stim_by_session_t(:, :, 1);
p_corr_by_phase_m(:, :)             = p_corr_by_phase_by_session_t(:, :, 1);
p_corr_by_season_m(:, :)            = p_corr_by_season_by_session_t(:, :, 1);
p_corr_by_stim_by_phase_t(:, :, :)  = p_corr_by_stim_by_phase_by_session_t(:, :, :, 1);

didgo_m(:, :)                       = didgo_t(:, :, 1);
p_go_v                              = p_go_by_session_m(:, 1);
p_go_by_stim_m(:, :)                = p_go_by_stim_by_session_t(:, :, 1);
p_go_by_phase_m(:, :)               = p_go_by_phase_by_session_t(:, :, 1);
p_go_by_season_m(:, :)              = p_go_by_season_by_session_t(:, :, 1);
p_go_by_stim_by_phase_t(:, :, :)    = p_go_by_stim_by_phase_by_session_t(:, :, :, 1);

if season == 2 % Neutral season
    if iStim == 1 || iStim == 2     % RNRN || NRNR
        p_go_N_season_alt_with_R_season_v = p_go_N_season_alt_with_R_season_by_session_m(:, 1);
    elseif iStim == 5 || iStim == 6 % PNPN || NPNP
        p_go_N_season_alt_with_P_season_v = p_go_N_season_alt_with_P_season_by_session_m(:, 1);
    end;
end;

%% Format data and save the file for analysis in Jamovi
all_behav_data.acc_m                            = acc_m(options.dataset.subjects, :);   % only the 44 non-excluded subjects (instead of the initial 50 + 4)
all_behav_data.p_corr_v                         = p_corr_v(options.dataset.subjects);
all_behav_data.p_corr_by_stim_m                 = p_corr_by_stim_m(options.dataset.subjects, :);
all_behav_data.p_corr_by_phase_m                = p_corr_by_phase_m(options.dataset.subjects, :);
all_behav_data.p_corr_by_season_m               = p_corr_by_season_m(options.dataset.subjects, :);
all_behav_data.p_corr_by_stim_by_phase_t        = p_corr_by_stim_by_phase_t(options.dataset.subjects, :, :);

all_behav_data.didgo_m                          = didgo_m(options.dataset.subjects, :);
all_behav_data.p_go_v                           = p_go_v(options.dataset.subjects);
all_behav_data.p_go_by_stim_m                   = p_go_by_stim_m(options.dataset.subjects, :);
all_behav_data.p_go_by_phase_m                  = p_go_by_phase_m(options.dataset.subjects, :);
all_behav_data.p_go_by_season_m                 = p_go_by_season_m(options.dataset.subjects, :);
all_behav_data.p_go_by_stim_by_phase_t          = p_go_by_stim_by_phase_t(options.dataset.subjects, :, :);

all_behav_data.p_go_N_season_alt_with_R_season_v  	= p_go_N_season_alt_with_R_season_by_session_m(options.dataset.subjects, 1);
all_behav_data.p_go_N_season_alt_with_P_season_v    = p_go_N_season_alt_with_P_season_by_session_m(options.dataset.subjects, 1);

%
drug_behav_data.acc_m                           = acc_m(onDrugSubjects, :);
drug_behav_data.p_corr_v                        = p_corr_v(onDrugSubjects);
drug_behav_data.p_corr_by_stim_m                = p_corr_by_stim_m(onDrugSubjects, :);
drug_behav_data.p_corr_by_phase_m               = p_corr_by_phase_m(onDrugSubjects, :);
drug_behav_data.p_corr_by_season_m              = p_corr_by_season_m(onDrugSubjects, :);
drug_behav_data.p_corr_by_stim_by_phase_t       = p_corr_by_stim_by_phase_t(onDrugSubjects, :, :);

drug_behav_data.didgo_m                         = didgo_m(onDrugSubjects, :);
drug_behav_data.p_go_v                          = p_go_v(onDrugSubjects);
drug_behav_data.p_go_by_stim_m                  = p_go_by_stim_m(onDrugSubjects, :);
drug_behav_data.p_go_by_phase_m                 = p_go_by_phase_m(onDrugSubjects, :);
drug_behav_data.p_go_by_season_m                = p_go_by_season_m(onDrugSubjects, :);
drug_behav_data.p_go_by_stim_by_phase_t         = p_go_by_stim_by_phase_t(onDrugSubjects, :, :);

drug_behav_data.p_go_N_season_alt_with_R_season_v   = p_go_N_season_alt_with_R_season_by_session_m(onDrugSubjects, 1);
drug_behav_data.p_go_N_season_alt_with_P_season_v   = p_go_N_season_alt_with_P_season_by_session_m(onDrugSubjects, 1);

%
placebo_behav_data.acc_m                        = acc_m(offDrugSubjects, :);
placebo_behav_data.p_corr_v                     = p_corr_v(offDrugSubjects);
placebo_behav_data.p_corr_by_stim_m             = p_corr_by_stim_m(offDrugSubjects, :);
placebo_behav_data.p_corr_by_phase_m            = p_corr_by_phase_m(offDrugSubjects, :);
placebo_behav_data.p_corr_by_season_m           = p_corr_by_season_m(offDrugSubjects, :);
placebo_behav_data.p_corr_by_stim_by_phase_t    = p_corr_by_stim_by_phase_t(offDrugSubjects, :, :);

placebo_behav_data.didgo_m                      = didgo_m(offDrugSubjects, :);
placebo_behav_data.p_go_v                       = p_go_v(offDrugSubjects);
placebo_behav_data.p_go_by_stim_m               = p_go_by_stim_m(offDrugSubjects, :);
placebo_behav_data.p_go_by_phase_m              = p_go_by_phase_m(offDrugSubjects, :);
placebo_behav_data.p_go_by_season_m             = p_go_by_season_m(offDrugSubjects, :);
placebo_behav_data.p_go_by_stim_by_phase_t      = p_go_by_stim_by_phase_t(offDrugSubjects, :, :);

placebo_behav_data.p_go_N_season_alt_with_R_season_v = p_go_N_season_alt_with_R_season_by_session_m(offDrugSubjects, 1);
placebo_behav_data.p_go_N_season_alt_with_P_season_v = p_go_N_season_alt_with_P_season_by_session_m(offDrugSubjects, 1);

%
pgoDataForJamovi(:, 1) = repmat(options.dataset.subjects', options.dataset.nSeasons, 1);
pgoDataForJamovi(:, 2) = [ones(options.dataset.nEffSubjects, 1); 2 * ones(options.dataset.nEffSubjects, 1); 3 * ones(options.dataset.nEffSubjects, 1)];
pgoDataForJamovi(:, 3) = all_behav_data.p_go_by_season_m(:);    % [p(go) on R seasons for all subjects; p(go) on N seasons for all subjects; p(go) on P seasons for all subjects]

%% Saving
saveBool = options.save.behavioralanalysis;
if saveBool
    if ~exist(outputDirAll, 'dir')
        mkdir(outputDirAll);
    end;
    if ~exist(outputDirDrug, 'dir')
        mkdir(outputDirDrug);
    end;
    if ~exist(outputDirPlacebo, 'dir')
        mkdir(outputDirPlacebo);
    end;
    if ~exist(outputDirJamovi, 'dir')
        mkdir(outputDirJamovi);
    end;
    
    overwriteBool = options.overwrite.behavioralanalysis;
    if overwriteBool || ~exist(outputFileAll, 'file')
        if options.verbose.behavioralanalysis
            disp(' Results from shellmdl_aggreg_analyze_subj_behav_data were overwritten.');
        end;
        
        save(outputFileAll,         'all_behav_data');
        save(outputFileDrug,        'drug_behav_data');
        save(outputFilePlacebo,     'placebo_behav_data');
        
        xlswrite(pgoDataForJamoviFile, pgoDataForJamovi);
        
    else %%% seems to be working well, but non-overwritten files won't be used in the ensuing analyses steps unless the code is further changed
        if options.verbose.behavioralanalysis
            disp(' Results from shellmdl_aggreg_analyze_subj_behav_data were saved, but not overwritten.');
        end;
        
        b = exist(outputFileAll, 'file'); fileCounter = 1;
        while b
            b = exist([outputFileAll(1:(end-4)) '_' num2str(fileCounter) '.mat'], 'file');
            fileCounter = fileCounter + 1;
        end;
        save([outputFileAll(1:(end-4)) '_' num2str(fileCounter - 1) '.mat'],        'all_behav_data');
        save([outputFileDrug(1:(end-4)) '_' num2str(fileCounter - 1) '.mat'],       'drug_behav_data');
        save([outputFilePlacebo(1:(end-4)) '_' num2str(fileCounter - 1) '.mat'],    'placebo_behav_data');
        
        xlswrite([pgoDataForJamoviFile(1:(end-4)) '_' num2str(fileCounter - 1) '.xls'], pgoDataForJamovi);
    end;
    
else
    disp(' Results from shellmdl_aggreg_analyze_subj_behav_data were not saved.');
end;
end