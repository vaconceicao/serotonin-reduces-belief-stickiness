cat("\014")
rm(list = ls())

require(MASS)
library(sfsmisc)

################################################################################
data_for_robust_regs = read.csv('C:/Users/User/OneDrive/Área de Trabalho/nbimd_results/group/behavioralreplication/session1/all/robust_regs_data.csv', header = FALSE, sep = ",", dec = ".") # adjust accordingly
colnames(data_for_robust_regs) = c("escitalopram", "group", "ocirObsessing", "ocirOther", "stateInferenceIndex1", "stateInferenceIndex2")

################################################################################
stateInferenceIndex1_model = rlm(stateInferenceIndex1 ~ escitalopram + group	+ ocirObsessing +	ocirOther, data = data_for_robust_regs, psi = psi.bisquare)
print(summary(stateInferenceIndex1_model))
confint.default(stateInferenceIndex1_model)
f.robftest(stateInferenceIndex1_model, var = "escitalopram")
# f.robftest(stateInferenceIndex1_model, var = "group")
# f.robftest(stateInferenceIndex1_model, var = "ocirObsessing")
# f.robftest(stateInferenceIndex1_model, var = "ocirOther")

################################################################################
stateInferenceIndex2_model = rlm(stateInferenceIndex2 ~ escitalopram + group	+ ocirObsessing +	ocirOther, data = data_for_robust_regs, psi = psi.bisquare)
print(summary(stateInferenceIndex2_model))
confint.default(stateInferenceIndex2_model)
f.robftest(stateInferenceIndex2_model, var = "escitalopram")
# f.robftest(stateInferenceIndex2_model, var = "group")
# f.robftest(stateInferenceIndex2_model, var = "ocirObsessing")
# f.robftest(stateInferenceIndex2_model, var = "ocirOther")