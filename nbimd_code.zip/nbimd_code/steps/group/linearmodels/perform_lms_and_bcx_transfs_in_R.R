cat("\014")
rm(list = ls())

require(olsrr)
require(geoR)

################################################################################
# Section 1 ####################################################################
data_for_lms = read.csv('C:/Users/User/OneDrive/Área de Trabalho/nbimd_results/group/linearmodels/session1/all/linear_models_data.csv', header = FALSE, sep = ",", dec = ".")  # adjust accordingly
deltaLogME_bcx_lambdas_file = 'C:/Users/User/OneDrive/Área de Trabalho/nbimd_results/group/modelcomparison/session1/all/lambdasBCxDeltaLogME.csv'                             # adjust accordingly

if(ncol(data_for_lms) == 6){
  colnames(data_for_lms) = c("escitalopram", "group", "ocirObsessing", "ocirOther", "scores1stCV", "deltaLogME")
} else if(ncol(data_for_lms) == 7){
  colnames(data_for_lms) = c("escitalopram", "group", "ocirObsessing", "ocirOther", "scores1stCV", "deltaLogME", "boxCoxDeltaLogME")
}
 
# center escitalopram (see Manuscript for rationale):
onDrugSubjects                                = data_for_lms[, "escitalopram"] > 0 
meanEscitalopramOnDrug                        = mean(data_for_lms[onDrugSubjects, "escitalopram"])
data_for_lms[onDrugSubjects, "escitalopram"]  = data_for_lms[onDrugSubjects, "escitalopram"] - meanEscitalopramOnDrug
 
################################################################################
# Section 2 ####################################################################
deltaLogME_model = lm(deltaLogME ~ escitalopram + group	+ ocirObsessing +	ocirOther, data = data_for_lms)
ols_test_breusch_pagan(deltaLogME_model)

y = data_for_lms[, "deltaLogME"]
x = cbind(data_for_lms[, "escitalopram"], data_for_lms[, "group"], data_for_lms[, "ocirObsessing"], data_for_lms[, "ocirOther"])

bcx_model = boxcoxfit(y, x, lambda2 = TRUE)
bcx_model

write.csv(bcx_model$lambda, deltaLogME_bcx_lambdas_file, row.names = TRUE)

################################################################################
# Section 3 ####################################################################
boxCoxDeltaLogME_model = lm(boxCoxDeltaLogME ~ escitalopram + group	+ ocirObsessing +	ocirOther, data = data_for_lms)
ols_test_breusch_pagan(boxCoxDeltaLogME_model)

print(summary(boxCoxDeltaLogME_model))
confint(boxCoxDeltaLogME_model)