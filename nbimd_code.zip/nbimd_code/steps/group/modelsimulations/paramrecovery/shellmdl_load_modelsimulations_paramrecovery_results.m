function [] = shellmdl_load_modelsimulations_paramrecovery_results(options, paths)
% [] = shellmdl_load_modelsimulations_paramrecovery_results(options, paths)
%
% shellmdl_load_modelsimulations_paramrecovery_results is a function called 
%by shellmdl_master, which copies the previously obtained results from 
% paths.previousresultsdir (the folder where those files should be stored) 
% into paths.resultsdir (the new results folder). In doing so, this 
% function generates (or overwrites) the results (that would be) obtained 
% by running the parameter-recovery simulations pipeline, allowing to 
% minimize computation time. To run this function, instead of the 
% respective model-simulations pipeline, 
% options.load.modelsimulations.paramrecovery and
% options.run.modelsimulations.paramrecovery should be set to 1
% and 0, respectively, in shellmdl_set_analysis_options.
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  shellmdl_paths
%
% Author: Vasco A. Concei��o
%
% Last modified: November 2023

%% Settings
prDir = [paths.previousresultsdir filesep 'modelsimulations' filesep 'paramrecovery']; 	% previous results folder

prDir_all           = [prDir filesep 'all'];
prDir_individ_model = [prDir filesep 'individ_model'];
prDir_all_figs      = [prDir_all filesep 'figures'];

%% Main Code - Initialization
if ~exist(prDir, 'dir')
    mkdir(prDir);
end;
if ~exist(prDir_all, 'dir')
    mkdir(prDir_all);
end;
if ~exist(prDir_individ_model, 'dir')
    mkdir(prDir_individ_model);
end;
if ~exist(prDir_all_figs, 'dir')
    mkdir(prDir_all_figs);
end;

if options.verbose.modelsimulations
    disp(' ');
    disp('--------------------------------------------------------------');
    disp('Running shellmdl_load_modelsimulations_paramrecovery_results...');
    disp(' ');
    disp('Running the first major cycle of shellmdl_load_modelsimulations_paramrecovery_results...');
end;

%% Main Code - Copy the output files from shellmdl_loop_simulate_subj_behavior & shellmdl_aggreg_simulated_behavior
for iSimul = 1:options.modelsimulations.paramrecovery.nSimulations
    if options.verbose.modelsimulations
        if iSimul < options.modelsimulations.paramrecovery.nSimulations
            disp(['... for simulation ' num2str(iSimul) ' out of ' num2str(options.modelsimulations.paramrecovery.nSimulations) ';']);
        else
            disp(['... for simulation ' num2str(iSimul) ' out of ' num2str(options.modelsimulations.paramrecovery.nSimulations) '.']);
        end;
    end;

    simulType   = ceil(iSimul / options.modelsimulations.paramrecovery.nSimulationsPerModel);
    iModel      = options.rl.selectedModel;
    paths       = shellmdl_paths(paths, 1, -1, iModel, options); % -1 is the subject error code

    % shellmdl_loop_simulate_subj_behavior: 
    rDir_group  = paths.results.group.modelsimulations.paramrecovery.tempsession.alldir;
    rFile_group = [paths.results.group.modelsimulations.paramrecovery.tempsession.all.paramrecoveryfile(1:(end-4)) '-' num2str(iSimul) '.mat'];

    % copyfile(rFile_group, prDir_all); % this line is commented intentionally; it was ran to obtain the previous results files

    if ~exist(rDir_group, 'dir')
        mkdir(rDir_group);
    end;

    prFile_group = [prDir_all filesep 'simulation_results-' num2str(iSimul) '.mat'];
    copyfile(prFile_group, rDir_group);
    
    prDir_individ_model_spec = [prDir_individ_model filesep options.mcmc.modelNames{iModel}];   % previous results folder
    if ~exist(prDir_individ_model_spec, 'dir')
        mkdir(prDir_individ_model_spec);
    end;
    
    for s = 1:options.dataset.nEffSubjects
        subj            = options.dataset.subjects(s);
        paths           = shellmdl_paths(paths, 1, subj, iModel, options);
        
        % shellmdl_loop_simulate_subj_behavior:
        rDir_individ    = paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelsimulations.paramrecoverydir;
        rFile_individ   = [paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelsimulations.paramrecoveryfile(1:(end - 4)) '-' num2str(iSimul) '.mat'];
        
        prDir_individ_model_spec_subj = [prDir_individ_model_spec filesep ['subject-' num2str(subj)]];
        if ~exist(prDir_individ_model_spec_subj, 'dir')
            mkdir(prDir_individ_model_spec_subj);
        end;
        
        % copyfile(rFile_individ, prDir_individ_model_spec_subj); % this line is commented intentionally; it was ran to obtain the previous results files
        
        prFile_individ  = [prDir_individ_model_spec_subj filesep 'simulResults-' num2str(subj) '-' num2str(iSimul) '.mat'];
        if ~exist(rDir_individ, 'dir')
            mkdir(rDir_individ);
        end;
        copyfile(prFile_individ, rDir_individ);
    end;
    
    % shellmdl_aggreg_simulated_behavior:
    rFile_group     = [paths.results.group.modelsimulations.paramrecovery.tempsession.all.aggregparamrecoveryfile(1:(end-4)) '-' num2str(iSimul) '.mat'];
    % copyfile(rFile_group, prDir_all); % this line is commented intentionally; it was ran to obtain the previous results files
    
    prFile_group    = [prDir_all filesep 'aggreg_simul_results-' num2str(iSimul) '.mat'];
    copyfile(prFile_group, rDir_group);
end;

%% Main Code - Copy the output files from shellmdl_loop_subj_invert_model
firstSubj           = min(options.dataset.subjects);
lastSubj            = max(options.dataset.subjects);
subjsOfInterest_v   = options.dataset.subjects;

if options.verbose.modelsimulations
    disp(' ');
    disp('Running the second major cycle of shellmdl_load_modelsimulations_paramrecovery_results...');
end;

for iProcedure = options.modelsimulations.paramrecovery.firstProcedure:options.modelsimulations.paramrecovery.lastProcedure
    if options.verbose.modelsimulations
        if iProcedure < options.modelsimulations.paramrecovery.lastProcedure
            disp(['... for procedure ' num2str(iProcedure) ' out of ' num2str(options.modelsimulations.paramrecovery.lastProcedure) ';']);
        else
            disp(['... for procedure ' num2str(iProcedure) ' out of ' num2str(options.modelsimulations.paramrecovery.lastProcedure) '.']);
        end;
    end;

    iModel = options.rl.selectedModel;
    
    prDir_individ_model_spec = [prDir_individ_model filesep options.mcmc.modelNames{iModel}];	% previous results folder
    if ~exist(prDir_individ_model_spec, 'dir')
        mkdir(prDir_individ_model_spec);
    end;
    
    for subj = firstSubj:1:lastSubj
        if ismember(subj, subjsOfInterest_v)
            paths   = shellmdl_paths(paths, options.dataset.session, subj, iModel, options);
            
            simulatedDataset                    = iProcedure;
            rDir_individ_model_spec_subj_simul  = [getfield(paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelsimulations, 'paramrecoverydir') filesep num2str(simulatedDataset)];
            
            rFile = [rDir_individ_model_spec_subj_simul, filesep, options.modelsimulations.paramrecovery.fileNames{1}, num2str(subj), '.mat'];
            
            prDir_individ_model_spec_subj_simul = [prDir_individ_model_spec filesep ['subject-' num2str(subj)] filesep ['simul-' num2str(simulatedDataset)]];
            if ~exist(prDir_individ_model_spec_subj_simul, 'dir')
                mkdir(prDir_individ_model_spec_subj_simul);
            end;
            
            % copyfile(rFile, prDir_individ_model_spec_subj_simul); % this line is commented intentionally; it was ran to obtain the previous results files
            
            prFile = [prDir_individ_model_spec_subj_simul, filesep, options.modelsimulations.paramrecovery.fileNames{1}, num2str(subj), '.mat'];
            
            if ~exist(rDir_individ_model_spec_subj_simul, 'dir')
                mkdir(rDir_individ_model_spec_subj_simul);
            end;
            
            copyfile(prFile, rDir_individ_model_spec_subj_simul);
        end;
    end;
end;

%% Main Code - Copy the output files from shellmdl_show_param_recovery_results
rDir        = paths.results.group.modelsimulations.paramrecovery.tempsession.alldir;
rDir_figs 	= paths.results.group.modelsimulations.paramrecovery.tempsession.all.figuresdir;

for iSimul = 1:options.modelsimulations.paramrecovery.nSimulations
    rFig1   = [rDir_figs filesep options.figs.figSR2B.figureNames{iSimul} '.tif'];
    rFig2   = [rDir_figs filesep options.figs.figSR2B.figureNames{iSimul} '.pdf'];
    
    rFile1  = [rDir filesep 'simul_params_' num2str(iSimul) '.mat'];
    rFile2  = [rDir filesep 'recov_params_' num2str(iSimul) '.mat'];
    rFile3  = [rDir filesep 'simul_params_' num2str(iSimul) '.xls'];
    rFile4  = [rDir filesep 'recov_params_' num2str(iSimul) '.xls'];
    rFile5  = [rDir filesep 'simul_params_' num2str(iSimul) '.csv'];
    rFile6  = [rDir filesep 'recov_params_' num2str(iSimul) '.csv'];
    
    rFile7  = [rDir filesep 'p_holm.csv'];
    rFile8  = [rDir filesep 'p_holm.xls'];
    rFile9  = [rDir filesep 'p_uncorr.csv'];
    rFile10 = [rDir filesep 'p_uncorr.xls'];
    
    if options.figs.figSR2C.whiteShadingColorMap
        if options.figs.figSR2C.use_Holm_corrected_p_values
            rFig3 = [rDir_figs filesep 'Correlogram - Holm - white shading.tif'];
            rFig4 = [rDir_figs filesep 'Correlogram - Holm - white shading.pdf'];
        else
            rFig3 = [rDir_figs filesep 'Correlogram - white shading.tif'];
            rFig4 = [rDir_figs filesep 'Correlogram - white shading.pdf'];
        end;
    else
        if options.figs.figSR2C.use_Holm_corrected_p_values
            rFig3 = [rDir_figs filesep 'Correlogram - Holm.tif'];
            rFig4 = [rDir_figs filesep 'Correlogram - Holm.pdf'];
        else
            rFig3 = [rDir_figs filesep 'Correlogram.tif'];
            rFig4 = [rDir_figs filesep 'Correlogram.pdf'];
        end;
    end;
    
    % copyfile(rFig1, prDir_all_figs);    % this line is commented intentionally; it was ran to obtain the previous results files
    % copyfile(rFig2, prDir_all_figs);    % this line is commented intentionally; it was ran to obtain the previous results files
    
    % copyfile(rFile1, prDir_all);        % this line is commented intentionally; it was ran to obtain the previous results files
    % copyfile(rFile2, prDir_all);        % this line is commented intentionally; it was ran to obtain the previous results files
    % copyfile(rFile3, prDir_all);        % this line is commented intentionally; it was ran to obtain the previous results files
    % copyfile(rFile4, prDir_all);        % this line is commented intentionally; it was ran to obtain the previous results files
    % copyfile(rFile5, prDir_all);        % this line is commented intentionally; it was ran to obtain the previous results files
    % copyfile(rFile6, prDir_all);        % this line is commented intentionally; it was ran to obtain the previous results files
    
    % copyfile(rFile7, prDir_all);        % this line is commented intentionally; it was ran to obtain the previous results files
    % copyfile(rFile8, prDir_all);        % this line is commented intentionally; it was ran to obtain the previous results files
    % copyfile(rFile9, prDir_all);        % this line is commented intentionally; it was ran to obtain the previous results files
    % copyfile(rFile10, prDir_all);       % this line is commented intentionally; it was ran to obtain the previous results files
    
    % copyfile(rFig3, prDir_all_figs);    % this line is commented intentionally; it was ran to obtain the previous results files
    % copyfile(rFig4, prDir_all_figs);    % this line is commented intentionally; it was ran to obtain the previous results files
    
    prFig1  = [prDir_all_figs filesep options.figs.figSR2B.figureNames{iSimul} '.tif'];
    prFig2  = [prDir_all_figs filesep options.figs.figSR2B.figureNames{iSimul} '.pdf'];
    
    prFile1 = [prDir_all filesep 'simul_params_' num2str(iSimul) '.mat'];
    prFile2 = [prDir_all filesep 'recov_params_' num2str(iSimul) '.mat'];
    prFile3 = [prDir_all filesep 'simul_params_' num2str(iSimul) '.xls'];
    prFile4 = [prDir_all filesep 'recov_params_' num2str(iSimul) '.xls'];
    prFile5 = [prDir_all filesep 'simul_params_' num2str(iSimul) '.csv'];
    prFile6 = [prDir_all filesep 'recov_params_' num2str(iSimul) '.csv'];
    
    prFile7  = [prDir_all filesep 'p_holm.csv'];
    prFile8  = [prDir_all filesep 'p_holm.xls'];
    prFile9  = [prDir_all filesep 'p_uncorr.csv'];
    prFile10 = [prDir_all filesep 'p_uncorr.xls'];
    
    if options.figs.figSR2C.whiteShadingColorMap
        if options.figs.figSR2C.use_Holm_corrected_p_values
            prFig3 = [prDir_all_figs filesep 'Correlogram - Holm - white shading.tif'];
            prFig4 = [prDir_all_figs filesep 'Correlogram - Holm - white shading.pdf'];
        else
            prFig3 = [prDir_all_figs filesep 'Correlogram - white shading.tif'];
            prFig4 = [prDir_all_figs filesep 'Correlogram - white shading.pdf'];
        end;
    else
        if options.figs.figSR2C.use_Holm_corrected_p_values
            prFig3 = [prDir_all_figs filesep 'Correlogram - Holm.tif'];
            prFig4 = [prDir_all_figs filesep 'Correlogram - Holm.pdf'];
        else
            prFig3 = [prDir_all_figs filesep 'Correlogram.tif'];
            prFig4 = [prDir_all_figs filesep 'Correlogram.pdf'];
        end;
    end;
    
    if ~exist(rDir, 'dir')
        mkdir(rDir);
    end;
    if ~exist(rDir_figs, 'dir')
        mkdir(rDir_figs);
    end;
    
    copyfile(prFig1, rDir_figs);
    copyfile(prFig2, rDir_figs);
    
    copyfile(prFile1, rDir);
    copyfile(prFile2, rDir);
    copyfile(prFile3, rDir);
    copyfile(prFile4, rDir);
    copyfile(prFile5, rDir);
    copyfile(prFile6, rDir);
    
    copyfile(prFile7, rDir);
    copyfile(prFile8, rDir);
    copyfile(prFile9, rDir);
    copyfile(prFile10, rDir);
    
    copyfile(prFig3, rDir_figs);
    copyfile(prFig4, rDir_figs);
end;