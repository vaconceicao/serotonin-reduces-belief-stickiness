cat("/014")
rm(list = ls())

library(psych)

################################################################################
# Obtain the first set of parameter-recovery results from MATLAB:
simul_params_alpha_plus_data    = read.csv('C:/Users/User/OneDrive/Área de Trabalho/nbimd_results/group/modelsimulations/paramrecovery/session1/all/simul_params_1.csv', header = FALSE, sep = ",", dec = ".") # adjust paths accordingly
simul_params_alpha_minus_data   = read.csv('C:/Users/User/OneDrive/Área de Trabalho/nbimd_results/group/modelsimulations/paramrecovery/session1/all/simul_params_2.csv', header = FALSE, sep = ",", dec = ".")
simul_params_beta_plus_data     = read.csv('C:/Users/User/OneDrive/Área de Trabalho/nbimd_results/group/modelsimulations/paramrecovery/session1/all/simul_params_3.csv', header = FALSE, sep = ",", dec = ".")
simul_params_beta_minus_data    = read.csv('C:/Users/User/OneDrive/Área de Trabalho/nbimd_results/group/modelsimulations/paramrecovery/session1/all/simul_params_4.csv', header = FALSE, sep = ",", dec = ".")
simul_params_phi_data           = read.csv('C:/Users/User/OneDrive/Área de Trabalho/nbimd_results/group/modelsimulations/paramrecovery/session1/all/simul_params_5.csv', header = FALSE, sep = ",", dec = ".")
simul_params_gamma_data         = read.csv('C:/Users/User/OneDrive/Área de Trabalho/nbimd_results/group/modelsimulations/paramrecovery/session1/all/simul_params_6.csv', header = FALSE, sep = ",", dec = ".")
simul_params_zeta_data          = read.csv('C:/Users/User/OneDrive/Área de Trabalho/nbimd_results/group/modelsimulations/paramrecovery/session1/all/simul_params_7.csv', header = FALSE, sep = ",", dec = ".")

recov_params_alpha_plus_data    = read.csv('C:/Users/User/OneDrive/Área de Trabalho/nbimd_results/group/modelsimulations/paramrecovery/session1/all/recov_params_1.csv', header = FALSE, sep = ",", dec = ".")
recov_params_alpha_minus_data   = read.csv('C:/Users/User/OneDrive/Área de Trabalho/nbimd_results/group/modelsimulations/paramrecovery/session1/all/recov_params_2.csv', header = FALSE, sep = ",", dec = ".")
recov_params_beta_plus_data     = read.csv('C:/Users/User/OneDrive/Área de Trabalho/nbimd_results/group/modelsimulations/paramrecovery/session1/all/recov_params_3.csv', header = FALSE, sep = ",", dec = ".")
recov_params_beta_minus_data    = read.csv('C:/Users/User/OneDrive/Área de Trabalho/nbimd_results/group/modelsimulations/paramrecovery/session1/all/recov_params_4.csv', header = FALSE, sep = ",", dec = ".")
recov_params_phi_data           = read.csv('C:/Users/User/OneDrive/Área de Trabalho/nbimd_results/group/modelsimulations/paramrecovery/session1/all/recov_params_5.csv', header = FALSE, sep = ",", dec = ".")
recov_params_gamma_data         = read.csv('C:/Users/User/OneDrive/Área de Trabalho/nbimd_results/group/modelsimulations/paramrecovery/session1/all/recov_params_6.csv', header = FALSE, sep = ",", dec = ".")
recov_params_zeta_data          = read.csv('C:/Users/User/OneDrive/Área de Trabalho/nbimd_results/group/modelsimulations/paramrecovery/session1/all/recov_params_7.csv', header = FALSE, sep = ",", dec = ".")

################################################################################
n_subjects  = 44
p_uncorr    = matrix(nrow = 7, ncol = 7)
p_holm      = matrix(nrow = 7, ncol = 7)

################################################################################
res = corr.test(simul_params_alpha_plus_data[,1], recov_params_alpha_plus_data, adjust = "holm"); 
res
p_holm[1,] = res$p; 
p_uncorr[1,] = res$p.adj;

res2 = paired.r(abs(res$r[1]), abs(res$r[3]), abs(corr.test(recov_params_alpha_plus_data[,1], recov_params_alpha_plus_data[,3])$r), n_subjects); 
res2

################################################################################
res = corr.test(simul_params_alpha_minus_data[,2], recov_params_alpha_minus_data, adjust = "holm"); 
res
p_holm[2,] = res$p; 
p_uncorr[2,] = res$p.adj

res2 = paired.r(abs(res$r[2]), abs(res$r[5]), abs(corr.test(recov_params_alpha_minus_data[,2], recov_params_alpha_minus_data[,5])$r), n_subjects);
res2

################################################################################
res = corr.test(simul_params_beta_plus_data[,3], recov_params_beta_plus_data, adjust = "holm"); 
res
p_holm[3,] = res$p;
p_uncorr[3,] = res$p.adj

res2 = paired.r(abs(res$r[3]), abs(res$r[5]), abs(corr.test(recov_params_beta_plus_data[,3], recov_params_beta_plus_data[,5])$r), n_subjects);
res2

################################################################################
res = corr.test(simul_params_beta_minus_data[,4], recov_params_beta_minus_data, adjust = "holm");
res
p_holm[4,] = res$p;
p_uncorr[4,] = res$p.adj

res2 = paired.r(abs(res$r[4]), abs(res$r[5]), abs(corr.test(recov_params_beta_minus_data[,4], recov_params_beta_minus_data[,5])$r), n_subjects); res2$t; res2$p
res2

################################################################################
res = corr.test(simul_params_phi_data[,5], recov_params_phi_data, adjust = "holm"); 
res
p_holm[5,] = res$p;
p_uncorr[5,] = res$p.adj

res2 = paired.r(abs(res$r[5]), abs(res$r[3]), abs(corr.test(recov_params_phi_data[,5], recov_params_phi_data[,3])$r), n_subjects); res2$t; res2$p

################################################################################
res = corr.test(simul_params_gamma_data[,6], recov_params_gamma_data, adjust = "holm"); 
res
p_holm[6,] = res$p;
p_uncorr[6,] = res$p.adj

res2 = paired.r(abs(res$r[6]), abs(res$r[7]), abs(corr.test(recov_params_gamma_data[,6], recov_params_gamma_data[,7])$r), n_subjects)
res2

res2 = paired.r(abs(res$r[6]), abs(res$r[5]), abs(corr.test(recov_params_gamma_data[,6], recov_params_gamma_data[,5])$r), n_subjects)
res2

################################################################################
res = corr.test(simul_params_zeta_data[,7], recov_params_zeta_data, adjust = "holm");
res
p_holm[7,] = res$p;
p_uncorr[7,] = res$p.adj

res2 = paired.r(abs(res$r[7]), abs(res$r[6]), abs(corr.test(recov_params_zeta_data[,7], recov_params_zeta_data[,6])$r), n_subjects);
res2

write.csv(format(p_uncorr, scientific = F), file = "C:/Users/User/OneDrive/Área de Trabalho/nbimd_results/group/modelsimulations/paramrecovery/session1/all/p_uncorr.csv", row.names = TRUE)  # adjust paths accordingly
write.csv(format(p_holm, scientific = F), file = "C:/Users/User/OneDrive/Área de Trabalho/nbimd_results/group/modelsimulations/paramrecovery/session1/all/p_holm.csv", row.names = TRUE)