function [] = shellmdl_show_param_recovery_results(options, paths)
% [] = shellmdl_show_param_recovery_results(options, paths)
%
% shellmdl_show_param_recovery_results is a function that depicts the
% correlations between the simulated and the fit parameter values (panels B
% and C of Supplementary Results Figure 2; the full Figure is assembled in
% Adobe Illustrator).
% Holm correction for multiple comparisons should be executed in R, by
% running get_param_recovery_results_from_R, before panel C
% is generated.
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  [none]
%
% Author: Vasco A. Concei��o
%
% Last modified: October 2023

%% Initialization / Settings
nModelParams    = options.rl.nParams(options.rl.selectedModel);

outputDir       = paths.results.group.modelsimulations.paramrecovery.tempsession.alldir;
figsOutputDir 	= paths.results.group.modelsimulations.paramrecovery.tempsession.all.figuresdir;

paramRecoveryCorrectedPValuesFile = paths.results.group.modelsimulations.paramrecovery.tempsession.all.pholmfile;

paramNames      = options.figs.figSR2.paramNames;
paramNames_mod  = options.figs.figSR2.paramNames_mod;

figDimensions   = options.figs.figSR2B.figDimensions;
x_label         = options.figs.figSR2B.x_label;
y_label         = options.figs.figSR2B.y_label;
fontName        = options.figs.figSR2B.fontName;
titleFontSize   = options.figs.figSR2B.titleFontSize;
labelFontSize   = options.figs.figSR2B.labelFontSize;
fontSize        = options.figs.figSR2B.fontSize;
markerSize      = options.figs.figSR2B.markerSize;
markerColor     = options.figs.figSR2B.markerColor;
figureNames     = options.figs.figSR2B.figureNames;
x_tick          = options.figs.figSR2B.x_tick;
y_tick          = options.figs.figSR2B.y_tick;
axis_v          = options.figs.figSR2B.axis_v;

figDimensions2              = options.figs.figSR2C.figDimensions;
whiteShadingColorMap        = options.figs.figSR2C.whiteShadingColorMap;
use_Holm_corrected_p_values = options.figs.figSR2C.use_Holm_corrected_p_values;
mymap                       = options.figs.figSR2C.mymap;
myMapWhiteFirst             = options.figs.figSR2C.myMapWhiteFirst;
myMapWhiteLast              = options.figs.figSR2C.myMapWhiteLast;

%% Main Code - Panel B (and obtention of key variables for Panel C)
if options.verbose.modelsimulations
    disp(' ');
    disp('Running shellmdl_show_param_recovery_results...');
    disp(' ');
    disp('To run this function for Holm-corrected p-values, please generate paramRecoveryCorrectedPValuesFile, if (and when) asked to below.');
    disp(' ');
end;

if ~exist(outputDir, 'dir')
    mkdir(outputDir);
end;
if ~exist(figsOutputDir, 'dir')
    mkdir(figsOutputDir);
end;

r_figSR2_m  = -Inf * ones(nModelParams, nModelParams);
p_figSR2_m  = -Inf * ones(nModelParams, nModelParams);

for iSimul = 1:nModelParams
    if options.verbose.modelsimulations
        disp(['Obtaining parameter estimates for simulation ' num2str(iSimul) '...']);
    end;
    
    simulParams_m           = -Inf * ones(nModelParams, options.dataset.nEffSubjects);
    recoveredParams_m       = -Inf * ones(nModelParams, options.dataset.nEffSubjects);
    
    for iSubj = 1:options.dataset.nEffSubjects
        subj = options.dataset.subjects(iSubj);
        
        paths       = shellmdl_paths(paths, 1, subj, options.rl.selectedModel, options);
        
        inputDir1   = [paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelsimulations.paramrecoverydir filesep num2str(iSimul)];
        inputFile1  = [inputDir1 filesep options.modelsimulations.modelrecovery.fileNames{1} num2str(subj)];
        load(inputFile1);
        recoveredParams_m(:, iSubj) = results.samples.pE;
        
        inputFile2  = [paths.results.group.modelsimulations.paramrecovery.tempsession.all.paramrecoveryfile(1:(end-4)) '-' num2str(iSimul) '.mat'];
        load(inputFile2);
        simulParams_m(:, iSubj) = params_simul_m(iSubj, :)';
    end;

    [r_Pearson, p_Pearson]      = corr(simulParams_m(iSimul, :)', recoveredParams_m(iSimul, :)', 'type', 'Pearson');
    
    set(0, 'DefaultAxesTitleFontWeight', 'normal');
    f = figure();
    set(f, 'name', figureNames{iSimul}, 'units', 'centimeters', 'position', figDimensions, ...
        'paperunits', 'centimeters', 'paperposition', figDimensions);
    
    hold on;
    
    [r, m, b] = regression(simulParams_m(iSimul, :), recoveredParams_m(iSimul, :));
    plot(axis_v(iSimul, 1:2), b + m * axis_v(iSimul, 1:2), '--k');
    
    plot(simulParams_m(iSimul, :)', recoveredParams_m(iSimul, :)', 'o', ...
        'markerSize', markerSize, 'markerFaceColor', markerColor, 'markerEdgeColor', markerColor);
    
    text(axis_v(iSimul, 2) * 0.5, axis_v(iSimul, 4) * 0.95, ...
        paramNames{iSimul}, 'fontName', fontName, 'fontSize', titleFontSize, ...
        'horizontalalignment', 'center', 'verticalalignment', 'middle');
    
    if iSimul == 1 || iSimul == 5
        ylabel(y_label, 'fontName', fontName, 'fontSize', labelFontSize);
    end;
    xlabel(x_label, 'fontName', fontName, 'fontSize', labelFontSize);
    
    if p_Pearson < 0.001
        signifString = '***';
    elseif p_Pearson < 0.01
        signifString = '**';
    elseif p_Pearson < 0.05
        signifString = '*';
    else
        signifString = '';
    end;
    
    text((axis_v(iSimul, 2) - axis_v(iSimul, 1)) * 0.825, ...
        (axis_v(iSimul, 4) - axis_v(iSimul, 3)) * 0.075, ...
        ['\it{r} = ' num2str(round(r_Pearson, 2), '%.2f'), signifString], ...
        'horizontalalignment', 'center', ...
        'verticalalignment', 'middle', ...
        'fontName', fontName, 'fontSize', fontSize, ...
        'color', markerColor);
    
    axis(axis_v(iSimul, :));
    
    set(gca, 'xtick', x_tick(iSimul, :), 'ytick', y_tick(iSimul, :), ...
        'fontname', fontName, 'fontSize', fontSize);
    
    if options.save.modelsimulations && options.overwrite.modelsimulations
        export_fig([figsOutputDir filesep figureNames{iSimul}], '-r900', '-transparent', '-tiff');
        print([figsOutputDir filesep figureNames{iSimul}], '-r1000', '-dpdf');
        close(f);
        if options.verbose.modelsimulations
            disp('Panel B of Supplementary Results Figure 2 was partially overwritten.');
        end;
    end;
    
    iParam1 = iSimul;
    for iParam2 = 1:nModelParams
        [r_figSR2_m(iParam1, iParam2), p_figSR2_m(iParam1, iParam2)] = ...
            corr(simulParams_m(iParam1, :)', recoveredParams_m(iParam2, :)', 'type', 'Pearson');
    end;
    r_figSR2_m;
    p_figSR2_m;
    
    s = simulParams_m';
    r = recoveredParams_m';
    if options.save.modelsimulations && options.overwrite.modelsimulations
        save([outputDir filesep 'simul_params_' num2str(iSimul)], 's');
        save([outputDir filesep 'recov_params_' num2str(iSimul)], 'r');
        xlswrite([outputDir filesep 'simul_params_' num2str(iSimul) '.xls'], s);
        xlswrite([outputDir filesep 'recov_params_' num2str(iSimul) '.xls'], r);
        csvwrite([outputDir filesep 'simul_params_' num2str(iSimul) '.csv'], s);
        csvwrite([outputDir filesep 'recov_params_' num2str(iSimul) '.csv'], r);
        if options.verbose.modelsimulations
            disp(' ');
            disp('The output files from shellmdl_show_param_recovery_results were overwritten.');
        end;
    end;
end;

if options.verbose.modelsimulations
    disp(' ');
    disp('The correlation matrix between the simulated and fit parameter values is:');
    r_figSR2_m
    disp('The respective p-value matrix is:');
    p_figSR2_m
end;

if use_Holm_corrected_p_values
    disp('Using Holm-corrected p-values to generate Panel C...');
    disp(' ');
    if ~exist(paramRecoveryCorrectedPValuesFile, 'file')
        readyToProceed = input('Please run get_param_recovery_results_from_R and generate the respective .xls file (containing only the 7x7 matrix with numeric values) before proceeding.\nReady to proceed?\nPlease introduce 1 if so.\n');
        disp(' ');
        while ~readyToProceed
            readyToProceed = input('Please run get_param_recovery_results_from_R and generate the respective .xls file (containing only the 7x7 matrix with numeric values) before proceeding.\nReady to proceed?\nPlease introduce 1 if so.\n');
            disp(' ');
        end;
    else
        readyToProceed = input('Is the .xls file with the output from get_param_recovery_results_from_R correct?\nIf so, please introduce 1 to proceed.\n');
        disp(' ');
        while ~readyToProceed
            readyToProceed = input('Is the .xls file with the output from get_param_recovery_results_from_R correct?\nIf so, please introduce 1 to proceed.\n');
            disp(' ');
        end;
    end;
    p_figSR2_m = xlsread(paramRecoveryCorrectedPValuesFile); % note that this .xls file should be manually created from the .csv file saved by the R function
else
    disp('Using uncorrected p-values to generate Panel C...');
    disp(' ');
end;

%% Main Code - Panel C
set(0, 'DefaultAxesTitleFontWeight', 'bold');
f = figure();
set(f, 'name', 'Correlogram', 'units', 'centimeters', 'position', figDimensions2, ...
    'paperunits', 'centimeters', 'paperposition', figDimensions2);

if whiteShadingColorMap
    mymap(myMapWhiteFirst:myMapWhiteLast, :) = ones(myMapWhiteLast - myMapWhiteFirst + 1, 3);
end;

colormap(flipud(mymap))

hold on;
imagesc(r_figSR2_m');
caxis([-1 1]); colorbar;

% outer square:
plot([0.5, 7.5], [0.5, 0.5], '-', 'color', [0 0 0], 'LineWidth', 2);
plot([0.5, 7.5], [7.5, 7.5], '-', 'color', [0 0 0], 'LineWidth', 2);
plot([0.5, 0.5], [0.5, 7.5], '-', 'color', [0 0 0], 'LineWidth', 2);
plot([7.5, 7.5], [0.5, 7.5], '-', 'color', [0 0 0], 'LineWidth', 2);

for iParam1 = 1:nModelParams
    for iParam2 = 1:nModelParams
        if p_figSR2_m(iParam1, iParam2) < 0.001
            signficanceString = '***';
        elseif p_figSR2_m(iParam1, iParam2) < 0.01
            signficanceString = '**';
        elseif p_figSR2_m(iParam1, iParam2) < 0.05
            signficanceString = '*';
        else
            signficanceString = '';
        end;
        if p_figSR2_m(iParam1, iParam2) < 0.001
            fontSize_aux = fontSize - 1;
            fontWeight_aux = 'bold';
        elseif p_figSR2_m(iParam1, iParam2) < 0.05
            fontSize_aux = fontSize - 1;
            fontWeight_aux = 'normal';
        else
            fontSize_aux = fontSize - 1;
            fontWeight_aux = 'normal';
            
        end;
        text(iParam1, iParam2, [num2str(round(r_figSR2_m(iParam1, iParam2), 2), '%.2f') signficanceString], ...
            'horizontalalignment', 'center', ...
            'verticalalignment', 'middle', ...
            'color', 'k', 'fontWeight', fontWeight_aux, ...
            'fontName', fontName, 'fontSize', fontSize_aux);
    end;
end;

title('\it r', 'fontName', fontName, 'fontSize', titleFontSize);

axis([0.25, nModelParams + 0.75, 0.25, nModelParams + 0.75]);

set(gca, 'xtick', 1:nModelParams, 'xTickLabel', paramNames_mod, ...
    'ytick', 1:nModelParams, 'yTickLabel', paramNames_mod, ...
    'fontname', fontName, 'fontSize', fontSize + 1);

if options.save.modelsimulations && options.overwrite.modelsimulations
    if whiteShadingColorMap
        if use_Holm_corrected_p_values
            export_fig([figsOutputDir filesep 'Correlogram - Holm - white shading'], '-r900', '-transparent', '-tiff');
            print([figsOutputDir filesep 'Correlogram - Holm - white shading'], '-r1000', '-dpdf');
        else
            export_fig([figsOutputDir filesep 'Correlogram - white shading'], '-r900', '-transparent', '-tiff');
            print([figsOutputDir filesep 'Correlogram - white shading'], '-r1000', '-dpdf');
        end;
    else
        if use_Holm_corrected_p_values
            export_fig([figsOutputDir filesep 'Correlogram - Holm'], '-r900', '-transparent', '-tiff');
            print([figsOutputDir filesep 'Correlogram - Holm'], '-r1000', '-dpdf');
        else
            export_fig([figsOutputDir filesep 'Correlogram'], '-r900', '-transparent', '-tiff');
            print([figsOutputDir filesep 'Correlogram'], '-r1000', '-dpdf');
        end;
    end;
    if options.verbose.modelsimulations
        disp('Panel C of Supplementary Results Figure 2 was overwritten.');
    end;
end;
close(f);
end