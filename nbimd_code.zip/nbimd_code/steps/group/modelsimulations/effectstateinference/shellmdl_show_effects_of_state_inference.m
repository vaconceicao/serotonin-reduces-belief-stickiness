function [] = shellmdl_show_effects_of_state_inference(options, paths)
% [] = shellmdl_show_effects_of_state_inference(options, paths)
%
% shellmdl_show_effects_of_state_inference is a function that shows how
% (differente values of) gamma and zeta, the two state-inference
% paramenters, influence task performance.
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  [none]
%
% Author: Vasco A. Concei��o
%
% Last modified: October 2023

%% Settings
nSimulationsPerParam    = options.modelsimulations.effectofstateinference.nSimulationsPerParam;
inputFile           	= paths.results.group.modelsimulations.effectofstateinference.tempsession.all.aggregeffectofstateinferencefile; % suffix is added inside the cycle
outputDir               = paths.results.group.modelsimulations.effectofstateinferencedir;
figsOutputDir           = paths.results.group.modelsimulations.effectofstateinference.figuresdir;

%% Main Code
if ~exist(outputDir, 'dir')
    mkdir(outputDir);
end;
if ~exist(figsOutputDir, 'dir')
    mkdir(figsOutputDir);
end;

for iTypeOfSimulation = 1:options.modelsimulations.effectofstateinference.nTypesOfSimulations
    
    switch iTypeOfSimulation
        case 1
            paramString = 'gamma'; paramString2 = 'gamma';
            labelString = '\gamma';
            initSimul   = 0;                        % first set of simulations
            yMin        = options.figs.figSR1A.yMin;
            yMax        = options.figs.figSR1A.yMax;
            xMin        = options.figs.figSR1A.xMin;
            xMax        = options.figs.figSR1A.xMax;
            xlValue     = options.figs.figSR1A.xlValue;
            xrValue     = options.figs.figSR1A.xrValue;
            xmaxValue   = options.figs.figSR1A.xmaxValue;
            
        case 2
            paramString = 'zeta'; paramString2 = 'zeta';
            labelString = '\zeta';
            initSimul   = nSimulationsPerParam;     % second set of simulations
            yMin        = options.figs.figSR1B.yMin;
            yMax        = options.figs.figSR1B.yMax;
            xMin        = options.figs.figSR1B.xMin;
            xMax        = options.figs.figSR1B.xMax;
            xlValue     = options.figs.figSR1B.xlValue;
            xrValue     = options.figs.figSR1B.xrValue;
            
        case 3
            paramString = 'a larger zeta'; paramString2 = 'larger_zeta';
            labelString = '\zeta';
            initSimul   = 2 * nSimulationsPerParam; % third set of simulations
            yMin        = options.figs.figSR1C.yMin;
            yMax        = options.figs.figSR1C.yMax;
            xMin        = options.figs.figSR1C.xMin;
            xMax        = options.figs.figSR1C.xMax;
    end;
    
    if options.verbose.modelsimulations
        disp(' ');
        disp('--------------------------------------------------------------');
        disp(['Running shellmdl_show_effects_of_state_inference for ' paramString '...']);
    end;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    mean_number_correct_answers_v  = -Inf * ones(nSimulationsPerParam, 1);
    param_aux_v                    = -Inf * ones(nSimulationsPerParam, 1);
    
    for iSimul = 1:nSimulationsPerParam
        auxInputFile = [inputFile(1:(end-4)) '-' num2str(iSimul + initSimul) '.mat'];
        load(auxInputFile);
        
        switch iTypeOfSimulation
            case 1
                param_aux = params_all_subjects(1, 6); % all subjects have the same gamma value in each simulation; 6 is the parameter number for gamma in S-S-R-8, the selected model
            case {2, 3}
                param_aux = params_all_subjects(1, 7); % all subjects have the same zeta value in each simulation; 7 is the parameter number for zeta in S-S-R-8, the selected model
        end;
        
        mean_number_correct_answers_v(iSimul) = mean(number_correct_answers);
        param_aux_v(iSimul) = param_aux;
    end;
    
    param_v_c = param_aux_v - mean(param_aux_v);
    
    if options.verbose.modelsimulations
        disp(' ');
        disp('The following set of results were obtained when using polynomial fit 1-3 for the centered parameter values:...');
        disp(' ');
        
        % Poly 1
        poly1_model_c   = fitlm(param_v_c, mean_number_correct_answers_v)
        poly1_c_AIC     = poly1_model_c.ModelCriterion.AIC
        poly1_c_BIC     = poly1_model_c.ModelCriterion.BIC
        
        % Poly 2
        poly2_model_c   = fitlm([param_v_c, param_v_c.^2], mean_number_correct_answers_v)
        poly2_c_AIC     = poly2_model_c.ModelCriterion.AIC
        poly2_c_BIC     = poly2_model_c.ModelCriterion.BIC
        
        % Poly 3
        poly3_model_c   = fitlm([param_v_c, param_v_c.^2, param_v_c.^3], mean_number_correct_answers_v)
        poly3_c_AIC     = poly3_model_c.ModelCriterion.AIC
        poly3_c_BIC     = poly3_model_c.ModelCriterion.BIC
        poly3_c_CI      = coefCI(poly3_model_c)
    end;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if iTypeOfSimulation == 3
        f       = figure();
        figName = ['Proof-of-concept Simulations for ' paramString ' - Poly1 Fit'];
        set(f, 'name', figName, 'units', 'centimeters', 'position', options.figs.figSR1.dimensions, ...
            'paperunits', 'centimeters', 'paperposition', options.figs.figSR1.dimensions);
        hold all;
        
        [fitted_acc_1, gof_1] = fit(param_aux_v, mean_number_correct_answers_v, 'poly1');
        plot(param_aux_v, mean_number_correct_answers_v, 'o', 'markerSize', 3, ...
            'markerFaceColor', 'k', 'markerEdgeColor', 'k');
        plot(sort(param_aux_v), fitted_acc_1.p2 + fitted_acc_1.p1 * sort(param_aux_v), '-b', 'Linewidth', 2);
        
        xlabel(labelString, 'fontname', 'Arial', 'fontsize', 9);
        ylabel(options.figs.figSR1.ylabel, 'fontname', 'Arial', 'fontsize', 9);
        axis([xMin xMax yMin yMax]);
        set(gca, 'ytick', yMin:2:yMax, 'fontname', 'Arial', 'fontsize', 8);
        
        if options.save.modelsimulations && options.overwrite.modelsimulations
            export_fig([figsOutputDir filesep figName], '-r800', '-tiff', '-nocrop', '-transparent');
            
            if options.verbose.modelsimulations
                disp(' ');
                disp(['The figure for ' paramString ' was overwritten.']);
            end;
        end;
    end;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if iTypeOfSimulation < 3
        f       = figure();
        figName = ['Proof-of-concept Simulations for ' paramString ' - Poly3 Fit'];
        set(f, 'name', figName, 'units', 'centimeters', 'position', options.figs.figSR1.dimensions, ...
            'paperunits', 'centimeters', 'paperposition', options.figs.figSR1.dimensions);
        hold all;
        
        [fitted_acc_3, gof_3] = fit(param_aux_v, mean_number_correct_answers_v, 'poly3');
        plot(param_aux_v, mean_number_correct_answers_v, 'o', 'markerSize', 3, ...
            'markerFaceColor', 'k', 'markerEdgeColor', 'k');
        plot(sort(param_aux_v), fitted_acc_3.p4 + fitted_acc_3.p3 * sort(param_aux_v) + fitted_acc_3.p2 * (sort(param_aux_v).^2) + fitted_acc_3.p1 * (sort(param_aux_v).^3), '-b', 'Linewidth', 2);
        
        plot([xlValue, xlValue], [yMin, yMax], '--r');
        plot([xrValue, xrValue], [yMin, yMax], '--r');
        
        if iTypeOfSimulation == 1
            plot([xmaxValue, xmaxValue], [yMin, yMax], '--', 'color', [0.3 0.3 0.3]);
        end;
        
        xlabel(labelString, 'fontname', 'Arial', 'fontsize', 9);
        ylabel(options.figs.figSR1.ylabel, 'fontname', 'Arial', 'fontsize', 9);
        axis([xMin xMax yMin yMax]);
        set(gca, 'ytick', yMin:2:yMax, 'fontname', 'Arial', 'fontsize', 8);
        
        if options.save.modelsimulations && options.overwrite.modelsimulations
            export_fig([figsOutputDir filesep figName], '-r800', '-tiff', '-nocrop', '-transparent');
            
            if options.verbose.modelsimulations
                disp(' ');
                disp(['The figure for ' paramString ' was overwritten.']);
            end;
        end;
    end;
    
    if options.save.modelsimulations && options.overwrite.modelsimulations
        save([outputDir filesep 'show_effects_of_state_inference_results_' paramString2]);
        
        if options.verbose.modelsimulations
            disp(' ');
            disp(['The output file of shellmdl_show_effects_of_state_inference for ' paramString ' was overwritten.']);
        end;
    end;
end