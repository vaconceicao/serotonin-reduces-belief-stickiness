function [] = shellmdl_load_modelsimulations_effectofstateinference_results(options, paths)
% [] = shellmdl_load_modelsimulations_effectofstateinference_results(options, paths)
%
% shellmdl_load_modelsimulations_effectofstateinference_results is a
% function called by shellmdl_master, which copies the previously obtained
% results from paths.previousresultsdir (the folder where those files
% should be stored) into paths.resultsdir (the new results folder). In
% doing so, this function generates (or overwrites) the results (that would
% be) obtained by running the model-simulations pipeline aimed at showing
% the effects of state inference on task performance, allowing to minimize
% computation time. To run this function, instead of the respective
% model-simulations pipeline,
% options.load.modelsimulations.effectofstateinference and
% options.run.modelsimulations.effectofstateinference should be set to 1
% and 0, respectively, in shellmdl_set_analysis_options.
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  shellmdl_paths
%
% Author: Vasco A. Concei��o
%
% Last modified: November 2023

%% Settings
prDir = [paths.previousresultsdir filesep 'modelsimulations' filesep 'effectofstateinference'];     % previous results folder

prDir_all       = [prDir filesep 'all'];
prDir_individ   = [prDir filesep 'individ'];
prDir_all_figs 	= [prDir_all filesep 'figures'];

%% Main Code - Initialization
if ~exist(prDir, 'dir')
    mkdir(prDir);
end;
if ~exist(prDir_all, 'dir')
    mkdir(prDir_all);
end;
if ~exist(prDir_individ, 'dir')
    mkdir(prDir_individ);
end;
if ~exist(prDir_all_figs, 'dir')
    mkdir(prDir_all_figs);
end;

if options.verbose.modelsimulations
    disp(' ');
    disp('--------------------------------------------------------------');
    disp('Running shellmdl_load_modelsimulations_effectofstateinference_results...');
end;

%% Main Code - Copy the output files from shellmdl_loop_simulate_subj_behavior & shellmdl_aggreg_simulated_behavior
iModel      = options.modelsimulations.effectofstateinference.iModelNumber;
paths       = shellmdl_paths(paths, 1, -1, iModel, options);                                    % -1 is the subject error code
rDir_group  = paths.results.group.modelsimulations.effectofstateinference.tempsession.alldir;  	% results folder

if ~exist(rDir_group, 'dir')
    mkdir(rDir_group);
end;

for iSimul = 1:options.modelsimulations.effectofstateinference.nSimulations
    
    if options.verbose.modelsimulations 
        if iSimul < options.modelsimulations.effectofstateinference.nSimulations
            disp(['... for simulation ' num2str(iSimul) ' out of ' num2str(options.modelsimulations.effectofstateinference.nSimulations) ';']);
        else
            disp(['... for simulation ' num2str(iSimul) ' out of ' num2str(options.modelsimulations.effectofstateinference.nSimulations) '.']);
        end;
    end;
    
    % shellmdl_loop_simulate_subj_behavior:
    rFile_group     = [paths.results.group.modelsimulations.effectofstateinference.tempsession.all.effectofstateinferencefile(1:(end-4)) '-' num2str(iSimul) '.mat'];
    % copyfile(rFile_group, prDir_all); % this line is commented intentionally; it was ran to obtain the previous results files
    
    prFile_group    = [prDir_all filesep 'simulation_results-' num2str(iSimul) '.mat'];
    copyfile(prFile_group, rDir_group);
    
    for s = 1:options.dataset.nEffSubjects
        subj            = options.dataset.subjects(s);
        paths           = shellmdl_paths(paths, 1, subj, iModel, options);
        
        rDir_individ    = paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelsimulations.effectofstateinferencedir;
        rFile_individ   = [paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelsimulations.effectofstateinferencefile(1:(end - 4)) '-' num2str(iSimul) '.mat'];
        % copyfile(rFile_individ, prDir_individ); % this line is commented intentionally; it was ran to obtain the previous results files
        
        prFile_individ  = [prDir_individ filesep 'simulResults-' num2str(subj) '-' num2str(iSimul) '.mat'];
        if ~exist(rDir_individ, 'dir')
            mkdir(rDir_individ);
        end;
        copyfile(prFile_individ, rDir_individ);
    end;
    
    % shellmdl_aggreg_simulated_behavior:
    rFile_group     = [paths.results.group.modelsimulations.effectofstateinference.tempsession.all.aggregeffectofstateinferencefile(1:(end-4)) '-' num2str(iSimul) '.mat'];
    % copyfile(rFile_group, prDir_all); % this line is commented intentionally; it was ran to obtain the previous results files
    
    prFile_group    = [prDir_all filesep 'aggreg_simul_results-' num2str(iSimul) '.mat'];
    copyfile(prFile_group, rDir_group);
end;

%% Main Code - Copy the output files from shellmdl_show_effects_of_state_inference
rDir_group      = paths.results.group.modelsimulations.effectofstateinferencedir;
rDir_group_figs = paths.results.group.modelsimulations.effectofstateinference.figuresdir;

if ~exist(rDir_group, 'dir')
    mkdir(rDir_group);
end;
if ~exist(rDir_group_figs, 'dir')
    mkdir(rDir_group_figs);
end;

for iTypeOfSimulation = 1:options.modelsimulations.effectofstateinference.nTypesOfSimulations
    switch iTypeOfSimulation
        case 1
            paramString = 'gamma';
        case 2
            paramString = 'zeta';
        case 3
            paramString = 'larger_zeta';
    end;
    rFile_group = [rDir_group filesep 'show_effects_of_state_inference_results_' paramString '.mat'];
    % copyfile(rFile_group, prDir_all); % this line is commented intentionally; it was ran to obtain the previous results files
    
    prFile_group = [prDir_all filesep 'show_effects_of_state_inference_results_' paramString '.mat'];
    copyfile(prFile_group, rDir_group);
end;

rFig1 = [rDir_group_figs filesep 'Proof-of-concept Simulations for gamma - Poly3 Fit.tif'];
rFig2 = [rDir_group_figs filesep 'Proof-of-concept Simulations for zeta - Poly3 Fit.tif'];
rFig3 = [rDir_group_figs filesep 'Proof-of-concept Simulations for a larger zeta - Poly1 Fit.tif'];

% copyfile(rFig1, prDir_all_figs); % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFig2, prDir_all_figs); % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFig3, prDir_all_figs); % this line is commented intentionally; it was ran to obtain the previous results files

prFig1 = [prDir_all_figs filesep 'Proof-of-concept Simulations for gamma - Poly3 Fit.tif'];
prFig2 = [prDir_all_figs filesep 'Proof-of-concept Simulations for zeta - Poly3 Fit.tif'];
prFig3 = [prDir_all_figs filesep 'Proof-of-concept Simulations for a larger zeta - Poly1 Fit.tif'];

copyfile(prFig1, rDir_group_figs);
copyfile(prFig2, rDir_group_figs);
copyfile(prFig3, rDir_group_figs);

end