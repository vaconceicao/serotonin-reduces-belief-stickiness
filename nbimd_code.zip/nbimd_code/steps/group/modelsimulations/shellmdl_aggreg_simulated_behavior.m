function [] = shellmdl_aggreg_simulated_behavior(options, paths, iSimul, iModel, inputFileInfo, outputDir, outputFile)
% [] = shellmdl_aggreg_simulated_behavior(options, paths, iSimul, iModel, inputFileInfo, outputDir, outputFile)
%
% shellmdl_aggreg_simulated_behavior is a function that aggregates the
% behavior simulated previously using shellmdl_loop_simulate_subj_behavior.
% (Note, however, that shellmdl_loop_simulate_subj_behavior already 
% aggregates some of the data across subjects.)
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  [none]
%
% Author: Vasco A. Concei��o
%
% Last modified: October 2023

%% Init
soi         = options.dataset.subjects;
nEffSubj    = numel(soi);

modelName   = options.rl.modelNames{iModel};

%% Main Code
if options.verbose.modelsimulations
    disp(' ');
    disp(['Running shellmdl_aggreg_simulated_behavior: simulation ' num2str(iSimul) ' - model ' modelName '...']);
end;

load([paths.results.group.behavior2modeldir filesep 'states_m']);
load([paths.results.group.behavior2modeldir filesep 'phases_m']);

number_correct_answers  = zeros(nEffSubj, 1);
params_all_subjects     = -Inf * ones(nEffSubj, options.rl.nParams(iModel));

for iSubj = 1:nEffSubj
    subj    = soi(iSubj);
    
    paths   = shellmdl_paths(paths, 1, subj, iModel, options);
    if isequal(inputFileInfo, 'effectofstateinference')
        inputFile = paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelsimulations.effectofstateinferencefile;
    elseif isequal(inputFileInfo, 'modelrecovery')
        inputFile = paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelsimulations.modelrecoveryfile;
    elseif isequal(inputFileInfo, 'paramrecovery')
        inputFile = paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelsimulations.paramrecoveryfile;
    end;
    subjInputFile   = [inputFile(1:(end - 4)) '-' num2str(iSimul) '.mat'];
    load(subjInputFile);
    
    for iTrial = 1:options.dataset.nTrials
        corrAction = options.dataset.state2correctaction(stim_seq(iTrial), phases_m(subj, iTrial));
        number_correct_answers(iSubj) = number_correct_answers(iSubj) + (act_v(iTrial) == corrAction);
    end;
    number_correct_answers(iSubj) = number_correct_answers(iSubj);
    params_all_subjects(iSubj, :) = params;
end;

%% Save
if options.save.modelsimulations && options.overwrite.modelsimulations
    if ~exist(outputDir, 'dir')
        mkdir(outputDir);
    end;
    if options.verbose.modelsimulations
        disp(' The output file from shellmdl_aggreg_simulated_behavior was overwritten.');
    end;
end;
save(outputFile, 'number_correct_answers', 'params_all_subjects');