function [] = shellmdl_load_modelsimulations_modelrecovery_results(options, paths)
% [] = shellmdl_load_modelsimulations_modelrecovery_results(options, paths)
%
% shellmdl_load_modelsimulations_modelrecovery_results is a function called 
% by shellmdl_master, which copies the previously obtained results from 
% paths.previousresultsdir (the folder where those files should be stored) 
% into paths.resultsdir (the new results folder). In doing so, this 
% function generates (or overwrites) the results (that would be) obtained 
% by running the model-recovery simulations pipeline, allowing to minimize 
% computation time. To run this function, instead of the respective 
% model-simulations pipeline, options.load.modelsimulations.modelrecovery 
% and options.run.modelsimulations.modelrecovery should be set to 1
% and 0, respectively, in shellmdl_set_analysis_options.
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  shellmdl_paths
%
% Author: Vasco A. Concei��o
%
% Last modified: November 2023

%% Settings
prDir = [paths.previousresultsdir filesep 'modelsimulations' filesep 'modelrecovery'];     % previous results folder

prDir_all           = [prDir filesep 'all'];
prDir_individ_model = [prDir filesep 'individ_model'];
prDir_all_figs      = [prDir_all filesep 'figures'];

%% Main Code - Initialization
if ~exist(prDir, 'dir')
    mkdir(prDir);
end;
if ~exist(prDir_all, 'dir')
    mkdir(prDir_all);
end;
if ~exist(prDir_individ_model, 'dir')
    mkdir(prDir_individ_model);
end;
if ~exist(prDir_all_figs, 'dir')
    mkdir(prDir_all_figs);
end;

if options.verbose.modelsimulations
    disp(' ');
    disp('--------------------------------------------------------------');
    disp('Running shellmdl_load_modelsimulations_modelrecovery_results...');
end;

%% Main Code - Copy the output files from shellmdl_loop_simulate_subj_behavior & shellmdl_aggreg_simulated_behavior
for iSimul = 1:options.modelsimulations.modelrecovery.nSimulations
    if options.verbose.modelsimulations
        if iSimul < options.modelsimulations.modelrecovery.nSimulations
            disp(['... for simulation ' num2str(iSimul) ' out of ' num2str(options.modelsimulations.modelrecovery.nSimulations) ';']);
        else
            disp(['... for simulation ' num2str(iSimul) ' out of ' num2str(options.modelsimulations.modelrecovery.nSimulations) '.']);
        end;
    end;

    simulType   = ceil(iSimul / options.modelsimulations.modelrecovery.nSimulationsPerModel);
    iModel      = options.modelsimulations.modelrecovery.iModelNumbers(simulType);
    paths       = shellmdl_paths(paths, 1, -1, iModel, options); % -1 is the subject error code

    % shellmdl_loop_simulate_subj_behavior:
    rDir_group  = paths.results.group.modelsimulations.modelrecovery.tempsession.alldir;
    rFile_group = [paths.results.group.modelsimulations.modelrecovery.tempsession.all.modelrecoveryfile(1:(end-4)) '-' num2str(iSimul) '.mat'];

    % copyfile(rFile_group, prDir_all); % this line is commented intentionally; it was ran to obtain the previous results files

    if ~exist(rDir_group, 'dir')
        mkdir(rDir_group);
    end;

    prFile_group = [prDir_all filesep 'simulation_results-' num2str(iSimul) '.mat'];
    copyfile(prFile_group, rDir_group);
    
    prDir_individ_model_spec = [prDir_individ_model filesep options.mcmc.modelNames{iModel}];   % previous results folder
    if ~exist(prDir_individ_model_spec, 'dir')
        mkdir(prDir_individ_model_spec);
    end;
    
    for s = 1:options.dataset.nEffSubjects
        subj            = options.dataset.subjects(s);
        paths           = shellmdl_paths(paths, 1, subj, iModel, options);

        % shellmdl_loop_simulate_subj_behavior:
        rDir_individ    = paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelsimulations.modelrecoverydir;
        rFile_individ   = [paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelsimulations.modelrecoveryfile(1:(end - 4)) '-' num2str(iSimul) '.mat'];

        prDir_individ_model_spec_subj = [prDir_individ_model_spec filesep ['subject-' num2str(subj)]];
        if ~exist(prDir_individ_model_spec_subj, 'dir')
            mkdir(prDir_individ_model_spec_subj);
        end;

        % copyfile(rFile_individ, prDir_individ_model_spec_subj); % this line is commented intentionally; it was ran to obtain the previous results files

        prFile_individ  = [prDir_individ_model_spec_subj filesep 'simulResults-' num2str(subj) '-' num2str(iSimul) '.mat'];
        if ~exist(rDir_individ, 'dir')
            mkdir(rDir_individ);
        end;
        copyfile(prFile_individ, rDir_individ);
    end;

    % shellmdl_aggreg_simulated_behavior:
    rFile_group     = [paths.results.group.modelsimulations.modelrecovery.tempsession.all.aggregmodelrecoveryfile(1:(end-4)) '-' num2str(iSimul) '.mat'];
    % copyfile(rFile_group, prDir_all); % this line is commented intentionally; it was ran to obtain the previous results files

    prFile_group    = [prDir_all filesep 'aggreg_simul_results-' num2str(iSimul) '.mat'];
    copyfile(prFile_group, rDir_group);
end;

%% Main Code - Copy the output files from shellmdl_loop_subj_invert_model
firstSubj           = min(options.dataset.subjects);
lastSubj            = max(options.dataset.subjects);
subjsOfInterest_v   = options.dataset.subjects;

if options.verbose.modelsimulations
    disp(' ');
    disp('Running the second cycle of shellmdl_load_modelsimulations_modelrecovery_results...');
end;

for iProcedure = options.modelsimulations.modelrecovery.firstProcedure:options.modelsimulations.modelrecovery.lastProcedure
    if options.verbose.modelsimulations
        if iProcedure < options.modelsimulations.modelrecovery.lastProcedure
            disp(['... for procedure ' num2str(iProcedure) ' out of ' num2str(options.modelsimulations.modelrecovery.lastProcedure) ';']);
        else
            disp(['... for procedure ' num2str(iProcedure) ' out of ' num2str(options.modelsimulations.modelrecovery.lastProcedure) '.']);
        end;
    end;

    iProcedure_aux = mod(iProcedure, options.modelsimulations.modelrecovery.nSimulations);      % each set of simulated data was fit by all candidate models
    if iProcedure_aux == 0
        iProcedure_aux = options.modelsimulations.modelrecovery.nSimulations;
    end;
    iModel  = options.modelsimulations.modelrecovery.iModelNumbers(iProcedure_aux);
    
    prDir_individ_model_spec = [prDir_individ_model filesep options.mcmc.modelNames{iModel}];   % previous results folder
    if ~exist(prDir_individ_model_spec, 'dir')
        mkdir(prDir_individ_model_spec);
    end;
    
    for subj = firstSubj:1:lastSubj
        if ismember(subj, subjsOfInterest_v)
            paths   = shellmdl_paths(paths, options.dataset.session, subj, iModel, options);
            
            simulatedDataset                    = ceil(iProcedure / options.modelsimulations.modelrecovery.nSimulations);
            rDir_individ_model_spec_subj_simul  = [getfield(paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelsimulations, 'modelrecoverydir') filesep num2str(simulatedDataset)];
            
            rFile = [rDir_individ_model_spec_subj_simul, filesep, options.modelsimulations.modelrecovery.fileNames{1}, num2str(subj), '.mat'];
            
            prDir_individ_model_spec_subj_simul = [prDir_individ_model_spec filesep ['subject-' num2str(subj)] filesep ['simul-' num2str(simulatedDataset)]];
            if ~exist(prDir_individ_model_spec_subj_simul, 'dir')
                mkdir(prDir_individ_model_spec_subj_simul);
            end;
            
            % copyfile(rFile, prDir_individ_model_spec_subj_simul); % this line is commented intentionally; it was ran to obtain the previous results files
            
            prFile = [prDir_individ_model_spec_subj_simul, filesep, options.modelsimulations.modelrecovery.fileNames{1}, num2str(subj), '.mat'];
            
            if ~exist(rDir_individ_model_spec_subj_simul, 'dir')
                mkdir(rDir_individ_model_spec_subj_simul);
            end;
            
            copyfile(prFile, rDir_individ_model_spec_subj_simul);
            
        end;
    end;
end;

%% Main Code - Copy the output files from shellmdl_show_model_recovery_results
rDir            = paths.results.group.modelsimulations.modelrecovery.tempsession.alldir;
rDir_figures 	= paths.results.group.modelsimulations.modelrecovery.tempsession.all.figuresdir;

rFile = [rDir filesep 'confusion_matrix_peps.mat'];
rFig1 = [rDir_figures filesep options.figs.figSR2A.name '.tif'];
rFig2 = [rDir_figures filesep options.figs.figSR2A.name '.eps'];
rFig3 = [rDir_figures filesep options.figs.figSR2A.name '.pdf'];

% copyfile(rFile, prDir_all);       % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFig1, prDir_all_figs);  % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFig2, prDir_all_figs);  % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFig3, prDir_all_figs);  % this line is commented intentionally; it was ran to obtain the previous results files

prFile = [prDir_all filesep 'confusion_matrix_peps.mat'];
prFig1 = [prDir_all_figs filesep options.figs.figSR2A.name '.tif'];
prFig2 = [prDir_all_figs filesep options.figs.figSR2A.name '.eps'];
prFig3 = [prDir_all_figs filesep options.figs.figSR2A.name '.pdf'];

if ~exist(rDir, 'dir')
    mkdir(rDir);
end;
if ~exist(rDir_figures, 'dir')
    mkdir(rDir_figures);
end;

copyfile(prFile, rDir);
copyfile(prFig1, rDir_figures);
copyfile(prFig2, rDir_figures);
copyfile(prFig3, rDir_figures);

end