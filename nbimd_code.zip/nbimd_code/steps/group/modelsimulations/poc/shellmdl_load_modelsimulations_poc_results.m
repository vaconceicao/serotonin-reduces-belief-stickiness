function [] = shellmdl_load_modelsimulations_poc_results(options, paths)
% [] = shellmdl_load_modelsimulations_poc_results(options, paths)
%
% shellmdl_load_modelsimulations_poc_results is a function called by
% shellmdl_master, which copies the previously obtained results from
% paths.previousresultsdir (the folder where those files should be stored)
% into paths.resultsdir (the new results folder). In doing so, this
% function generates (or overwrites) the results (that would be) obtained
% by running the proof-of-concept model-simulations pipeline, allowing to
% minimize computation time. To run this function, instead of the full
% proof-of-concept model-simulations pipeline,
% options.load.modelsimulations.poc and options.run.modelsimulations.poc
% should be set to 1 and 0, respectively, in shellmdl_set_analysis_options.
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  shellmdl_paths
%
% Author: Vasco A. Concei��o
%
% Last modified: November 2023

%% Settings
prDir = [paths.previousresultsdir filesep 'modelsimulations' filesep 'poc'];  	% previous results folder

prDir_fict_individ  = [prDir filesep 'fict_individ'];
prDir_figs          = [prDir_fict_individ filesep 'figures'];

%% Main Code - Initialization
if ~exist(prDir, 'dir')
    mkdir(prDir);
end;
if ~exist(prDir_fict_individ, 'dir')
    mkdir(prDir_fict_individ);
end;
if ~exist(prDir_figs, 'dir')
    mkdir(prDir_figs);
end;

if options.verbose.datapreprocessing
    disp(' ');
    disp('--------------------------------------------------------------');
    disp('Running shellmdl_load_modelsimulations_poc_results...');
end;

%% Main Code - Copy the output files from shellmdl_show_belief_pliability
rDir = paths.results.modelsimulations.pocdir;                                       % results folder

for iSimul = 1:options.figs.figM3.nPanels
    rFile1 = [rDir filesep options.figs.figM3.figName '_' num2str(iSimul) '.mat'];  % results file 1
    rFile2 = [rDir filesep options.figs.figM3.figName '_' num2str(iSimul) '.xls'];  % results file 2
    
    % copyfile(rFile1, prDir_fict_individ); % this line is commented intentionally; it was ran to obtain the previous results files
    % copyfile(rFile2, prDir_fict_individ); % this line is commented intentionally; it was ran to obtain the previous results files
    
    prFile1 = [prDir_fict_individ filesep options.figs.figM3.figName '_' num2str(iSimul) '.mat']; % previous results file 1
    prFile2 = [prDir_fict_individ filesep options.figs.figM3.figName '_' num2str(iSimul) '.xls']; % previous results file 2
    if ~exist(rDir, 'dir')
        mkdir(rDir);
    end;
    copyfile(prFile1, rDir);
    copyfile(prFile2, rDir);
end;

rDir_figs = [paths.results.modelsimulations.poc.figuresdir];

rFig1 = [rDir_figs filesep options.figs.figM3.figName '.eps'];
rFig2 = [rDir_figs filesep options.figs.figM3.figName '.tif'];

% copyfile(rFig1, prDir_figs); % this line is commented intentionally; it was ran to obtain the previous results files
% copyfile(rFig2, prDir_figs); % this line is commented intentionally; it was ran to obtain the previous results files

prFig1 = [prDir_figs filesep options.figs.figM3.figName '.eps'];
prFig2 = [prDir_figs filesep options.figs.figM3.figName '.tif'];
if ~exist(rDir_figs, 'dir')
    mkdir(rDir_figs);
end;
copyfile(prFig1, rDir_figs);
copyfile(prFig2, rDir_figs);

end