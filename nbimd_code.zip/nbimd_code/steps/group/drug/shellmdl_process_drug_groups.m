function [onDrugSubjs, offDrugSubjs, drugLevels] = shellmdl_process_drug_groups(options, paths)
% [] = shellmdl_process_drug_groups(options, paths)
%
% shellmdl_process_drug_groups is a function that obtains the drug-related 
% information of interest, from the files that were manually preprocessed 
% previously .
%
% Called in:
%   shellmdl_assess_btw_group_differences_in_model_frequencies
%
% List of key auxiliary functions:
%   [none]
%
% Author: Vasco A. Concei��o
%
% Last modified: September 2023

%% Main code:
drugDataFolder          = paths.results.group.drugdir;
drugLevelsFile          = [drugDataFolder filesep 'escitalopramLevels.mat'];
drugGroupsFile          = [drugDataFolder filesep 'escitalopramGroup.mat'];

load(drugLevelsFile);
load(drugGroupsFile);

drug.on.subjectIDs      = (options.dataset.subjects(escitalopramGroup == 1))';
drug.on.plasmaLevels    = escitalopramLevels(escitalopramGroup == 1);

drug.off.subjectIDs   	= (options.dataset.subjects(escitalopramGroup == 0))';

%% Saving:
onDrugSubjs             = drug.on.subjectIDs;
offDrugSubjs            = drug.off.subjectIDs;
drugLevels              = drug.on.plasmaLevels;

end

