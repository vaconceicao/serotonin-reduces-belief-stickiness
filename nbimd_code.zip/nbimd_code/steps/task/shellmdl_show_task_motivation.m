function [] = shellmdl_show_task_motivation(options, paths)
% [] = shellmdl_show_task_motivation(options, paths)
%
% shellmdl_show_task_motivation is a function that depicts the motivation 
% underlying the use of a reversal-learning task (Figure 2 of the paper).
% It inputs "options", a struct that fully configures how this
% function is run, and "paths", a struct that contains all path-related
% information.
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  [none]
%
% Author: Vasco A. Concei��o
%
% Last modified: April 2024

%%
if options.verbose.taskmotivation
    disp(' ');
    disp('--------------------------------------------------------------');
    disp('Running shellmdl_show_task_motivation...');
end;

%% Settings
% Task
nStates             = options.taskmotivation.nStates;
nPhases             = options.taskmotivation.nPhases;
nTrialsPerPhase     = options.taskmotivation.nTrialsPerPhase;
nTrials             = options.taskmotivation.nTrials;

reinf1              = options.taskmotivation.reinf1;    % first season is punishing
reinf2              = options.taskmotivation.reinf2;    % second season is rewarding

% Subject
alpha               = options.taskmotivation.alpha;     % single learning rate
beta                = options.taskmotivation.beta;      % single inverse temperature

gamma               = options.taskmotivation.gamma;     % to depict a subject with "optimal" state inference
zeta                = options.taskmotivation.zeta;      % to depict a subject with "optimal" state inference

% Figure
figSize             = options.figs.fig2.figSize;
figName             = options.figs.fig2.figName;
figRes              = options.figs.fig2.figRes;

fontName            = options.figs.fig2.fontName;
fontSize            = options.figs.fig2.fontSize;
% legendFontSize      = options.figs.fig2.legendFontSize;
% labelFontSize       = options.figs.fig2.labelFontSize;

phaseColors         = options.taskmotivation.phaseColors;

phasePositionsX     = options.figs.fig2.phasePositionsX;
phasePositionsY     = options.figs.fig2.phasePositionsY;

srLearnerColor      = options.figs.fig2.srLearnerColor;
stateInferenceColor = options.figs.fig2.stateInferenceColor;
% legendString        = options.figs.fig2.legendString;

axis_v              = options.figs.fig2.axis_v;

%% Main Code
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initialization
currHS              = 1; 
beliefs             = [1/nStates; 1/nStates]; % current beliefs
beliefs_m           = zeros(2, nTrialsPerPhase * nPhases); % matrix; 
% stores the current beliefs (that is, the beliefs being used on each trial)
p_reinfs_hs         = [1 1 1; 1 1 1]; % stores the number of counts
% for -1, 1, and 0, respectively; these are the counts for the 3 possible 
% reinforcements in the Shell game (but, in this simplified example, we're 
% only using -1 and 1, for simplicity)

srLearnerValues_v               = 0;        % vector; stores the current Q(stimulus, action) values
stateInferenceValues_v          = 0;        % vector; stores the current Q(stimulus state, action) values
currHS_v                        = currHS;   % vector; stores the currently inferred (hidden) states

srLearnerProbabilities_v        = [];       % vector; stores the current p(Go) for the stimulus-response learner
stateInferenceProbabilities_v   = [];       % vector; stores the current p(Go) for the stimulus's state-response learner

stateInferenceValues_m          = zeros(nStates, nTrialsPerPhase * nPhases + 1); % maximum of 2 (hidden) states, because we're only using 2 reinforcements

eff_reinf_v                     = [];   % vector; stores the reinforcements that were effectively obtained on each trial

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate values
for iTrial = 1:(nTrialsPerPhase * nPhases)
    if ceil(iTrial/nTrialsPerPhase) == 1 || ceil(iTrial/nTrialsPerPhase) == 3   % first state; phases 1 and 3
        eff_reinf       = reinf1;
        eff_reinf_index = 1;
    else                                                                        % second state; phases 2 and 4
        eff_reinf       = reinf2;
        eff_reinf_index = 2;
    end;
    
    srLearnerValues_v = [srLearnerValues_v, srLearnerValues_v(end) + alpha * (eff_reinf - srLearnerValues_v(end))];
    
    if currHS == 1
        otherHS = 2;
    else
        otherHS = 1;
    end;
    
    beliefs = beliefs .^ gamma;
    beliefs = beliefs / sum(beliefs);
    
    beliefs = beliefs .* p_reinfs_hs(:, eff_reinf_index) ./ sum(p_reinfs_hs, 2);
    beliefs = beliefs / sum(beliefs);
    
    if (beliefs(currHS) + zeta) < beliefs(otherHS)
        currHS_old = currHS;
        currHS = otherHS;
        otherHS = currHS_old;
    end;
    p_reinfs_hs(currHS, eff_reinf_index) = p_reinfs_hs(currHS, eff_reinf_index) + 1;
    
    stateInferenceValues_m(currHS, iTrial+1)    = stateInferenceValues_m(currHS, iTrial) + alpha * (eff_reinf - stateInferenceValues_m(currHS, iTrial));
    stateInferenceValues_m(otherHS, iTrial+1)   = stateInferenceValues_m(otherHS, iTrial);
    
    currHS_v                = [currHS_v, currHS];
    stateInferenceValues_v  = [stateInferenceValues_v, stateInferenceValues_m(currHS, iTrial + 1)];
    beliefs_m(:, iTrial)    = beliefs;
    eff_reinf_v             = [eff_reinf_v, eff_reinf];

    srLearnerProbabilities_v        = [srLearnerProbabilities_v , 1 / (1 + exp(-beta * srLearnerValues_v(iTrial)))];
    stateInferenceProbabilities_v   = [stateInferenceProbabilities_v, 1 / (1 + exp(-beta * stateInferenceValues_v(iTrial)))];
end;

%% Plot
f = figure();
set(f, 'Name', figName, 'Units', 'Centimeters', 'Position', figSize, ...
    'PaperUnits', 'Centimeters', 'PaperPosition', figSize);

hold on;
plot(1:nTrials, stateInferenceProbabilities_v, 'LineStyle', '-', ...
    'Color', stateInferenceColor, 'LineWidth', 1);
plot(1:nTrials, srLearnerProbabilities_v , 'LineStyle', '--', ...
    'Color', srLearnerColor, 'LineWidth', 1);

for iPhase = 1:nPhases
    plot(phasePositionsX{iPhase}, phasePositionsY{iPhase}, ...
        'Color', phaseColors{iPhase}, 'LineWidth', 3);
end;

axis(axis_v);
% xlabel('Trial', 'fontName', fontName, 'fontSize', labelFontSize); % being
% done in Adobe Illustrator
% ylabel('P(Go)', 'fontName', fontName, 'fontSize', labelFontSize); % being
% done in Adobe Illustrator

set(gca, 'fontName', fontName, 'fontSize', fontSize, 'XTick', [], ...
    'Ytick', []);

%% Save
outputDir = paths.results.taskdir;
if ~exist(outputDir, 'dir')
    mkdir(outputDir);
end;

export_fig([outputDir filesep figName], figRes, '-tiff', '-transparent');
print([outputDir filesep figName], figRes, '-deps', '-tiff');