function [] = shellmdl_reformat_git_data(options, paths)
% [] = shellmdl_reformat_git_data(options, paths)
%
% shellmdl_reformat_git_data is the function that should be used to 
% preprocess the data downloaded from the git (paths.datadir).
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  [none]
%
% Author: Vasco A. Concei��o
%
% Last modified: December 2023

%% Main Code:
if options.verbose.datapreprocessing
    disp(' ');
    disp('--------------------------------------------------------------');
    disp('Running shellmdl_reformat_git_data...');
end;

if ~exist(paths.data.preprocdir, 'dir')
    mkdir(paths.data.preprocdir);
end;
copyfile(paths.data.manpreproc.maingroupdatafile, 	paths.data.preproc.maingroupdatafile);
copyfile(paths.data.manpreproc.ocirgroupdatafile, 	paths.data.preproc.ocirgroupdatafile);

if ~exist(paths.data.preproc.behavdir, 'dir')
    mkdir(paths.data.preproc.behavdir);
end;
copyfile(paths.data.manpreproc.behavdir, paths.data.preproc.behavdir);