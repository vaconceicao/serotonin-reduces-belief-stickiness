function [] = shellmdl_loop_preprocess_subj_behav_data(options, paths)
% function [] = shellmdl_loop_preprocess_subj_behav_data(options, paths)
% 
% shellmdl_loop_preprocess_subj_behav_data is a function called by 
% shellmdl_master, which loops across the .txts created during task 
% solving, evoking the auxiliary function that will process the data from 
% each subject of interest; that is, from each subject specified in 
% options.dataset.subjects.
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  shellmdl_paths
%  shellmdl_preprocess_subj_behav_data
%
% Notes:
%  The .txts created during task solving contain all information of 
%  interest (stimuli shown on each trial, the respective actions and 
%  reinforcements, etc.).
%
% Author: Vasco A. Concei��o
%
% Last modified: September 2023

%% Main Code
if options.verbose.datapreprocessing
    disp(' ');
    disp('--------------------------------------------------------------');
    disp('Running shellmdl_loop_process_subj_behav_data...');
end;

for iSubject = 1:options.dataset.nEffSubjects
    subject = options.dataset.subjects(iSubject);
    
    paths = shellmdl_paths(paths, 1, subject);
    shellmdl_preprocess_subj_behav_data(options, paths, subject);
end;
end