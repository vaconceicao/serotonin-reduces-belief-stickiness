function [] = shellmdl_loop_preprocess_trace_behav_data(options, paths)
% [] = shellmdl_loop_preprocess_trace_behav_data(options, paths)
%
% shellmdl_loop_preprocess_trace_behav_data is a function called by 
% shellmdl_master, which inspects the files with the trace-related 
% information for all subjects, storing each subject-specific 
% trace-related information separately.
%
% Called in: 
%   shellmdl_master
%
% List of key auxiliary functions:
%   shellmdl_paths
%   shellmdl_get_comp_trace_metrics
%
% Author: Vasco A. Concei��o
%
% Last modified: September 2023

%%
if options.verbose.datapreprocessing
    disp(' ');
    disp('--------------------------------------------------------------');
    disp('Running shellmdl_loop_preprocess_trace_behav_data...');
end;

traces_comp = struct();

for iSubject = 1:options.dataset.nEffSubjects
    subject     = options.dataset.subjects(iSubject);
    paths       = shellmdl_paths(paths, 1, subject);
    inputFile   = paths.data.behavior.tempsubject.tempsessiontracefile;
    
    outputDir   = paths.results.subjects.tempsubject.tracedir;
    outputFile  = paths.results.subjects.tempsubject.tracefile;
    
    aux_trace               = csvread(inputFile);
    aux_trace(aux_trace(:, 3) == 2, 3) = -1; % -1s were coded as 2s in the task trace
    
    traceInfo.stim          = aux_trace(:, 1);
    traceInfo.states        = aux_trace(:, 2);
    traceInfo.reinfsIfGo    = aux_trace(:, 3);
    
    traces_comp = shellmdl_get_comp_trace_metrics(options, subject, aux_trace, traces_comp); % traces_comp is the structure that will store complementary trace information for each subject
    
    aux2 = getfield(traces_comp, ['trace_subj_' num2str(subject) '_ts']);   % trials in which each shell appears
    aux3 = getfield(traces_comp, ['trace_subj_' num2str(subject) '_rev']);  % index of the shell-specific occurrences where the 2nd, 3rd, and 4th phases start
    traceInfo.phases = traceInfo.states;
    for iStim = 1:options.dataset.nStim
        aux4 = aux2{iStim};
        aux5 = aux3(iStim, :);
        traceInfo.phases(aux4(aux5(2):options.dataset.nStimTrials(iStim))) = ... % states 1, 2, 1, 2 become phases 1, 2, 3, 4
            traceInfo.phases(aux4(aux5(2):options.dataset.nStimTrials(iStim))) + options.dataset.nHS;
    end;
    
    saveBool = options.save.datapreprocessing;
    if saveBool
        if ~exist(outputDir, 'dir')
            mkdir(outputDir);
        end;
        
        overwriteBool = options.overwrite.datapreprocessing;
        if overwriteBool || ~exist(outputFile, 'file')
            if options.verbose.datapreprocessing
                disp([' Results from shellmdl_loop_preprocess_trace_behav_data for subject ' num2str(subject) ' were overwritten.']);
            end;
            save(outputFile, 'traceInfo');
            
        else %%% seems to be working well, but non-overwritten files won't be used in the ensuing analyses steps unless the code is further changed
            if options.verbose.datapreprocessing
                disp([' Results from shellmdl_loop_preprocess_trace_behav_data for subject ' num2str(subject) ' were saved, but not overwritten.']);
            end;
            b = exist(outputFile, 'file'); fileCounter = 1;
            while b
                b = exist([outputFile(1:end-4) '_' num2str(fileCounter) '.mat'], 'file');
                fileCounter = fileCounter + 1;
            end;
            save([outputFile(1:end-4) '_' num2str(fileCounter - 1) '.mat'], 'traceInfo');
        end;
        
    else
        if options.verbose.datapreprocessing
            disp([' Results from shellmdl_loop_preprocess_trace_behav_data for subject ' num2str(subject) ' were not saved.']);
        end;
    end; 
end