function [traces_comp] = shellmdl_get_comp_trace_metrics(options, subject, trace, traces_comp)
% [traces_comp] = shellmdl_get_comp_trace_metrics(options, subject, trace, traces_comp)
%
% shellmdl_get_comp_trace_metrics is a function called by
% shellmdl_loop_preprocess_trace_behav_data, which gets complementary trace
% metrics for a given subject, according to the respective task trace, and 
% then stores those metrics inside the traces_comp struct.
%
% Called in:
%   shellmdl_loop_preprocess_trace_behav_data
%
% List of key auxiliary functions:
%   [none]
%
% Author: Vasco A. Concei��o
%
% Last modified: December 2023

%% Settings
nStim   = options.dataset.nStim;
nPhases = options.dataset.nPhases;

%% Main Code
aux_ts  = cell(options.dataset.nStim, 1);
aux_ss  = cell(nStim, 1);
aux_rs  = cell(nStim, 1);

aux_rev = -Inf * ones(nStim, nPhases - 1);

for iStim = 1:nStim
    aux_ts{iStim, 1}    = find(trace(:, 1) == iStim); % trials in which the stimulus is shown
    aux_ss{iStim, 1}    = trace(aux_ts{iStim, 1}, 2); % stimulus's states in the respective trials
    aux_rs{iStim, 1}    = trace(aux_ts{iStim, 1}, 3); % reinforcements (if Go) in the respective trials
    
    aux_rev(iStim, :)   = 1 + find(aux_ss{iStim, 1}(2:end) - aux_ss{iStim, 1}(1:(end-1))); % stores the 3 (3 = nPhases - 1) stimulus occurrences in which there is a reversal
end;

traces_comp = setfield(traces_comp, ['trace_subj_' num2str(subject) '_ts'], aux_ts);
traces_comp = setfield(traces_comp, ['trace_subj_' num2str(subject) '_ss'], aux_ss);
traces_comp = setfield(traces_comp, ['trace_subj_' num2str(subject) '_rs'], aux_rs);
traces_comp = setfield(traces_comp, ['trace_subj_' num2str(subject) '_rev'], aux_rev);