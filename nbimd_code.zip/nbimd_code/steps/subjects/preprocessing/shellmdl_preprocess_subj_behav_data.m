function [] = shellmdl_preprocess_subj_behav_data(options, paths, subject)
% [] = shellmdl_preprocess_subj_behav_data(options, paths, subject)
% 
% shellmdl_preprocess_subj_behav_data is a function called by 
% shellmdl_loop_preprocess_subj_behav_data, which reads the 
% subject-specific .txt of interest and saves the respective 
% subject-specific output file (containing the preprocessed information).
%
% Called in:
%  shellmdl_loop_preprocess_subj_behav_data
%
% List of key auxiliary functions:
%  [none]
%
% Notes: 
%  In the original files, the feedback was coded as: 
%  0 = neutral; 1 = correct; 2 = wrong.
%
% Authors: Frederike H. Petzschner; Vasco A. Concei��o
%
% Last modified: September 2023

%%
inputFile   = paths.data.behavior.tempsubject.tempsessionfile;
outputDir   = paths.results.subjects.tempsubject.behavior.tempsession.preprocdir;
outputFile  = paths.results.subjects.tempsubject.behavior.tempsession.preprocfile;

%%
f = fopen(inputFile, 'r');
nt = 0;

while ~feof(f)
	line = fgetl(f);
    
	% Parse line into tokens
	parsed = [];
	[parsed{1} remain] = strtok(line,' ');
	while ~isempty(remain)
		[tok remain] = strtok(remain,' ');
		parsed{end+1} = tok;
    end
    nt = nt + 1;
    % disp(['Trial ', num2str(nt), '...']);
    D.preproc.rt(nt)            = str2num(parsed{5});
    D.preproc.stim(nt)          = str2num(parsed{2});
    D.preproc.feedbackIfGo(nt)  = str2num(parsed{3});
    D.preproc.gonogo(nt)        = str2num(parsed{4});
end

D.preproc.feedbackIfGo(D.preproc.feedbackIfGo == 2) = -1;

D.preproc.feedback = D.preproc.feedbackIfGo;
D.preproc.feedback(D.preproc.gonogo == 0) = 0; % NoGo never yields any feedback

fclose(f);

%%
saveBool = options.save.datapreprocessing;
if saveBool
    if ~exist(outputDir, 'dir')
        mkdir(outputDir);
    end;
    
    overwriteBool = options.overwrite.datapreprocessing;
    if overwriteBool || ~exist(outputFile, 'file')
        if options.verbose.datapreprocessing
            disp([' Results from shellmdl_preprocess_subj_behav_data for subject ' num2str(subject) ' were overwritten.']);
        end;
        save(outputFile, 'D');
        
    else % seems to be working well, but non-overwritten files won't be used in the ensuing analyses steps unless the code is further changed
        if options.verbose.datapreprocessing
            disp([' Results from shellmdl_preprocess_subj_behav_data for subject ' num2str(subject) ' were saved, but not overwritten.']);
        end;
        b = exist(outputFile, 'file'); fileCounter = 1;
        while b
            b = exist([outputFile(1:end-4) '_' num2str(fileCounter) '.mat'], 'file');
            fileCounter = fileCounter + 1;
        end;
        save([outputFile(1:end-4) '_' num2str(fileCounter - 1) '.mat'], 'D');
    end;
    
else
    if options.verbose.datapreprocessing
        disp([' Results from shellmdl_preprocess_subj_behav_data for subject ' num2str(subject) ' were not saved.']);
    end;
end;