function [] = shellmdl_plot_predicted_subj_behavior(options, paths)
% [] = shellmdl_plot_predicted_subj_behavior(options, paths)
%
% shellmdl_plot_predicted_subj_behavior is a function that should be used 
% to plot the trial-by-trial evolution of the variables from the (selected) 
% RL models. It requires that shellmdl_loop_predict_subj_behavior is 
% previously ran for the models being plotted here. It creates Figure 5 of
% the article.
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  [none]
%
% Author: Vasco A. Concei��o
%
% Last modified: April 2024

%% Settings
modelNumbers    = options.selectedmodelsanalysis.iModelNumbers; % S-R-8 and S-S-R-8
nModels         = numel(modelNumbers);

nHS             = options.rl.nHS;

soi             = options.dataset.subjects;
nEffSubj        = numel(soi);

nStims          = options.dataset.nStim;
nActions        = options.dataset.nActions;
% nReinfs         = options.dataset.nReinfs;
nTrials         = options.dataset.nTrials;

stimNames       = options.dataset.stimNames;
stimPosition    = options.figs.shellSubPlots;

numberFigs      = options.figs.fig5.nPanels;
dispTol         = options.figs.fig5.dispTol;
statesYA = {...
    options.figs.fig5A.seasonYPositions(1), options.figs.fig5A.seasonYPositions(2);
    options.figs.fig5A.seasonYPositions(2), options.figs.fig5A.seasonYPositions(1);
    options.figs.fig5A.seasonYPositions(1), options.figs.fig5A.seasonYPositions(3);
    options.figs.fig5A.seasonYPositions(3), options.figs.fig5A.seasonYPositions(1);
    options.figs.fig5A.seasonYPositions(3), options.figs.fig5A.seasonYPositions(2);
    options.figs.fig5A.seasonYPositions(2), options.figs.fig5A.seasonYPositions(3)};

statesYB = {...
    options.figs.fig5B.seasonYPositions(1), options.figs.fig5B.seasonYPositions(2);
    options.figs.fig5B.seasonYPositions(2), options.figs.fig5B.seasonYPositions(1);
    options.figs.fig5B.seasonYPositions(1), options.figs.fig5B.seasonYPositions(3);
    options.figs.fig5B.seasonYPositions(3), options.figs.fig5B.seasonYPositions(1);
    options.figs.fig5B.seasonYPositions(3), options.figs.fig5B.seasonYPositions(2);
    options.figs.fig5B.seasonYPositions(2), options.figs.fig5B.seasonYPositions(3)};

statesColor = {...
    options.figs.seasonColors(1, :), options.figs.seasonColors(2, :);
    options.figs.seasonColors(2, :), options.figs.seasonColors(1, :);
    options.figs.seasonColors(1, :), options.figs.seasonColors(3, :);
    options.figs.seasonColors(3, :), options.figs.seasonColors(1, :);
    options.figs.seasonColors(3, :), options.figs.seasonColors(2, :);
    options.figs.seasonColors(2, :), options.figs.seasonColors(3, :)};

modelVariablesOutput.data       = -Inf * ones(nEffSubj * nTrials, 4);   % p(a_{t, model2} = a_{t, subject}) | p(a_{t, model1} = a_{t, subject}) | stage | subject
modelVariablesOutput.auxData    = cell(nEffSubj, 2);                    % trials in stages 1 and 2 | nTrials in stages 3 and 4
modelVariablesOutput.gof_ratio  = -Inf * ones(nEffSubj, 3);             % full | stages 1 and 2 | stages 3 and 4

%% Main Code
if options.verbose.selectedmodelsanalysis
    disp(' '); 
    disp('Running shellmdl_plot_predicted_subj_behavior for the selected model and its nested S-R equivalent...');
end;

load([paths.results.group.behavior2modeldir filesep 'states_m']);
load([paths.results.group.behavior2modeldir filesep 'phases_m']);

for s = 1:options.figs.fig5.nSubjects
    subj = options.figs.fig5.subjects(s);
    
    if subj == options.figs.fig5.subjectInUse % only being run for one subject (the subject whose data was placed in the article)
        for iModel = 1:nModels
            modelNumber = modelNumbers(iModel);
            
            paths = shellmdl_paths(paths, 1, subj, modelNumber, options);
            load(paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelfitdiagnosisfile);
            load(paths.results.subjects.tempsubject.models.tempsession.tempmodel.predictedModelVariablesfile);
            outputDir = paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelinspection.figuresdir; % could be outside this cycle
            
            if iModel == 1
                modelInfo1  = modelInfo;
                stim_seq1   = modelInfo1.dataset.stimSeq';
                act_seq1    = modelInfo1.dataset.actSeq';
                reinf_seq1  = modelInfo1.dataset.reinfSeq';
                stimProb1   = stimProb;
                
                prob_same1 = -Inf * ones(nTrials, 1);
                for iTrial = 1:nTrials
                    if act_seq1(iTrial) == 1
                        prob_same1(iTrial) = prob_v(iTrial);
                    elseif act_seq1(iTrial) == 2
                        prob_same1(iTrial) = 1 - prob_v(iTrial);
                    end;
                end;
                modelVariablesOutput.data(((s-1)*nTrials+1):(s*nTrials), 1) = prob_same1;
                
            else
                modelInfo2  = modelInfo;
                act_seq2    = modelInfo2.dataset.actSeq'; % same as act_seq1
                stimProb2   = stimProb;
                
                prob_same2 = -Inf * ones(nTrials, 1);
                for iTrial = 1:nTrials
                    if act_seq2(iTrial) == 1
                        prob_same2(iTrial) = prob_v(iTrial);
                    elseif act_seq2(iTrial) == 2
                        prob_same2(iTrial) = 1 - prob_v(iTrial);
                    else
                        error('Missing data!');
                    end;
                end;
                modelVariablesOutput.data(((s-1)*nTrials+1):(s*nTrials), 2) = prob_same2;
            end;
        end;
        modelVariablesOutput.data(((s-1)*nTrials+1):(s*nTrials), 3) = phases_m(subj, :);
        modelVariablesOutput.data(((s-1)*nTrials+1):(s*nTrials), 4) = subj;
        
        modelVariablesOutput.auxData{s, 1} = [find(phases_m(subj,:)==1), find(phases_m(subj,:)==2)];
        modelVariablesOutput.auxData{s, 2} = [find(phases_m(subj,:)==3), find(phases_m(subj,:)==4)];
        
        modelVariablesOutput.gof_ratio(s, 1) = prod(prob_same2) / prod(prob_same1);
        
        phases12_trialIndices = ((s-1)*nTrials) + modelVariablesOutput.auxData{s, 1};
        phases34_trialIndices = ((s-1)*nTrials) + modelVariablesOutput.auxData{s, 2};
        modelVariablesOutput.gof_ratio(s, 2) = prod(modelVariablesOutput.data(phases12_trialIndices, 2)) / prod(modelVariablesOutput.data(phases12_trialIndices, 1));
        modelVariablesOutput.gof_ratio(s, 3) = prod(modelVariablesOutput.data(phases34_trialIndices, 2)) / prod(modelVariablesOutput.data(phases34_trialIndices, 1));
        
        states_seq = states_m(subj,:);
        
        for fig = 1:numberFigs
            f = figure();
            if fig == 1
                figureName = [options.figs.fig5A.name ' for subject ' num2str(subj)];
            elseif fig == 2
                figureName = [options.figs.fig5B.name ' for subject ' num2str(subj)];
            end;
            set(f, 'Name', figureName, 'Units', 'Centimeters', 'Position', options.figs.fig5.dimensions, ...
                'PaperUnits', 'Centimeters', 'PaperPosition', options.figs.fig5.dimensions);
            
            for stim = 1:nStims
                trials_v = find(stim_seq1 == stim);
                subplot(nStims/3, nStims/2, stimPosition(stim));
                
                % plot subject's actions
                y_v = nActions - act_seq1(trials_v); x_v = 1:length(y_v);
                plot(x_v, y_v, 'o', 'MarkerFaceColor', 'k', 'MarkerEdgeColor', 'k', 'MarkerSize', options.figs.fig5.markerSize);
                
                % color-code reinforcements
                hold on;
                goTrials            = find(act_seq1(trials_v) == 1);
                posReinfTrials      = find(reinf_seq1(trials_v) == 1);
                neutralReinfTrials  = intersect(goTrials,find(reinf_seq1(trials_v) == 0));
                negReinfTrials      = find(reinf_seq1(trials_v) == -1);
                
                plot(posReinfTrials,        ones(1, length(posReinfTrials)),    	'o', 'MarkerFaceColor', options.figs.seasonColors(1, :), 'MarkerEdgeColor', 'k', 'MarkerSize', options.figs.fig5.markerSize);
                plot(neutralReinfTrials,    ones(1, length(neutralReinfTrials)),    'o', 'MarkerFaceColor', options.figs.seasonColors(2, :), 'MarkerEdgeColor', 'k', 'MarkerSize', options.figs.fig5.markerSize);
                plot(negReinfTrials,        ones(1, length(negReinfTrials)),        'o', 'MarkerFaceColor', options.figs.seasonColors(3, :), 'MarkerEdgeColor', 'k', 'MarkerSize', options.figs.fig5.markerSize);
                
                % get variables to plot states
                stage       = 0;
                prevState   = 0;
                beginStage  = zeros(1, options.dataset.nPhases);
                phases_c    = cell(1, options.dataset.nPhases);
                for i = 1:length(y_v)
                    state_t = states_seq(trials_v(i));
                    if state_t ~= prevState
                        stage = stage + 1;
                        beginStage(stage) = i;
                        if stage > 1
                            phases_c{stage - 1} = (beginStage(stage-1) : beginStage(stage)) - 0.5; % - 0.5 is for graphical purposes
                        end;
                    end;
                    prevState = state_t;
                end;
                phases_c{options.dataset.nPhases} = (beginStage(options.dataset.nPhases):(length(y_v) + 1)) - 0.5;
                
                if fig == 1
                    % plot states
                    plot(phases_c{1}, repmat(statesYA{stim,1}, 1, length(phases_c{1})), 'LineStyle', '-', 'color', statesColor{stim,1}, 'LineWidth', options.figs.fig5.seasonLineWidth);
                    plot(phases_c{3}, repmat(statesYA{stim,1}, 1, length(phases_c{3})), 'LineStyle', '-', 'color', statesColor{stim,1}, 'LineWidth', options.figs.fig5.seasonLineWidth);
                    
                    plot(phases_c{2}, repmat(statesYA{stim,2}, 1, length(phases_c{2})), 'LineStyle', '-', 'color', statesColor{stim,2}, 'LineWidth', options.figs.fig5.seasonLineWidth);
                    plot(phases_c{4}, repmat(statesYA{stim,2}, 1, length(phases_c{4})), 'LineStyle', '-', 'color', statesColor{stim,2}, 'LineWidth', options.figs.fig5.seasonLineWidth);
                    
                    if stimPosition(stim) == 1 || stimPosition(stim) == 4
                        ylabel(options.figs.fig5A.yLabel, 'fontName', options.figs.fontName, 'fontSize', options.figs.labelFontSize);
                    end;
                    
                elseif fig == 2
                    % plot states
                    plot(phases_c{1}, repmat(statesYB{stim,1}, 1, length(phases_c{1})), 'LineStyle', '-', 'color', statesColor{stim,1}, 'LineWidth', options.figs.fig5.seasonLineWidth);
                    plot(phases_c{3}, repmat(statesYB{stim,1}, 1, length(phases_c{3})), 'LineStyle', '-', 'color', statesColor{stim,1}, 'LineWidth', options.figs.fig5.seasonLineWidth);
                    
                    plot(phases_c{2}, repmat(statesYB{stim,2}, 1, length(phases_c{2})), 'LineStyle', '-', 'color', statesColor{stim,2}, 'LineWidth', options.figs.fig5.seasonLineWidth);
                    plot(phases_c{4}, repmat(statesYB{stim,2}, 1, length(phases_c{4})), 'LineStyle', '-', 'color', statesColor{stim,2}, 'LineWidth', options.figs.fig5.seasonLineWidth);
                    
                    switch stimPosition(stim) % this manual implementation only works for the selected subject
                        case 1
                            lineColorsAux(1, :) = options.figs.seasonColors(1, :);
                            lineColorsAux(2, :) = options.figs.seasonColors(3, :);
                            lineColorsAux(3, :) = options.figs.seasonColors(2, :);
                        case 2
                            lineColorsAux(1, :) = options.figs.seasonColors(1, :);
                            lineColorsAux(2, :) = options.figs.fig5.undiscoveredSeasonColor;
                            lineColorsAux(3, :) = options.figs.fig5.undiscoveredSeasonColor;
                        case 3
                            lineColorsAux(1, :) = options.figs.seasonColors(2, :);
                            lineColorsAux(2, :) = options.figs.seasonColors(3, :);
                            lineColorsAux(3, :) = options.figs.fig5.undiscoveredSeasonColor;
                        case 4
                            lineColorsAux(1, :) = options.figs.seasonColors(3, :);
                            lineColorsAux(2, :) = options.figs.seasonColors(1, :);
                            lineColorsAux(3, :) = options.figs.fig5.undiscoveredSeasonColor;
                        case 5
                            lineColorsAux(1, :) = options.figs.seasonColors(2, :);
                            lineColorsAux(2, :) = options.figs.seasonColors(1, :);
                            lineColorsAux(3, :) = options.figs.fig5.undiscoveredSeasonColor;
                        case 6
                            lineColorsAux(1, :) = options.figs.seasonColors(3, :);
                            lineColorsAux(2, :) = options.figs.seasonColors(2, :);
                            lineColorsAux(3, :) = options.figs.fig5.undiscoveredSeasonColor;
                    end;
                    
                    for hs = nHS:-1:1
                        if mod(hs, 2)
                            lineStr = '-';
                        else
                            lineStr = '-';
                        end;
                            
                        plot(x_v, stimBeliefs(x_v, hs, stim), lineStr, 'Color', lineColorsAux(hs, :));
                        for taux = 1:length(x_v)
                            if stimCurrHS(taux,stim) == hs
                                plot(taux, stimBeliefs(taux,hs,stim), 's', 'MarkerSize', options.figs.fig5.markerSize - 1, ...
                                    'MarkerFaceColor', lineColorsAux(hs, :), 'MarkerEdgeColor', lineColorsAux(hs, :));
                                % plot currently inferred hidden state above:
                                plot([taux - 0.5, taux + 0.5], [1.11, 1.11], 'color', lineColorsAux(hs, :), 'LineWidth', options.figs.fig5.seasonLineWidth);
                            end;
                        end;
                    end;
                    
                    if stimPosition(stim) == 1 || stimPosition(stim) == 4
                        ylabel(options.figs.fig5B.yLabel, 'fontName', options.figs.fontName, 'fontSize', options.figs.labelFontSize);
                    end;
                end;
                
                axis([0 max(x_v)+1 0 - dispTol(1) 1 + dispTol(fig)]);
                set(gca, 'XTick', 0:10:(max(x_v)+1), 'fontSize', options.figs.fontSize, 'fontName', options.figs.fontName);

                xlabel('Trial', 'fontName', options.figs.fontName, 'fontSize', options.figs.labelFontSize);

                title(stimNames{stim}, 'fontName', options.figs.fontName, 'fontSize', options.figs.titleFontSize - 1);

                if fig == 1
                    if nModels == 2
                        % plot probabilities predicted by the models:
                        plot(stimProb2(x_v, stim), options.figs.fig5A.lineTypes{2}, 'color', options.figs.fig5A.lineColors(2, :), 'LineWidth', options.figs.fig5A.lineWidth);
                        plot(stimProb1(x_v, stim), options.figs.fig5A.lineTypes{1}, 'color', options.figs.fig5A.lineColors(1, :), 'LineWidth', options.figs.fig5A.lineWidth);
                    end;
                end;
            end;
            
            if options.save.selectedmodelsanalysis
                if options.verbose.selectedmodelsanalysis
                    if fig == 1
                        disp('Panel A of Figure 5 was overwritten.');
                    else
                        disp('Panel B of Figure 5 was overwritten.');
                    end;
                end;
                if ~exist(outputDir, 'dir')
                    mkdir(outputDir);
                end;
                if fig == 1
                    export_fig([outputDir filesep options.figs.fig5A.name], '-tiff', ['-r' num2str(options.figs.fig5.res)], '-transparent'); % , '-nocrop'
                    print([outputDir filesep options.figs.fig5A.name], '-r1000', '-depsc', '-tiff');
                else
                    export_fig([outputDir filesep options.figs.fig5B.name], '-tiff', ['-r' num2str(options.figs.fig5.res)], '-transparent'); % , '-nocrop'
                    print([outputDir filesep options.figs.fig5B.name], '-r1000', '-depsc', '-tiff');
                end;
                close(f);
            end;
        end;
    end;
end;
end