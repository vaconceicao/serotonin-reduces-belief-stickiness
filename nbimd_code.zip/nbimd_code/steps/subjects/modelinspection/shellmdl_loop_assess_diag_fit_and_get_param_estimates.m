function [] = shellmdl_loop_assess_diag_fit_and_get_param_estimates(options, paths, iModel)
% [] = shellmdl_loop_assess_diag_fit_and_get_param_estimates(options, paths, iModel)
%
% shellmdl_loop_assess_diag_fit_and_get_param_estimates is a function that
% assesses the quality of the model fit (diagnosis, not TI) for the model 
% defined in options.rl.modelNames{iModel}. 
% It gets the R_hat for each each parameter and for the log likelihood for 
% all subjects, and it stores both model-subject-specific and 
% model-specific output .mat and .xls files.
%
% Called in: 
%  shellmdl_master
%
% List of key auxiliary functions:
%  [none]
%
% Author: Vasco A. Concei��o
%
% Last modified: September 2023

%% Settings:
inputFileName       = options.mcmc.fileNames{2}; % uses the results from the model inversion with all chains at a temperature of 1 (diagResults)

% modelFamilies       = options.rl.modelFamilies;
modelNames          = options.rl.modelNames;

%% Main Code:
if options.verbose.selectedmodelsanalysis % can be changed back into: .modelinspection
    disp(' ');
    disp(['Running shellmdl_loop_assess_diag_fit_and_get_param_estimates for model ' modelNames{iModel} '...']);
end;
    
R_hat_all_subjects  = []; % will store all information for the specified model
params_all_subjects = [];

for subject = options.dataset.subjects
    
    paths               = shellmdl_paths(paths, 1, subject, iModel, options);
    inputFilesFolder    = paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelfitdir;
    outputFilesFolder   = paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelinspectiondir;
    
    if ~exist(outputFilesFolder, 'dir')
        mkdir(outputFilesFolder);
    end;
    
    outputFilesName1    = [outputFilesFolder filesep 'R_hat_assessment.xls'];
    outputFilesName2    = [outputFilesFolder filesep 'param_estimates.xls'];
    
    load([inputFilesFolder filesep inputFileName num2str(subject)]);
    if options.overwrite.selectedmodelsanalysis % can be changed back into: .modelinspection
        try
            delete(outputFilesName1);
            delete(outputFilesName2);
        catch
        end;
    end;
    if options.save.selectedmodelsanalysis % can be changed into: .modelinspection
        xlswrite(outputFilesName1, [results.pR, results.llhR]);
        xlswrite(outputFilesName2, results.samples.pE');
    end;
    
    if options.verbose.selectedmodelsanalysis % can be changed into: .modelinspection
        if max([results.pR results.llhR]) >= 1.1
            disp([' R_hat values > 1.1 for subject ' num2str(subject) '!']);
        else
            disp([' All good regarding R_hat for subject ' num2str(subject) '.']);
        end;
    end;
    
    R_hat_all_subjects  = [R_hat_all_subjects; [subject, results.pR, results.llhR]];
    params_all_subjects = [params_all_subjects; [subject, results.samples.pE']];
end;

paths               = shellmdl_paths(paths, 1, -1, iModel, options); % -1 is the subject error code
outputFileFolder    = paths.results.group.modelinspection.tempsession.tempmodeldir;

if ~exist(outputFileFolder, 'dir')
    mkdir(outputFileFolder);
end;

outputFileName1     = [outputFileFolder filesep 'R_hat_assessment.xls'];
outputFileName2     = [outputFileFolder filesep 'param_estimates.xls'];
outputFileName3     = [outputFileFolder filesep 'param_estimates.csv'];
outputFileName4     = [outputFileFolder filesep 'params_m.mat'];

if options.overwrite.selectedmodelsanalysis % can be changed into: .modelinspection
    try
        delete(outputFileName1);
        delete(outputFileName2);
        delete(outputFileName3);
        delete(outputFileName4);
    catch
    end;
end;
if options.save.selectedmodelsanalysis % can be changed into: .modelinspection
    xlswrite(outputFileName1, R_hat_all_subjects);
    xlswrite(outputFileName2, params_all_subjects);
    csvwrite(outputFileName3, params_all_subjects);
    
    params_m = params_all_subjects(:, 2:end); % no need to save subject info for this too
    save(outputFileName4, 'params_m');
end;
    
R_hat_aux = R_hat_all_subjects(:, 2:end); % exclude subject column

if options.verbose.selectedmodelsanalysis % can be changed into: .modelinspection
    if max(R_hat_aux(:)) >= 1.1
        disp(['There are (several) R_hat values > 1.1 for model ' modelNames{iModel} '!']);
    else
        disp(['All good regarding R_hat for model ' modelNames{iModel} '.']);
    end;
end;
end