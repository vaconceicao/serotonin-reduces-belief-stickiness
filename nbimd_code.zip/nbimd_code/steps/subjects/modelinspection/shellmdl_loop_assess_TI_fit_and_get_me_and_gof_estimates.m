function [ME_TI_m, McFaddenPseudoR2_m] = shellmdl_loop_assess_TI_fit_and_get_me_and_gof_estimates(options, paths, iModel)
% [ME_TI_m, McFaddenPseudoR2_m] = shellmdl_loop_assess_TI_fit_and_get_me_and_gof_estimates(options, paths, iModel)
%
% shellmdl_loop_assess_TI_fit_and_get_me_and_gof_estimates is a function 
% that assesses the quality of the model fit (TI, not diagnosis) for the 
% model defined in options.rl.modelNames{iModel}. 
% It gets the the model evidence estimated using TI [ME_TI_m; as well as 
% suboptimal approximations, if less chains and/or iterations had been used
% during MCMC, or if other model evidence approximations (AIC, BIC, 
% maxLLH) had been chosen] for all subjects.
% In addition, it calculates two goodness-of-fit (gof) approximations: the
% average log-likelihood per trial and the McFadden's pseudo-R2.
% It then stores both model-subject-specific and model-specific output .mat
% and .xls files.
%
% Called in: 
%  shellmdl_master
%
% List of key auxiliary functions:
%  [none]
%
% Author: Vasco A. Concei��o
%
% Last modified: September 2023

%% Settings:
inputFileName       = options.mcmc.fileNames{1}; % uses the results from the model inversion with all chains at different temperatures (tiResults)

% modelFamilies       = options.rl.modelFamilies;
modelNames          = options.rl.modelNames;

%% Main Code:
if options.verbose.modelinspection
    disp(' ');
    disp(['Running shellmdl_loop_assess_TI_fit_and_get_model_evidence_estimates for model ' modelNames{iModel} '...']);
end;
    
me_estimates_all_subjects       = []; % will store all information for the specified model (ME according to TI, AIC, BIC, and maxLLH)
max_me_variation_all_subjects   = []; % if 10 to 50 chains had been used instead and/or if 1250, 1667, 2500, or 5000 iterations had been used instead

gof_estimates_all_subjects      = [];

paths = shellmdl_paths(paths, 1);
load(paths.results.group.behavior.tempsession.all.procfile);

meanPctGo   = mean(all_behav_data.didgo_m, 2);
sumGo       = sum(all_behav_data.didgo_m, 2);
sumNoGo     = size(all_behav_data.didgo_m, 2) - sumGo;

iSubject    = 0;
for subject = options.dataset.subjects
    
    iSubject = iSubject + 1;
    
    paths               = shellmdl_paths(paths, 1, subject, iModel, options);
    inputFilesFolder    = paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelfitdir;
    outputFilesFolder   = paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelinspectiondir;
    
    if ~exist(outputFilesFolder, 'dir')
        mkdir(outputFilesFolder);
    end;
    
    outputFilesName1    = [outputFilesFolder filesep 'me_estimates.xls'];
    outputFilesName2    = [outputFilesFolder filesep 'max_me_variation.xls'];
    
    load([inputFilesFolder filesep inputFileName num2str(subject)]);
    if options.overwrite.modelinspection
        try
            delete(outputFilesName1);
            delete(outputFilesName2);
        catch
        end;
    end;
    
    me_variation        = 100 * abs((results.meList(end, end) - results.meList(10:end, 2:end)) ./ results.meList(10:end, 2:end));
    max_me_variation    = max(me_variation(:));
    
    if options.save.modelinspection
        xlswrite(outputFilesName1, [results.samples.ME, results.samples.AIC, results.samples.BIC, max(results.samples.llh)]);
        xlswrite(outputFilesName2, max_me_variation);
    end;
    if options.verbose.modelinspection
        disp([' The maximum varation in model evidence for model ' modelNames{iModel} ' for subject ' num2str(subject) ' was ' num2str(round(max_me_variation, 2)) '%.']);
    end;
        
    me_estimates_all_subjects       = [me_estimates_all_subjects; [subject, results.samples.ME, results.samples.AIC, results.samples.BIC, max(results.samples.llh)]];
    max_me_variation_all_subjects   = [max_me_variation_all_subjects; [subject, max_me_variation]];
    
    avgLLHTrial         = exp(max(results.samples.llh) / options.dataset.nTrials);
    McFaddenPseudoR2    = 1 - max(results.samples.llh) / (log(meanPctGo(iSubject)^sumGo(iSubject) * (1-meanPctGo(iSubject))^sumNoGo(iSubject)));
        
    gof_estimates_all_subjects      = [gof_estimates_all_subjects; [subject, avgLLHTrial, McFaddenPseudoR2]];
    
    if options.verbose.modelinspection
        disp([' The McFaddenPseudoR2 for model ' modelNames{iModel} ' for subject ' num2str(subject) ' was ' num2str(round(McFaddenPseudoR2, 2)) '.']);
    end;
end;

paths               = shellmdl_paths(paths, 1, -1, iModel, options); % -1 is the subject error code
outputFileFolder    = paths.results.group.modelinspection.tempsession.tempmodeldir;

if ~exist(outputFileFolder, 'dir')
    mkdir(outputFileFolder);
end;

outputFileName1     = [outputFileFolder filesep 'me_estimates.xls'];
outputFileName2     = [outputFileFolder filesep 'max_me_variation.xls'];
outputFileName3     = [outputFileFolder filesep 'ME_TI_m.mat'];
outputFileName4     = [outputFileFolder filesep 'AIC_m.mat'];
outputFileName5     = [outputFileFolder filesep 'BIC_m.mat'];
outputFileName6     = [outputFileFolder filesep 'maxLLH_m.mat'];
outputFileName7     = [outputFileFolder filesep 'avgLLHTrial_m.mat'];
outputFileName8     = [outputFileFolder filesep 'McFaddenPseudoR2_m.mat'];

if options.overwrite.modelinspection
    try
        delete(outputFileName1);
        delete(outputFileName2);
        delete(outputFileName3);
        delete(outputFileName4);
        delete(outputFileName5);
        delete(outputFileName6);
        delete(outputFileName7);
        delete(outputFileName8);
    catch
    end;
end;

if options.save.modelinspection
    xlswrite(outputFileName1, me_estimates_all_subjects);
    xlswrite(outputFileName2, max_me_variation_all_subjects); 
    
    ME_TI_m     = me_estimates_all_subjects(:, 2); % no need to save subject info for this too
    AIC_m       = me_estimates_all_subjects(:, 3); % no need to save subject info for this too
    BIC_m       = me_estimates_all_subjects(:, 4); % no need to save subject info for this too
    maxLLH_m    = me_estimates_all_subjects(:, 5); % no need to save subject info for this too
    
    save(outputFileName3, 'ME_TI_m');
    save(outputFileName4, 'AIC_m');
    save(outputFileName5, 'BIC_m');
    save(outputFileName6, 'maxLLH_m');
    
    avgLLHTrial_m       = gof_estimates_all_subjects(:, 2); % no need to save subject info for this too
    McFaddenPseudoR2_m  = gof_estimates_all_subjects(:, 3); % no need to save subject info for this too
    
    save(outputFileName7, 'avgLLHTrial_m');
    save(outputFileName8, 'McFaddenPseudoR2_m');
end;

if options.verbose.modelinspection
    disp(['The maximum varation in model evidence for model ' modelNames{iModel} ' was ' num2str(round(max(max_me_variation_all_subjects(:, 2)), 2)) '%.']);
    disp(['The mean McFaddenPseudoR2 for model ' modelNames{iModel} ' was ' num2str(round(mean(McFaddenPseudoR2_m), 2)) '.']);
    disp(['The std of McFaddenPseudoR2 for model ' modelNames{iModel} ' was ' num2str(round(std(McFaddenPseudoR2_m), 2)) '.']);
end;
end