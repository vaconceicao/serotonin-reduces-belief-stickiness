function [] = shellmdl_loop_predict_subj_behavior(options, paths, iModel)
% [] = shellmdl_loop_predict_subj_behavior(options, paths, iModel)
%
% shellmdl_loop_predict_subj_behavior is a function that calculates the 
% trial-by-trial variables of interest for a given reinforcement learning
% (RL) model. For it to run, it requires the previous implementation, and 
% compilation, of the eval_llh_modelName_debug.c of interest. That file
% should be inside ...steps/subjects/modelfit/likeli.
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  eval_llh_[modelName]_debug
%
% Author: Vasco A. Concei��o
%
% Last modified: September 2023

%% Settings
modelName   = options.rl.modelNames{iModel};

soi         = options.dataset.subjects;
nEffSubj    = numel(soi);

nStims          = options.dataset.nStim;
nActions        = options.dataset.nActions;
nReinfs         = options.dataset.nReinfs;
nTrials         = options.dataset.nTrials;
maxTrialPerStim = max(options.dataset.nStimTrials);

%% Main Code
stimCurrHS_t    = nan*ones(maxTrialPerStim, nStims, nEffSubj);
stimBeliefs_t   = nan*ones(maxTrialPerStim, options.rl.nHS, nStims, nEffSubj);

if options.verbose.selectedmodelsanalysis
    disp(' '); 
    disp(['Running shellmdl_loop_predict_subj_behavior for model ' modelName '...']);
end;

for s = 1:options.dataset.nEffSubjects
    subj = soi(s);
    
    paths = shellmdl_paths(paths, 1, subj, iModel, options);
    load(paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelfitdiagnosisfile);

    nParams     = modelInfo.rl.nParams;
    params      = results.samples.pE;
   
    stim_seq    = modelInfo.dataset.stimSeq;
    act_seq     = modelInfo.dataset.actSeq;
    reinf_seq   = modelInfo.dataset.reinfSeq;
    
    % Run the function that calculates the trial-by-trial variables:
    if isequal(options.rl.modelFamilies{iModel}, 'SR')
        [prob_v, currHS_v, beliefs_m, normBeliefs_m, Q_m] = ...
            eval(['eval_llh_', modelName, '_debug', '(params, stim_seq, act_seq, reinf_seq, nStims, nActions, nTrials)']);
    elseif isequal(options.rl.modelFamilies{iModel}, 'SSR')
        [prob_v, currHS_v, beliefs_m, normBeliefs_m, Q_m] = ...
            eval(['eval_llh_', modelName, '_debug', '(params, stim_seq, act_seq, reinf_seq, nStims, nActions, nReinfs, nTrials, options.rl.nHS)']);
    else
        error('Not implemented yet.');
    end;
    
    % Get those variables:
    stimProb_aux            = nan * ones(nTrials, nStims);
    stimCurrHS_aux          = nan * ones(nTrials, nStims);
    stimBeliefs_aux         = nan * ones(nTrials, options.rl.nHS, nStims);
    stimNormBeliefs_aux     = nan * ones(nTrials, options.rl.nHS, nStims);
    stimQ_aux               = nan * ones(nTrials, nActions, nStims);
    
    nStimExh                = nan * ones(nStims, 1);
    
    for stim = 1:nStims
        trials_v = find(stim_seq == stim);
        stimProb_aux(trials_v, stim)    = prob_v(trials_v);
        stimCurrHS_aux(trials_v, stim)  = currHS_v(trials_v);
        
        stimBeliefs_aux(trials_v, :, stim)      = beliefs_m(trials_v, :);
        stimNormBeliefs_aux(trials_v,:,stim)    = normBeliefs_m(trials_v, :);   % exactly equal to the unnormalized beliefs
        stimQ_aux(trials_v, :, stim)            = Q_m(trials_v, :);
        nStimExh(stim)                          = length(trials_v);
    end;
    
    % Reshape variables:
    MaxStimExh = max(nStimExh);
    
    stimProb        = nan * ones(MaxStimExh, nStims);
    stimCurrHS      = nan * ones(MaxStimExh, nStims);
    stimBeliefs     = nan * ones(MaxStimExh, options.rl.nHS, nStims);
    stimNormBeliefs = nan * ones(MaxStimExh, options.rl.nHS, nStims);
    stimQ           = nan * ones(MaxStimExh, nActions, nStims);
    
    for stim = 1:nStims
        trials_v = find(stim_seq == stim);
        stimProb(1:nStimExh(stim), stim)            = stimProb_aux(trials_v, stim);
        stimCurrHS(1:nStimExh(stim), stim)          = stimCurrHS_aux(trials_v, stim);
        stimCurrHS_t(1:nStimExh(stim), stim, s)     = stimCurrHS(1:nStimExh(stim), stim);
        stimBeliefs(1:nStimExh(stim), :, stim)      = stimBeliefs_aux(trials_v, :, stim);
        stimBeliefs_t(1:nStimExh(stim), :, stim, s) = stimBeliefs(1:nStimExh(stim), :, stim);
        stimNormBeliefs(1:nStimExh(stim), :, stim)  = stimNormBeliefs_aux(trials_v, :, stim);
        stimQ(1:nStimExh(stim), :, stim)            = stimQ_aux(trials_v, :, stim);
    end;
    
    % Save variables:
    if options.save.selectedmodelsanalysis
        outputDir = paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelinspectiondir;
        if ~exist(outputDir, 'dir')
            mkdir(outputDir);
        end;
        
        save(paths.results.subjects.tempsubject.models.tempsession.tempmodel.predictedModelVariablesfile,...
            'prob_v', 'currHS_v', 'beliefs_m', 'normBeliefs_m', 'Q_m',...
            'params', 'stim_seq', 'act_seq', 'reinf_seq',...
            'stimProb', 'stimCurrHS', 'stimBeliefs', 'stimNormBeliefs', 'stimQ');
    end;
    clear('MCMCInfo'); % non-ideal implementation
end;

if options.save.selectedmodelsanalysis
    groupOutputDir = paths.results.group.modelinspection.tempsession.alldir;
    if ~exist(groupOutputDir, 'dir')
        mkdir(groupOutputDir);
    end;
    if iModel == options.rl.selectedModel
        save(paths.results.group.modelinspection.tempsession.all.predictedModelVariablesfile, ...
            'stimCurrHS_t', 'stimBeliefs_t');
    end;
end;