function [] = shellmdl_show_belief_pliability(options, paths)
% [] = shellmdl_show_belief_pliability(options, paths)
%
% shellmdl_show_belief_pliability is a function that depicts how beliefs
% are made pliable in the implemented S-S-R models, as a function of gamma, 
% one of the state-inference models. It creates Methods Figure 3 of the
% article.
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  [none]
%
% Author: Vasco A. Concei��o
%
% Last modified: September 2023

%% Initialization/Settings:
nHiddenStates = options.rl.nHS;

figName         = options.figs.figM3.figName;
figDimensions   = options.figs.figM3.figDimensions;

nSimulations    = options.figs.figM3.nPanels;   % number of exemplary panels
gammaValues     = 0:0.1:1;                      % gamma values to be depicted in the examples

fontName        = options.figs.fontName;
labelFontSize   = options.figs.labelFontSize;
fontSize        = options.figs.fontSize;

outputDir   	= paths.results.modelsimulations.pocdir;
figsOutputDir  	= paths.results.modelsimulations.poc.figuresdir;

%% Main Code:
if 1 % options.verbose.modelsimulations % this is commented intentionally; this function requires input from the user, so the user should know when it is being run
    disp(' ');
    disp('--------------------------------------------------------------');
    disp('Running shellmdl_show_belief_pliability...');
    disp(' ');
end;

if ~exist(outputDir, 'dir')
    mkdir(outputDir);
end;
if ~exist(figsOutputDir, 'dir')
    mkdir(figsOutputDir);
end;

f = figure();
set(f, 'name', figName, 'units', 'centimeters', 'position', figDimensions, ...
    'paperunits', 'centimeters', 'paperposition', figDimensions);

for iSimul = 1:nSimulations % each panel of Methods Figure 3
    subplot(nSimulations, 1, iSimul);
    beliefs = -Inf * ones(numel(gammaValues), nHiddenStates);
    deltaBeliefs = zeros(numel(gammaValues), nHiddenStates);
    
    switch iSimul
        case 1
            panelString = 'A';
        case 2
            panelString = 'B';
        case 3
            panelString = 'C';
        case 4
            panelString = 'D';
    end;
    
    simulationLooksGood = 0;
    while ~simulationLooksGood
        beliefs(end, :) = rand(1, nHiddenStates);
        beliefs(end, :) = beliefs(end, :) / sum(beliefs(end, :));   % beliefs to be depicted in the current panel (1-4)
        
        beliefs(end, :) = sort(beliefs(end, :), 'descend');         % sort them to facilitate visualization
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % uncomment the 2 lines below to use the previously saved beliefs:
        % numData         = xlsread([paths.results.modelsimulations.pocdir filesep 'Belief pliability_' num2str(iSimul) '.xls'], ['beliefs_simul_' num2str(iSimul)]);
        % beliefs(end, :) = numData(end, :);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        beliefs(end, :)
        simulationLooksGood = input(['Please see if you want to use the exemplary beliefs above in panel ' panelString '. \nIntroduce 1 if so, and 0 otherwise. \n']);
    end;
    
    for iGamma = 1:(numel(gammaValues)-1)
        gamma = gammaValues(iGamma);
        beliefs(iGamma, :) = beliefs(end,:) .^ gamma;
        beliefs(iGamma, :) = beliefs(iGamma, :)/sum(beliefs(iGamma, :));
        deltaBeliefs(iGamma, :) = beliefs(iGamma, :) - beliefs(end, :);
    end;
    
    hold on;
    b = bar(beliefs, 'grouped');
    set(b(1), 'FaceColor', [0 0 0]);
    set(b(2), 'FaceColor', [0.5, 0.5, 0.5]);
    set(b(3), 'FaceColor', [1 1 1]);
    
    plot([0.5, numel(gammaValues)+0.5], [1/3 1/3], '--k');
    
    switch iSimul
        case 1
            annotation('Line', [0.83 0.83], [0.750 0.925], 'LineWidth', 1, 'LineStyle', '-.');
        case 2
            annotation('Line', [0.83 0.83], [0.53 0.705], 'LineWidth', 1, 'LineStyle', '-.');
        case 3
            annotation('Line', [0.83 0.83], [0.310 0.485], 'LineWidth', 1, 'LineStyle', '-.');
        case 4
            annotation('Line', [0.83 0.83], [0.095 0.265], 'LineWidth', 1, 'LineStyle', '-.');
    end;
    
    axis([0.5, numel(gammaValues)+0.5, 0 1]);
    
    if iSimul == nSimulations
        xlabel('\gamma', 'fontname', fontName, 'fontsize', labelFontSize);
    end;
    ylabel('{\itp^{�}_{t}}({\ith_{i}})', 'fontname', fontName, 'fontsize', labelFontSize);
    if iSimul == nSimulations
        set(gca, 'ytick', 0:1/3:1, 'yticklabel', {'0', '0.33', '0.67', '1'}, ...
            'xtick', 1:(numel(gammaValues)), ...
            'xticklabel', {'0', '0.1', '0.2', '0.3', '0.4', ...
            '0.5', '0.6', '0.7', '0.8', '0.9', '{\itp}_{{\itt}-1}({\ith_{i}})'}, ...
            'fontsize', fontSize, 'fontname', fontName);
    else
        set(gca, 'ytick', 0:1/3:1, 'yticklabel', {'0', '0.33', '0.67', '1'}, ...
            'xtick', 1:(numel(gammaValues)), ...
            'xticklabel', [], ...
            'fontsize', fontSize, 'fontname', fontName);
    end;
    
    if options.save.modelsimulations && options.overwrite.modelsimulations
        save([outputDir filesep figName '_' num2str(iSimul)], 'beliefs', 'deltaBeliefs');
        xlswrite([outputDir filesep figName '_' num2str(iSimul)], beliefs, ['beliefs_simul_' num2str(iSimul)]);
        xlswrite([outputDir filesep figName '_' num2str(iSimul)], deltaBeliefs, ['deltaBeliefs_simul_' num2str(iSimul)]); % same .xls, but different sheet
        
        if options.verbose.modelsimulations
            disp('The data files related to Method Figure 3 were overwritten.');
        end;
    end;
end;

if options.save.modelsimulations && options.overwrite.modelsimulations
    export_fig([figsOutputDir filesep figName], '-transparent', '-tiff', '-r800');
    print([figsOutputDir filesep figName], '-r800', '-depsc', '-tiff');
    if options.verbose.modelsimulations
        disp('Method Figure 3 was overwritten.');
    end;
end;
end