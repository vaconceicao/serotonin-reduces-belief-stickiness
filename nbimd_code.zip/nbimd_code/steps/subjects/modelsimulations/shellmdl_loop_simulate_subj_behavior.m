function [] = shellmdl_loop_simulate_subj_behavior(options, paths, iSimul, iModel, params_simul_m, outputDirInfo, groupOutputDir, groupOutputFile)
% [] = shellmdl_loop_simulate_subj_behavior(options, paths, iSimul, iModel, params_simul_m, outputDirInfo, groupOutputDir, groupOutputFile)
%
% shellmdl_loop_simulate_subj_behavior is a function that simulates the
% trial-by-trial variables of interest for a given reinforcement learning
% (RL) model. For it to run, it requires the previous implementation, and
% compilation, of the eval_llh_modelName_simul.c of interest. That file
% should be inside ...steps/subjects/modelfit/likeli.
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  eval_llh_[modelName]_simul
%
% Author: Vasco A. Concei��o
%
% Last modified: October 2023

%% Settings
modelName   = options.rl.modelNames{iModel};

soi         = options.dataset.subjects;
nEffSubj    = numel(soi);

nStims          = options.dataset.nStim;
nActions        = options.dataset.nActions;
nReinfs         = options.dataset.nReinfs;
nTrials         = options.dataset.nTrials;
maxTrialPerStim = max(options.dataset.nStimTrials);

load([paths.results.group.behavior2modeldir filesep 'stim_m']);
load([paths.results.group.behavior2modeldir filesep 'reinfsIfGo_m']);

%% Main Code
if options.verbose.modelsimulations
    disp(' ');
    disp(['Running shellmdl_loop_simulate_subj_behavior: simulation ' num2str(iSimul) ' - model ' modelName '...']);
end;

stimCurrHS_t    = nan*ones(maxTrialPerStim, nStims, nEffSubj);
stimBeliefs_t   = nan*ones(maxTrialPerStim, options.rl.nHS, nStims, nEffSubj);

stim_simul_m    = nan*ones(nEffSubj, nTrials); % this code should be in shellmdl_aggreg_simulated_behavior
actions_simul_m = nan*ones(nEffSubj, nTrials); % this code should be in shellmdl_aggreg_simulated_behavior
reinfs_simul_m  = nan*ones(nEffSubj, nTrials); % this code should be in shellmdl_aggreg_simulated_behavior

for s = 1:options.dataset.nEffSubjects
    subj            = soi(s);
    paths           = shellmdl_paths(paths, 1, subj, iModel, options);
    
    if isequal(outputDirInfo, 'effectofstateinference')
        outputDir       = paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelsimulations.effectofstateinferencedir;
        outputFile      = [paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelsimulations.effectofstateinferencefile(1:(end - 4)) '-' num2str(iSimul) '.mat'];
    elseif isequal(outputDirInfo, 'modelrecovery')
        outputDir       = paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelsimulations.modelrecoverydir;
        outputFile      = [paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelsimulations.modelrecoveryfile(1:(end - 4)) '-' num2str(iSimul) '.mat'];
    elseif isequal(outputDirInfo, 'paramrecovery')
        outputDir       = paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelsimulations.paramrecoverydir;
        outputFile      = [paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelsimulations.paramrecoveryfile(1:(end - 4)) '-' num2str(iSimul) '.mat'];
    end;
    
    params          = params_simul_m(s, :);
    act_rdm_seq     = rand(options.dataset.nTrials, 1); % array of random numbers between 0 and 1 (probabilities) that will be used to generate the action sequence
    stim_seq        = stim_m(subj, :);
    reinf_if_go_seq = reinfsIfGo_m(subj, :);
    
    % Run the function that calculates the trial-by-trial variables:
    if isequal(options.rl.modelFamilies{iModel}, 'SR')
        [act_v, prob_v, currHS_v, beliefs_m, normBeliefs_m, Q_m] = ...
            eval(['eval_llh_', modelName, '_simul', '(params, stim_seq, act_rdm_seq, reinf_if_go_seq, nStims, nActions, nTrials)']);
    elseif isequal(options.rl.modelFamilies{iModel}, 'SSR')
        [act_v, prob_v, currHS_v, beliefs_m, normBeliefs_m, Q_m] = ...
            eval(['eval_llh_', modelName, '_simul', '(params, stim_seq, act_rdm_seq, reinf_if_go_seq, nStims, nActions, nReinfs, nTrials, options.rl.nHS)']);
    else
        error('Not implemented yet.');
    end;
    
    % Get those variables:
    stim_simul_m(s, :)      = stim_seq;
    actions_simul_m(s, :)   = act_v;
    reinfs_simul_m(s, :)    = reinf_if_go_seq .* (2 - act_v'); % always 0 if NoGo (which is coded as 2 in act_v)
    
    stimProb_aux            = nan * ones(nTrials, nStims);
    stimCurrHS_aux          = nan * ones(nTrials, nStims);
    stimBeliefs_aux         = nan * ones(nTrials, options.rl.nHS, nStims);
    stimNormBeliefs_aux     = nan * ones(nTrials, options.rl.nHS, nStims);
    stimQ_aux               = nan * ones(nTrials, nActions, nStims);
    
    nStimExh                = nan * ones(nStims, 1);
    
    for stim = 1:nStims
        trials_v = find(stim_seq == stim);
        stimProb_aux(trials_v, stim)    = prob_v(trials_v);
        stimCurrHS_aux(trials_v, stim)  = currHS_v(trials_v);
        
        stimBeliefs_aux(trials_v, :, stim)      = beliefs_m(trials_v, :);
        stimNormBeliefs_aux(trials_v,:,stim)    = normBeliefs_m(trials_v, :);   % exactly equal to the unnormalized beliefs
        stimQ_aux(trials_v, :, stim)            = Q_m(trials_v, :);
        nStimExh(stim)                          = length(trials_v);
    end;
    
    % Reshape variables:
    MaxStimExh = max(nStimExh);
    
    stimProb        = nan * ones(MaxStimExh, nStims);
    stimCurrHS      = nan * ones(MaxStimExh, nStims);
    stimBeliefs     = nan * ones(MaxStimExh, options.rl.nHS, nStims);
    stimNormBeliefs = nan * ones(MaxStimExh, options.rl.nHS, nStims);
    stimQ           = nan * ones(MaxStimExh, nActions, nStims);
    
    for stim = 1:nStims
        trials_v = find(stim_seq == stim);
        stimProb(1:nStimExh(stim), stim)            = stimProb_aux(trials_v, stim);
        stimCurrHS(1:nStimExh(stim), stim)          = stimCurrHS_aux(trials_v, stim);
        stimCurrHS_t(1:nStimExh(stim), stim, s)     = stimCurrHS(1:nStimExh(stim), stim);
        stimBeliefs(1:nStimExh(stim), :, stim)      = stimBeliefs_aux(trials_v, :, stim);
        stimBeliefs_t(1:nStimExh(stim), :, stim, s) = stimBeliefs(1:nStimExh(stim), :, stim);
        stimNormBeliefs(1:nStimExh(stim), :, stim)  = stimNormBeliefs_aux(trials_v, :, stim);
        stimQ(1:nStimExh(stim), :, stim)            = stimQ_aux(trials_v, :, stim);
    end;
    
    % Save variables:
    if options.save.modelsimulations && options.overwrite.modelsimulations
        if ~exist(outputDir, 'dir')
            mkdir(outputDir);
        end;
        save(outputFile,...
            'act_v', 'prob_v', 'currHS_v', 'beliefs_m', 'normBeliefs_m', ...
            'Q_m', 'params', 'stim_seq', 'act_rdm_seq', 'reinf_if_go_seq',...
            'stimProb', 'stimCurrHS', 'stimBeliefs', 'stimNormBeliefs', 'stimQ');
    end;
end;

if options.save.modelsimulations && options.overwrite.modelsimulations
    if ~exist(groupOutputDir, 'dir')
        mkdir(groupOutputDir);
    end;
    save(groupOutputFile, ...
        'stimCurrHS_t', 'stimBeliefs_t', ...
        'params_simul_m', 'stim_simul_m', 'actions_simul_m', 'reinfs_simul_m');
    if options.verbose.modelsimulations
        disp(' The output files from shellmdl_loop_simulate_subj_behavior were overwritten.');
    end;
end;