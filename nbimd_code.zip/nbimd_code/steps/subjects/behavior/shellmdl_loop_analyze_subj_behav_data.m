function [] = shellmdl_loop_analyze_subj_behav_data(options, paths)
% [] = shellmdl_loop_analyze_subj_behav_data(options, paths)
%
% shellmdl_loop_analyze_subj_behav_data is a function called by 
% shellmdl_master, which loops across subjects, evoking the auxiliary 
% function that will analyze the data from each subject of interest; i.e., 
% from each subject specified in options.dataset.subjects.
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  shellmdl_paths
%  shellmdl_analyze_subj_behav_data
%
% Last modified: September 2023

%% Main Code
if options.verbose.behavioralanalysis
    disp(' ');
    disp('--------------------------------------------------------------');
    disp('Running shellmdl_loop_analyze_subj_behav_data...');
end;

for iSubject = 1:options.dataset.nEffSubjects
    subject = options.dataset.subjects(iSubject);
    
    paths = shellmdl_paths(paths, 1, subject);
    shellmdl_analyze_subj_behav_data(options, paths, subject);
end;
end