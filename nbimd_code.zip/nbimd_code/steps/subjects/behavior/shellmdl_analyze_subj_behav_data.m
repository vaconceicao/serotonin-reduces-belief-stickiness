function [] = shellmdl_analyze_subj_behav_data(options, paths, subject)
% [] = shellmdl_loop_analyze_subj_behav_data(options, paths, subject)
%
% shellmdl_loop_analyze_subj_behav_data is a function called by 
% shellmdl_loop_analyze_subj_behav_data, which calculates the accuracy of 
% each subject, on each trial, saving the respective subject-specific
% output file.
%
% Called in:
%  shellmdl_loop_analyze_subj_behav_data
%
% List of key auxiliary functions:
%  [none]
%
% Author: Vasco A. Concei��o
%
% Last modified: September 2023

%% Settings
inputFile1  = paths.results.subjects.tempsubject.behavior.tempsession.preprocfile;
inputFile2  = paths.results.subjects.tempsubject.tracefile;

outputDir   = paths.results.subjects.tempsubject.behavior.tempsession.procdir;
outputFile  = paths.results.subjects.tempsubject.behavior.tempsession.procfile;

%% Main Code
load(inputFile1);
load(inputFile2);

D.proc.accuracy = -Inf * ones(1, options.dataset.nTrials);
for iTrial = 1:options.dataset.nTrials
    actions = options.dataset.nActions - D.preproc.gonogo; % in actions, like in options.dataset.state2correctaction, 1 corresponds to Go and 2 to NoGo
    D.proc.accuracy(iTrial) = (actions(iTrial) == options.dataset.state2correctaction(D.preproc.stim(iTrial), traceInfo.states(iTrial)));

    if options.dataset.state2correctaction(D.preproc.stim(iTrial), traceInfo.phases(iTrial)) == 0
        D.proc.accuracy(iTrial) = nan; % trials from neutral seasons, for which there is no correct answer
    end;
end;

%% Saving
saveBool = options.save.behavioralanalysis;
if saveBool
    if ~exist(outputDir, 'dir')
        mkdir(outputDir);
    end;
        
    overwriteBool = options.overwrite.behavioralanalysis;
    if overwriteBool || ~exist(outputFile, 'file')
        if options.verbose.behavioralanalysis
            disp([' Results from shellmdl_loop_analyze_subj_behav_data for subject ' num2str(subject) ' were overwritten.']);
        end;
        save(outputFile, 'D');
        
    else %%% seems to be working well, but non-overwritten files won't be used in the ensuing analyses steps unless the code is further changed
        if options.verbose.behavioralanalysis
            disp([' Results from shellmdl_loop_analyze_subj_behav_data for subject ' num2str(subject) ' were saved, but not overwritten.']);
        end;
        b = exist(outputFile, 'file'); fileCounter = 1;
        while b
            b = exist([outputFile(1:end-4) '_' num2str(fileCounter) '.mat'], 'file');
            fileCounter = fileCounter + 1;
        end;
        save([outputFile(1:end-4) '_' num2str(fileCounter - 1) '.mat'], 'D');
    end;
    
else
    if options.verbose.behavioralanalysis
        disp([' Results from shellmdl_loop_analyze_subj_behav_data for subject ' num2str(subject) ' were not saved.']);
    end;
end;
end