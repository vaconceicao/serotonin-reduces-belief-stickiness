function [] = shellmdl_loop_subj_invert_model(options, paths, modelInfo, MCMCInfo, varargin)
% [] = shellmdl_loop_subj_invert_model(options, paths, modelInfo, MCMCInfo)
%
% shellmdl_loop_subj_invert_model is a function that performs 
% population-MCMC inversion of a given reinforcement-learning (RL) model, 
% as specified in options, modelInfo, and MCMCInfo.
%
% Depending on the input (MCMCInfo.procedure), this function may perform
% either thermodynamic integration (TI, to obtain model evidences) or model
% diagnosis (to obtain parameter estimates while assessing the likelihood
% of non-convergence of the inversion routine).
%
% The results are stored as specified in paths.
%
% List of key auxiliary functions:
%  shellmdl_get_param_bounds
%  shellmdl_config_behav_input
%  tapas_pars
%  tapas_ptheta
%  tapas_htheta
%  tapas_ti_estimate
%  psrf
%
% Last modified: September 2023
%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Additional details:
%
% Input:
%  options              Struct defined in shellmdl_set_analysis_options
%  paths                Struct defined in shellmdl_paths
%  modelInfo            Struct with information regarding the dataset and
%                           RL model to be inverted; defined in
%                           shellmdl_master in agreement with options
%  MCMCInfo             Struct with information regarding the
%                           population-MCMC inversion (fitting) of the RL
%                           model; defined in shellmdl_master, in agreement
%                           with options
%
% Output:
%  [none]
%
% The full list of references and authors is lacking from this function.
% It should be checked elsewhere.

%% Obtain additional dataset-, RL-, or population-MCMC- related info: -----
% Dataset info ------------------------------------------------------------
if modelInfo.dataset.dataSpecification == 1 || modelInfo.dataset.dataSpecification == 2 % 1, if analyzing acquired data; 2, if analyzing data simulated for the same traces
    behavInput.useTaskAlikeData = 1;    % 1 if loaded data has task-alike properties
    behavInput.useAcqTraces = 1;        % 1, if desired to use the traces used for data acquisition
    if modelInfo.dataset.dataSpecification == 1
        behavInput.useAcqSeq = 1;       % 1, if the action and obtained reinforcement sequences should be loaded
    else
        behavInput.useAcqSeq = 0;
    end;
    
else
    error('Code not relevant for this article.');
end;
modelInfo.behavInput = behavInput;

if modelInfo.behavInput.useTaskAlikeData
    if modelInfo.behavInput.useAcqTraces
        paths = shellmdl_paths(paths, modelInfo.dataset.session);
        traceDataFolder = getfield(modelInfo.dataset.traceDataFolder, 'tempsessiondir');
    else
        error('Code not relevant for this article.');
    end;
        
    behavDataFolder    = traceDataFolder;
    load([behavDataFolder filesep 'stim_m']);
    
    if modelInfo.behavInput.useAcqSeq
        load([behavDataFolder filesep 'actions_m']);
        load([behavDataFolder filesep 'reinfs_m']);
    else
        load(varargin{1});
        actions_m   = -Inf * ones(max(modelInfo.dataset.subjsOfInterest), options.dataset.nTrials);
        actions_m(modelInfo.dataset.subjsOfInterest, :) = actions_simul_m;
        reinfs_m    = -Inf * ones(max(modelInfo.dataset.subjsOfInterest), options.dataset.nTrials);
        reinfs_m(modelInfo.dataset.subjsOfInterest, :) = reinfs_simul_m;
    end;
    
    load([traceDataFolder filesep 'reinfsIfGo_m']);
end;

if exist('actions_m', 'var')
    modelInfo.dataset.actions       = actions_m;
else
    error('');
end;
if exist('reinfs_m', 'var')
    modelInfo.dataset.reinfs        = reinfs_m;
else
    error('');
end;
if exist('reinfsIfGo_m', 'var')
    modelInfo.dataset.reinfsIfGo    = reinfsIfGo_m;
else
    error('');
end;
if exist('RTs_m', 'var')
    modelInfo.dataset.RTs           = RTs_m;
else
    error('');
end;
if exist('stim_m', 'var')
    modelInfo.dataset.stim          = stim_m;
else
    error('');
end;

% RL Model info -----------------------------------------------------------
[ptheta] = shellmdl_get_param_bounds(modelInfo);

% MCMC info ---------------------------------------------------------------
switch MCMCInfo.procedure
    case 1
        procedureName = 'thermodynamic integration';
    case 2
        procedureName = 'MCMC diagnosis';
    case 3
        error('Not implemented yet.'); % cross-model comparison
end;

%% Fitting procedure: -----------------------------------------------------
fprintf('\n%s%s\n', ...
    'Dataset: ', modelInfo.dataset.name);
fprintf('%s%s%s%s%s\n', ...
    'Running ', procedureName, ' for model ', modelInfo.rl.modelName, '...');

firstSubj = min(modelInfo.dataset.subjsOfInterest);
lastSubj = max(modelInfo.dataset.subjsOfInterest);
subjsOfInterest_v = modelInfo.dataset.subjsOfInterest;

for subj = firstSubj:1:lastSubj
    if ismember(subj, subjsOfInterest_v)
        
        fprintf('\n%s%d%s\n', '------------------------ Cycle for subject ', subj, ' has began. ------------------------');
        tic;
        
        %% Configure behavioral input -------------------------------------
        [modelInfo] = shellmdl_config_behav_input(modelInfo, subj, options, paths);
        
        %% Set pointers and other settings for tapas_ti_estimate ----------
        pars    = tapas_pars(MCMCInfo);
        ptheta  = tapas_ptheta(ptheta, modelInfo, MCMCInfo);
        htheta  = tapas_htheta(modelInfo);
        
        %% Inversion using population MCMC with TI ------------------------        
        [samples, meList] = tapas_ti_estimate_changed(modelInfo.dataset.actSeq, modelInfo.dataset.reinfSeq, ptheta, htheta, pars);
        % this is an adaptation of tapas_ti_estimate, a function that was
        % included in previous TAPAS packages; the function evoked here was
        % slightly adapted to allow the calculation of distinct 
        % model-evidence approximations (e.g., AIC_m) and to display and
        % store data in a personalzied manner, among other things
        results.samples = samples;
        
        %% Saving the results ---------------------------------------------
        %% Define the folder where the results from run_model will be stored, and, if necessary, create it
        if modelInfo.behavInput.useTaskAlikeData
            paths = shellmdl_paths(paths, modelInfo.dataset.session, subj, modelInfo.rl.iModelNumber, options);
            if modelInfo.behavInput.useAcqSeq
                MCMCInfo.resultsFolder = getfield(paths.results.subjects.tempsubject.models.tempsession.tempmodel, MCMCInfo.outputFolder);
            else
                MCMCInfo.resultsFolder = getfield(paths.results.subjects.tempsubject.models.tempsession.tempmodel.modelsimulations, MCMCInfo.outputFolder);
                MCMCInfo.resultsFolder = [MCMCInfo.resultsFolder filesep num2str(MCMCInfo.simulatedDataset)];
            end;
        else
            error('Not implemented yet.');
        end;

        if ~exist(MCMCInfo.resultsFolder, 'dir')
            mkdir(MCMCInfo.resultsFolder);
        end;
        
        if ~MCMCInfo.powerTemp % calculate Rhats anc CIs to assess convergence
            results.pR = psrf(results.samples.ps_theta_all);
            results.llhR = psrf(results.samples.llh_all);
            results.pCI = quantile(results.samples.ps_theta_all,[0.025 0.05 0.1 0.5 0.9 0.95 0.975]);
            if ~MCMCInfo.saveAll % to avoid storing unnecessary information
                results.samples = rmfield(results.samples, 'ps_theta_all');
                results.samples = rmfield(results.samples, 'llh_all');
            end;
            
        else % calculate model evidence using thermodynamic integration
            results.pCI = quantile(results.samples.ps_theta', [0.025 0.05 0.1 0.5 0.9 0.95 0.975]);
            results.meList = meList;
            results.me = meList(end);
            if ~MCMCInfo.saveAll % to avoid storing unnecessary information
                results.samples = rmfield(results.samples, 'ps_theta_all');
                results.samples = rmfield(results.samples, 'llh_all');
            end;
        end;
        
        results.duration = toc;
        
        resultsFile_aux = [MCMCInfo.resultsFolder, filesep, MCMCInfo.fileName, num2str(subj), '.mat'];
        if ~MCMCInfo.overwrite
            if exist(resultsFile_aux, 'file')
                b = exist(resultsFile_aux, 'file');
                counter = 2;
                while b
                    resultsFile_aux = [MCMCInfo.resultsFolder, filesep, MCMCInfo.fileName, num2str(subj), '_' num2str(counter) '.mat'];
                    b = exist(resultsFile_aux, 'file');
                    counter = counter + 1;
                end;
            end;
        end;
        resultsFile = resultsFile_aux;
        save(resultsFile, 'modelInfo', 'MCMCInfo', 'results');
        
    end;
end;

%% Auxiliary functions: ---------------------------------------------------
function [htheta] = tapas_htheta(modelInfo)
% Returns a struct with information about the standard hyperpriors of the
% model. This struct will be given as input to tapas_ti_estimate.
%
% Input
%   modelInfo   Struct with model specifications
%
% Output
%   htheta      Standard hyperpriors (htheta.pk is the precision kernel).
%
% Authors:
%
% Last modified:

% Precision kernel:
htheta.pk = eye(modelInfo.rl.nParams);

htheta.updatekernel = 0; % indicates that adaptive sampling is switched off

function [ptheta] = tapas_ptheta(ptheta, modelInfo, MCMCInfo)
% Returns a struct with information about the standard priors of the model.
% This struct will be given as input to tapas_ti_estimate.
%
% Input
%   ptheta      Struct with information about the priors of the model
%   modelInfo   Struct with model specifications
%
% Output
%   ptheta      Struct with updated information about the priors of the
%               model
%
% Authors:
%
% Last modified:

ptheta.nParams      = modelInfo.rl.nParams;
ptheta.nChains      = MCMCInfo.nChains;
ptheta.powerTemp    = MCMCInfo.powerTemp;

ptheta.modelFamilyNumber    = modelInfo.rl.modelFamilyNumber;
ptheta.modelNumber          = modelInfo.rl.modelNumber;

ptheta.paramsPriorDist          = [modelInfo.rl.priorDistTypes, modelInfo.rl.priorDistParams];
ptheta.paramsPriorDistTransf    = modelInfo.rl.priorDistTransf;

ptheta.stimSeq  = modelInfo.dataset.stimSeq;

ptheta.nStims   = modelInfo.dataset.nStims;
ptheta.nActions = modelInfo.dataset.nActions;
ptheta.nReinfs  = modelInfo.dataset.nReinfs;
ptheta.nTrials  = modelInfo.dataset.nTrials;

ptheta.nHS      = modelInfo.rl.nHS;

% ptheta  = modelInfo;
ptheta.jm = eye(ptheta.nParams); % projection matrix; this matrix can be
% used to define nested models by defining a low rank matrix

[ptheta.mu, ptheta.p0] = gen_init_param_values(modelInfo); % initial values of the
% parameters; should be either (1) different for each chain OR (2) equal to
% the expected value of the prior distribution
ptheta.p0 = ptheta.mu;

for p = 1:ptheta.nParams
    % Covariance of the proposal distribution:
    ptheta.params(p).lambda = MCMCInfo.proposal(p, 1);
    ptheta.params(p).Sigma = MCMCInfo.proposal(p, 2);
end;

% Propose sample and calculate Hastings ratio:
ptheta.mh_propose_sample = @tapas_ti_propose_theta;

% Estimate log-likelihood:
ptheta.llh = @tapas_llh;
ptheta.method = @tapas_eval_llh;

% Estimate log prior probability:
ptheta.lpp = @tapas_lpp;

% Transformation of the parameters from sampling space (usually the real
% interval) to the interval defined by the likelihood function:
ptheta.ptrans = @tapas_ptrans;

function [pars] = tapas_pars(MCMCInfo)
% Returns a struct with information about the MCMC settings. This struct
% will be given as input to tapas_ti_estimate.
%
% Input
%   MCMCInfo    Struct with information concerning the MCMC procedure
%
% Output
%   pars        Struct with information for TI estimation using
%               tapas_ti_estimate
%
% Authors:
%
% Last modified:

pars = struct();
pars.T = linspace(0, 1, MCMCInfo.nChains) .^ MCMCInfo.powerTemp;
pars.nburnin = MCMCInfo.nBurninIterations;
pars.niter = MCMCInfo.nIterations;
pars.verbose = MCMCInfo.verbose; % boolean indicating ... whether or not
% the MCMC information will be displayed

pars.samples = 1;   % ... whether or not the samples will be saved
pars.mc3it = 8;     % number of swaps per iteration