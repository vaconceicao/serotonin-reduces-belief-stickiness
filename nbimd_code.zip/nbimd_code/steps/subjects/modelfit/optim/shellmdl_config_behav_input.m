function [modelInfo] = shellmdl_config_behav_input(modelInfo, subj, options, paths)
% [modelInfo] = shellmdl_config_behav_input(modelInfo, subj, options, paths)
%
% shellmdl_config_behav_input is an auxiliary function called in 
% shellmdl_loop_subj_invert_model. It defines the behavioral sequences that 
% characterize the (simulated) subject whose data is being fitted, and 
% stores them in its output, modelInfo.
%
% Called in:
%  shellmdl_loop_subj_invert_model
%
% List of key auxiliary functions:
%  [none]
%
% Author: Vasco A. Concei��o
%
% Last modified: October 2023

%% Get variables:
dataset     = modelInfo.dataset;
behavInput  = modelInfo.behavInput;
goNogo      = dataset.goNogo;

useTaskAlikeData    = behavInput.useTaskAlikeData;
useAcqTraces        = behavInput.useAcqTraces;

%% Main code:
if useTaskAlikeData % use task-alike data
    
    stim_m                          = dataset.stim;
    modelInfo.dataset.stimSeq       = stim_m(subj,:); 
    modelInfo.dataset.nStims        = max(modelInfo.dataset.stimSeq);               % number of stimuli
    modelInfo.dataset.nTrials       = size(modelInfo.dataset.stimSeq, 2);           % number of trials
    
    if useAcqTraces % load acquired (or simulated) sequences
        actions_m                   = dataset.actions;
        reinfs_m                    = dataset.reinfs;
        % RT_m                      = dataset.RTs;
        modelInfo.dataset.actSeq    = actions_m(subj, :); 
        modelInfo.dataset.nActions  = max(modelInfo.dataset.actSeq);                % number of possible actions
        modelInfo.dataset.reinfSeq  = reinfs_m(subj,:); 
        modelInfo.dataset.nReinfs   = numel(unique(modelInfo.dataset.reinfSeq));    % number of possible reinforcements
        
    else
        error('This is not necessary for NBIMD.');
    end;
    
else % otherwise, simulate everything or load manually
     error('This is not necessary for NBIMD.');      
end;
end