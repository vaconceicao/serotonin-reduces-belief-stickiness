function [ntheta] = tapas_ptrans(theta,varargin)
% Transforms the parameters to their native space.
%
% Input
%   theta       Parameters 
%
% Output
%   ntheta      Transformation of the parameters
%
% Authors: 
%
% Last modified:

if ~isempty(varargin)
    ptheta = varargin{1};
    paramsPriorDistTransf = ptheta.paramsPriorDistTransf;
end;

try % requires that tapas_ti_estimate is changed
    ntheta = theta .* repmat(paramsPriorDistTransf(:,1), 1, size(theta,2)) + ...
        repmat(paramsPriorDistTransf(:,2), 1, size(theta, 2));
catch % if tapas_ti_estimate is not changed, the parameter transformation
    % must be implemented here a priori:
    ntheta = theta;
end;
    
end 

