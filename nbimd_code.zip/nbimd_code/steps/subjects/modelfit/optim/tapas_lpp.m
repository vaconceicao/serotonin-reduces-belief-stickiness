function [lpp] = tapas_lpp(theta, ptheta)
%
% Input
%   theta       Parameters
%   ptheta      Information about the priors and other auxiliary variables
%
% Output
%   lpp         Value of the log-prior probability
%
% Authors:
%
% Last modified:

paramsPriorDist = ptheta.paramsPriorDist;
paramsPriorDistTransf = ptheta.paramsPriorDistTransf;
lpp = zeros(1, ptheta.nChains);

for c = 1:ptheta.nChains
    lpp_aux = zeros(1, ptheta.nParams);
    
    for p = 1:ptheta.nParams
        if ptheta.paramsPriorDist(p,1) == 1
            lpp_aux(p) = log(betapdf(theta{c}(p),paramsPriorDist(p,2),paramsPriorDist(p,3)) / abs(paramsPriorDistTransf(p,1)));
        elseif ptheta.paramsPriorDist(p,1) == 2
            lpp_aux(p) = log(gampdf(theta{c}(p),paramsPriorDist(p,2),paramsPriorDist(p,3)) / abs(paramsPriorDistTransf(p,1)));
        elseif ptheta.paramsPriorDist(p,1) == 3
            lpp_aux(p) = log(unifpdf(theta{c}(p),paramsPriorDist(p,2),paramsPriorDist(p,3)) / abs(paramsPriorDistTransf(p,1)));
        else
            error('Parameter distributions were misspecified.');
        end;
    end;

    lpp(c) = sum(lpp_aux);
end;

end
