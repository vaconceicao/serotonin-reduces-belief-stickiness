function [llh, x] = tapas_llh(actSeq, reinfSeq, theta, ptheta)
% Auxiliary function called by tapas_ti_estimate. It computes the 
% log-likelihood of the data, through the use of an auxiliary function: 
% tapas_eval_llh (ptheta.method).
%
% Input
%   actSeq      Sequence of actions (observed data)
%   reinfSeq    Sequence of reinforcements (input)
%   theta       Parameters
%   ptheta      Information about the priors and other auxiliary variables
%
% Output
%   llh         Value of the log-likelihood
%
% Authors:
%
% Last modified:

nChains = ptheta.nChains;
llh = zeros(1, nChains);

x = cell(1, nChains);
eval_llh = ptheta.method;

for i = 1:nChains
    llh(i) = eval_llh(ptheta.ptrans(theta{i}(:), ptheta), ptheta.stimSeq, actSeq, reinfSeq, ...
        ptheta.nStims, ptheta.nActions, ptheta.nReinfs, ptheta.nTrials, ptheta.nHS, ...
        ptheta.modelFamilyNumber, ptheta.modelNumber);
end

