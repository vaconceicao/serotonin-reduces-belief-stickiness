function [ps, feList] = tapas_ti_estimate_changed(y, u, ptheta, htheta, pars)
% Auxiliary function called in shellmdl_loop_subj_invert_model. This 
% function is extremely similar to tapas_ti_estimate, which belang to an 
% older TAPAS version. 
% tapas_ti_estimate(_changed) estimates the posterior probability of the 
% parameters using MCMC combined with path sampling; detailed information
% on tapas_ti_estimate is pasted below.
%
% Input
%   y           Behavioral data.
%   u           Experimental input.
%   ptheta      Priors of the model
%   htheta      Kernel transformation.
%   pars        Parameters for the MCMC.
%               pars.verbose    True or false. Defs. False.
%               pars.mc3it      Number of iterations for MC3. Defs. 0.
%               pars.kup        Number of steps for the kernel update.
%                               Defs. 500.
%               pars.seed       Seed for the random generation. If zero use
%                               rng('shuffle'). Defaults to zero.
%               pars.samples    If true, stores the samples from the chain at
%                               lowest temperature. Defaults to zero.
%
% Output
%   ps          Samples from the posterior distribuion
%   feList      List of free energy estimates
%
% Uses a standard MCMC on a population and applies an exchange operator
% to improve the mixing.
%
% Reference: Real parameter evolutionary Monte Carlo with applications to Bayes Mixture
% Models, Journal of American Statistica Association, Liang & Wong 2001.
%
% aponteeduardo@gmail.com
% copyright (C) 2014
%
% Last modified: May 2016

if ~isfield(pars, 'verbose')
    pars.verbose = 0;
end

if ~isfield(pars, 'mc3it')
    pars.mc3it = 0;
end

if ~isfield(pars, 'kup')
    pars.kup = 500;
end

if ~isfield(pars, 'seed')
    pars.seed = 0;
end

if ~isfield(pars, 'samples')
    pars.samples = 0;
end

if pars.seed > 0
    rng(pars.seed);
else
    rng('shuffle');
end

T = pars.T;
nburnin = pars.nburnin;
niter = pars.niter;

ptheta.T = T;

nt = numel(T);

llh = @ptheta.llh;
lpp = @ptheta.lpp;

% Prepare ptheta
[htheta] = init_htheta(ptheta, htheta);
[ptheta] = init_ptheta(ptheta, htheta);
[otheta] = init_theta(ptheta, htheta);

[ollh, ox] = llh(y, u, otheta, ptheta);

[olpp] = lpp(otheta, ptheta);

ollh = sum(ollh, 1); %%% these are useless...
nlpp = sum(olpp, 1); %%% these are useless...

ps_theta = zeros(numel(otheta{end}), niter);
pp_theta = zeros(numel(otheta{end}), niter);
ellh = zeros(nt, niter);

ps_theta_all = zeros(niter, numel(otheta{end}), nt); %%% doing numel too many times

diagnostics = zeros(1, nt);

os = zeros(numel(otheta{1}), nt, pars.kup); %%% should not be doing numel all the time; value should be saved

t = 1;

for i = 1 : nburnin + niter
    % fprintf('Running iteration %d... \n', i);
    if pars.verbose && ismember(i,floor((nburnin+niter)*(0.05:0.05:1)));
        fprintf('%s%d%s\n', 'Status: ', floor(100 * i/(nburnin+niter)),'% Completed...');
    end;
    if i > 1 && mod(i-1, pars.kup) == 0
        diagnostics = diagnostics/pars.kup;
        if pars.verbose
            disp('----------------------------');
            fprintf(1, 'Iter %d \n', i);
            fprintf(1, 'diagnostics: \n');
            fprintf(1, '%0.2f ', diagnostics); %%% this is an average value...
            fprintf(1, '\n');
            fprintf(1, 'log-likelihood: \n');
            fprintf(1, '%0.2f ', ollh); %%% why not show something similar here?
            fprintf(1, '\n');
            if i > nburnin && nt > 1 && ptheta.powerTemp
                fe = trapz(T, mean(ellh(:,1:i-nburnin), 2));
                fprintf(1, 'Fe: %0.05f \n', fe);
            end
            disp('----------------------------');
        end
        if i <= nburnin
            % Keep changing the kernel at the same rate
            if(htheta.updatekernel == 1) %%% uncommented 26 June 2017
                % try
                htheta.ok = update_kernel(1, os, diagnostics, ptheta, htheta);
                % catch
                %     htheta.info = 'kernel update failed';
                %     disp('Kernel could not be updated because of an error. Kernel update was skipped!');
            end;
            %end
        end
        diagnostics(:) = 0;
        t = t + 1;
    end
    
    [ox, otheta, ollh, olpp, v] = tapas_ti_step_mh(y, u, ox, otheta, ...
        ollh, olpp, ptheta, htheta, pars);
    
    diagnostics(:) = diagnostics(:) + v(:);
    
    if i > nburnin
        ps_theta(:, i - nburnin) = otheta{end};
        for chain = 1:nt
            ps_theta_all(i - nburnin, :, chain) = ptheta.ptrans(otheta{chain},ptheta);
        end;
        ellh(:, i - nburnin) = ollh;
    else
        os(:, :, mod(i-1, pars.kup) + 1) = cell2mat(otheta);
    end
    
    for l = 1:pars.mc3it
        s = ceil(rand()*(nt-1));
        p = min(1, exp(ollh(s) * T(s+1) + ollh(s+1) * T(s) ...
            - ollh(s) * T(s) - ollh(s+1) * T(s+1)));
        if rand() < p
            ollh([s, s+1]) = ollh([s+1, s]);
            olpp([s, s+1]) = olpp([s+1, s]);
            ox([s, s+1]) = ox([s+1, s]);
            otheta(:, [s, s+1]) = otheta(:, [s+1, s]);
        end
    end
    
end

% If only one chain don't compute the free energy
if nt > 1
    % argTI = [mean(ellh,2),pars.T'];
    % feList = model_evidence_TI_trace(argTI,2);
    argTI = [ellh,pars.T'];
    feList = model_evidence_TI_trace_changed(argTI,2);
    % fe = feList(end);
    fe = trapz(T, mean(ellh, 2));
else
    fe = Nan;
end

% =============================================================================

% Expected posterior of theta

ptrans = ptheta.ptrans; % Transformation function of the parameters
ps.pE = mean(ptrans(ps_theta,ptheta), 2);
ps.pP = mean(ptrans(pp_theta,ptheta), 2);

% MAP
[maxLLH, i] = max(ellh(end, :));
ps.map = ptrans(ps_theta(:, i),ptheta); %%% this is not the map estimate; prior is not being taken into account
% Posteriors of theta
ps.ps_theta = [];
if pars.samples
    ps.ps_theta = ptrans(ps_theta,ptheta);
    ps.ps_theta_all = ps_theta_all;
    ps.llh_all = reshape(ellh',niter,1,nt);
end
% Approximations to the model evidence
ps.AIC = maxLLH - ptheta.nParams;
ps.ME = fe;
ps.BIC = maxLLH - ptheta.nParams/2 * log(ptheta.nTrials);
% Log likelihood of posterior
ps.llh = ellh(end, :);
% Initial values
ps.y = y;
ps.u = u;
ps.ptheta = ptheta;
ps.htheta = htheta;
ps.pars = pars;

end % tapas_ti_estimate

function [nhtheta] = init_htheta(ptheta, htheta)
% Init the parameters of the sampler

nhtheta = htheta;

% It is better not to adapt certain parameteres
if ~isfield(htheta, 'mixed')
    nhtheta.mixed = ones(size(ptheta.jm, 1), 1);
end

nhtheta.nmixed = abs(nhtheta.mixed - 1);
nhtheta.knmixed = chol(htheta.pk)' * ptheta.jm;

nhtheta.ok = init_kernel(ptheta, nhtheta);

end

function [nk] = init_kernel(ptheta, htheta)
%% Initilize the kernel or covariance matrix of the proposal distribution.
%
% See Exploring an adaptative Metropolis Algorithm
%

np = size(htheta.pk, 1);

njm = tapas_ti_zeromat(ptheta.jm);

c = njm' * htheta.pk * njm;
c = chol(c);

nk = cell(numel(ptheta.T), 1);
nk(:) = {c};

k =  0.05 * chol(htheta.pk)' * ptheta.jm;
tk = cell(numel(ptheta.T), 1);
tk(:) = {k};
nk = struct('S', nk, 's', 0.05, 'k', tk);

end

function [ntheta] = init_theta(ptheta, htheta)
%% Initial values of theta with the prior expected value
%
% Input
%   T - Temperatures
%   ptheta - Priors
%
% Output
%   ntheta -- Initialized structure array.

if isfield(ptheta, 'p0')
    mu = ptheta.p0;
else
    mu = ptheta.mu;
end

ntheta = cell(1, numel(ptheta.T));
ntheta(:) = {mu};

end

function [nptheta] = init_ptheta(ptheta, htheta)
% Precompute certain quantities

nptheta = ptheta;

if ~isfield(ptheta, 'sm')
    nptheta.sm = tapas_ti_zeromat(ptheta.jm);
end

end

function [nk] = update_kernel(t, os, ar, ptheta, htheta)

%% Computes a new kernel or covariance for the proposal distribution.
%
% ok    Old kernel
% os    Old samples
% ar    Acceptance rate
%
% See Exploring an adaptative Metropolis Algorithm
%

c0 = 1.0;
c1 = 0.8;

gammaS = t^-c1;
gammas = c0*gammaS;

ns = size(os, 3);
nd = size(os, 1);
ok = htheta.ok;
nk = ok;

% Optimal log rejection rate
ropt = 0.234;

sm = ptheta.sm;

for i = 1:numel(ok)
    % From Cholesky form to covariance form
    ok(i).S = ok(i).S' * ok(i).S; %%% changed by VC (12 May 2017)
    % Empirical variance
    ts = squeeze(os(:, i, :));
    ts = bsxfun(@minus, ts, mean(ts, 2));
    ts = sm' * ts;
    ek = (ts * ts')./(ns-1);
    % Set new kernel
    nk(i).S = ok(i).S + gammaS * ( ek - ok(i).S);
    % Compute the Cholesky decomposition
    nk(i).S = chol(nk(i).S);
    % Set new scaling
    nk(i).s = exp(log(ok(i).s) + gammas * (ar(i) - ropt));
    nk(i).k = ptheta.jm * nk(i).s * nk(i).S;
end

end

