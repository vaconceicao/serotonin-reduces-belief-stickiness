function [ntheta, ratio] = tapas_ti_propose_theta(otheta, ptheta, htheta)
% Auxiliary function called in tapas_ti_step_mh that provides as output
% the new set of parameters for each chain (ntheta), and the MH assymetry-
% -correction ratio.
%
% Input
%   otheta      Old values of the parameters for each chain
%   ptheta      Information about the priors of the parameters
%   htheta      Information about the hyperpriors of the parameters
%
% Output
%   ntheta      New values of the parameters for eahc chain
%   ratio       MH assymetry ratio
%
% Detailed description is missing.
%
% Reference: Real parameter evolutionary Monte Carlo with applications to 
% Bayes Mixture Models, Journal of American Statistica Association, 
% Liang & Wong 2001.
%
% Copyright info is lacking, but all TAPAS functions were originally 
% developed by TAPAS creators. They have, at most, minor adaptations here.
%
% Last modified: May 2016

nt = numel(otheta); % number of chains
ratio = zeros(1, nt); % this assumes that the kernel has not been trucated
ntheta = otheta; % new values of theta

l = ptheta.lowerBounds;
u = ptheta.upperBounds;

for i = 1:nt
    
    for iParam = 1:ptheta.nParams
        
        m = otheta{i}(iParam);
        s = sqrt(ptheta.params(iParam).lambda* ptheta.params(iParam).Sigma);

        randa = trandn((l(iParam)-m)/s,(u(iParam)-m)/s);    
        ntheta{i}(iParam) = randa*s + m;

        cdf1 = (l(iParam)-otheta{i}(iParam))/s;
        cdf2 = (l(iParam)-ntheta{i}(iParam))/s;
        cdf11 = (u(iParam)-otheta{i}(iParam))/s;
        cdf22 = (u(iParam)-ntheta{i}(iParam))/s;

        ratio(i) = ratio(i) + log((cdf('Normal',cdf22,0,1)-cdf('Normal',cdf2,0,1)))...
            - log((cdf('Normal',cdf11,0,1)-cdf('Normal',cdf1,0,1)));

    end; 
    
end;  
end

