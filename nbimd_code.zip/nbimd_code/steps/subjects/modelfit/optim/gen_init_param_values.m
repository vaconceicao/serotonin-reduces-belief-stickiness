function [mu, p0] = gen_init_param_values(modelInfo)
% [mu, p0] = gen_init_param_values(modelInfo)
%
% This function is based on a prior function by Sudhir Raman.
%
% It was adapted by Vasco A. Concei��o. 

p0 = -Inf * ones(modelInfo.rl.nParams,1);
mu = -Inf * ones(modelInfo.rl.nParams,1);

paramsPriorDist = [modelInfo.rl.priorDistTypes, modelInfo.rl.priorDistParams];

for p = 1:modelInfo.rl.nParams
    if paramsPriorDist(p,1) == 1
        p0(p) = betarnd(paramsPriorDist(p,2), paramsPriorDist(p,3));
        mu(p) = paramsPriorDist(p,2) / sum(paramsPriorDist(p,2:3));
    elseif paramsPriorDist(p,1) == 2
        p0(p) = gamrnd(paramsPriorDist(p,2), paramsPriorDist(p,3));
        mu(p) = prod(paramsPriorDist(p,2:3));
    elseif paramsPriorDist(p,1) == 3
        p0(p) = unifrnd(paramsPriorDist(p,2), paramsPriorDist(p,3));
        mu(p) = mean(paramsPriorDist(p,2:3));
    else
        error('Not implemented yet.');
    end;
end;