%% --------------------------------------------------------------------------------------------------
% model_evidence_TI_trace(_changed) - calculates model evidence estimate 
% from multiple chains using thermodynamic integration
%
%---------------------------------------------------------------------------------------------
% INPUT:
%       listLogLik - Nx(M+1) vector where column 1 is the log likelihood
%       for a particular chain, and iteration M and column (M+1) is the temperature
%       of that chain. (N is the number of chains with temperatures ranging
%       from 0 to 1).
%       startPoint - minimum spacing for the chains (usually 10)
%
% Optional:
%
%--------------------------------------------------------------------------------------------
% OUTPUT:
%           logEvidence list - list of log evidence approximations based on
%           taking different number of chains. The list is to see how the
%           value converges. The last value of the list will be the best
%           approximation since it will consider all the chains.
% -------------------------------------------------------------------------------------------
% REFERENCE:
%
% Author:   Sudhir Shankar Raman, TNU, UZH & ETHZ - 2014
% Note:     This version was slightly adapted by Vasco A. Concei��o - 2016
%
% This file is part of TAPAS, which is released under the terms of the GNU General Public
% Licence (GPL), version 3. For further details, see <http://www.gnu.org/licenses/>.

%%

function [listModelEvidence] = model_evidence_TI_trace_changed(listLogLik,startPoint)

nChains = size(listLogLik,1);
if(~exist('startPoint','var'))
    startPoint = min(2,nChains);
else
    startPoint = min(startPoint,nChains);
end

maxIterations = size(listLogLik,2)-1;
iterations_v = round(maxIterations ./ [4 3 2 1]);

listModelEvidence = zeros(nChains-startPoint+1,numel(iterations_v)+1);
listModelEvidence(1,2:end) = iterations_v;

for i0 = 1:numel(iterations_v)
    
    iterIndex = 1:iterations_v(i0);
    listLogLikTemp = [mean(listLogLik(:,iterIndex),2),listLogLik(:,end)];
    
    listLogLikTemp = sortrows(listLogLikTemp,2);
    
    for i = startPoint:nChains
        
        tempIndex = round(linspace(1,nChains,i));
        chainResults = listLogLikTemp(tempIndex,:);
        [nChains1 nVariables] = size(chainResults);
        logModelEvidence = 0;
        
        % numerical integration using the Trapezoid rule.
        for iChain1 = 1:(nChains1 - 1)
            logModelEvidence = logModelEvidence + 0.5*(chainResults(iChain1+1,2) - chainResults(iChain1,2))...
                *(chainResults(iChain1+1,1) + chainResults(iChain1,1));
        end
        
        listModelEvidence(i-startPoint+2,1) = i;
        listModelEvidence(i-startPoint+2,1+i0) = logModelEvidence;
        
    end 
end