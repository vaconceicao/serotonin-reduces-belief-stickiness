function [ptheta] = shellmdl_get_param_bounds(modelInfo)
% Auxiliary function called in shellmdl_subj_invert_model. It receives as 
% input a struct with information about the model settings (modelInfo) and 
% it returns a struct ptheta, which will contain information about the 
% priors, indicating the lower and upper bounds of the free parameters 
% (before transformation). 
%
% Input
%   modelInfo       Struct with information about the model
%
% Output
%   ptheta          Struct with information about the priors
%
% Detailed description is lacking.
%
% References are lacking.
%
% Copyright info is lacking.
%
% Last modified: August 20th, 2019

priorDist = modelInfo.rl.priorDistTypes;

lowerBounds = -Inf * ones(modelInfo.rl.nParams,1);
upperBounds =  Inf * ones(modelInfo.rl.nParams,1);

for p = 1:modelInfo.rl.nParams
    switch priorDist(p,1)
        case 1 % Beta distribution
            lowerBounds(p) = 0;
            upperBounds(p) = 1;
        case 2 % Gamma distribution
            lowerBounds(p) = 0;
            % upperBounds(p) = Inf;
        case 3 % Uniform distribution
            lowerBounds(p) = priorDist(p,2);
            upperBounds(p) = priorDist(p,3);
        otherwise
            error('Prior distribution was misspecified.');
    end;
end;

ptheta.lowerBounds = lowerBounds;
ptheta.upperBounds = upperBounds;
end