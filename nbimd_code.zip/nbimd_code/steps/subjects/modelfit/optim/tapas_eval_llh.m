function llk = tapas_eval_llh(params, stimSeq, actSeq, reinfSeq, nStims, ...
    nActions, nReinfs, nTrials, nHS, modelFamilyNumber, modelNumber)
% Auxiliary function called by tapas_llh. It obtains the log-likelihood
% value of interest, by fitting the data using the appropriate 
% reinforcement-learning (RL) model.
%
% Input
%
% Output
%
% Detailed description is lacking.
%
% References are lacking.
%
% Copyright info is lacking, but all TAPAS functions were originally 
% developed by TAPAS creators, and adapted, for this project, by Vasco A.
% Concei��o, sometimes with the help from Sudhir Raman.
%
% Last modified: August 2023

switch modelFamilyNumber
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    case 1 % S-R
        if modelNumber == 1     % 2 params: alpha, beta
            llk = eval_llh_SR1(params, stimSeq, actSeq, reinfSeq, nStims, nActions, nTrials);
        elseif modelNumber == 2 % 3 params: alpha_plus, alpha_minus, beta
            llk = eval_llh_SR2(params, stimSeq, actSeq, reinfSeq, nStims, nActions, nTrials);
        elseif modelNumber == 3 % 3 params: alpha, beta_plus, beta_minus
            llk = eval_llh_SR3(params, stimSeq, actSeq, reinfSeq, nStims, nActions, nTrials);
        elseif modelNumber == 4 % 4 params: alpha_plus, alpha_minus, beta_plus, beta_minus
            llk = eval_llh_SR4(params, stimSeq, actSeq, reinfSeq, nStims, nActions, nTrials);
        
        elseif modelNumber == 5 % 3 params: alpha, beta, go_bias
            llk = eval_llh_SR5(params, stimSeq, actSeq, reinfSeq, nStims, nActions, nTrials);
        elseif modelNumber == 6 % 4 params: alpha_plus, alpha_minus, beta, go_bias
            llk = eval_llh_SR6(params, stimSeq, actSeq, reinfSeq, nStims, nActions, nTrials);
        elseif modelNumber == 7 % 4 params: alpha, beta_plus, beta_minus, go_bias
            llk = eval_llh_SR7(params, stimSeq, actSeq, reinfSeq, nStims, nActions, nTrials);
        elseif modelNumber == 8 % 5 params: alpha_plus, alpha_minus, beta_plus, beta_minus, go_bias
            llk = eval_llh_SR8(params, stimSeq, actSeq, reinfSeq, nStims, nActions, nTrials);
        
        else
            error('Not implemented yet.');
        end;
        
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    case 2 % S-S-R
        if modelNumber == 1     % 4 params: alpha, beta, gamma, zeta
            llk = eval_llh_SSR1(params, stimSeq, actSeq, reinfSeq, nStims, nActions, nReinfs, nTrials, nHS);
        elseif modelNumber == 2 % 5 params: alpha_plus, alpha_minus, beta, gamma, zeta
            llk = eval_llh_SSR2(params, stimSeq, actSeq, reinfSeq, nStims, nActions, nReinfs, nTrials, nHS);
        elseif modelNumber == 3 % 5 params: alpha, beta_plus, beta_minus, gamma, zeta
            llk = eval_llh_SSR3(params, stimSeq, actSeq, reinfSeq, nStims, nActions, nReinfs, nTrials, nHS);
        elseif modelNumber == 4 % 6 params: alpha_plus, alpha_minus, beta_plus, beta_minus, gamma, zeta
            llk = eval_llh_SSR4(params, stimSeq, actSeq, reinfSeq, nStims, nActions, nReinfs, nTrials, nHS);
        
        elseif modelNumber == 5 % 5 params: alpha, beta, go_bias, gamma, zeta
            llk = eval_llh_SSR5(params, stimSeq, actSeq, reinfSeq, nStims, nActions, nReinfs, nTrials, nHS);
        elseif modelNumber == 6 % 6 params: alpha_plus, alpha_minus, beta, go_bias, gamma, zeta
            llk = eval_llh_SSR6(params, stimSeq, actSeq, reinfSeq, nStims, nActions, nReinfs, nTrials, nHS);
        elseif modelNumber == 7 % 6 params: alpha, beta_plus, beta_minus, go_bias, gamma, zeta
            llk = eval_llh_SSR7(params, stimSeq, actSeq, reinfSeq, nStims, nActions, nReinfs, nTrials, nHS);
        elseif modelNumber == 8 % 7 params: alpha_plus, alpha_minus, beta_plus, beta_minus, go_bias, gamma, zeta
            llk = eval_llh_SSR8(params, stimSeq, actSeq, reinfSeq, nStims, nActions, nReinfs, nTrials, nHS);
        
        else
            error('Not implemented yet.');
        end;
        
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    case 3 % S-R_{alpha(T)}
        if modelNumber == 1     % 3 params: alpha, beta, alpha_max
            llk = eval_llh_SRalphavar1(params, stimSeq, actSeq, reinfSeq, nStims, nActions, nTrials);
        elseif modelNumber == 2 % 5 params: alpha_plus, alpha_minus, beta, alpha_plus_max, alpha_minus_max
            llk = eval_llh_SRalphavar2(params, stimSeq, actSeq, reinfSeq, nStims, nActions, nTrials);
        elseif modelNumber == 3 % 4 params: alpha, beta_plus, beta_minus, alpha_max
            llk = eval_llh_SRalphavar3(params, stimSeq, actSeq, reinfSeq, nStims, nActions, nTrials);
        elseif modelNumber == 4 % 6 params: alpha_plus, alpha_minus, beta_plus, beta_minus, alpha_plus_max, alpha_minus_max
            llk = eval_llh_SRalphavar4(params, stimSeq, actSeq, reinfSeq, nStims, nActions, nTrials);
        
        elseif modelNumber == 5 % 4 params: alpha, beta, go_bias, alpha_max
            llk = eval_llh_SRalphavar5(params, stimSeq, actSeq, reinfSeq, nStims, nActions, nTrials);
        elseif modelNumber == 6 % 6 params: alpha_plus, alpha_minus, beta, go_bias, alpha_plus_max, alpha_minus_max
            llk = eval_llh_SRalphavar6(params, stimSeq, actSeq, reinfSeq, nStims, nActions, nTrials);
        elseif modelNumber == 7 % 5 params: alpha, beta_plus, beta_minus, go_bias, alpha_max
            llk = eval_llh_SRalphavar7(params, stimSeq, actSeq, reinfSeq, nStims, nActions, nTrials);
        elseif modelNumber == 8 % 7 params: alpha_plus, alpha_minus, beta_plus, beta_minus, go_bias
            llk = eval_llh_SRalphavar8(params, stimSeq, actSeq, reinfSeq, nStims, nActions, nTrials);
        
        else
            error('Not implemented yet.');
        end;
        
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    case 4 % S-R_{StimStick}
        if modelNumber == 1     % 4 params: alpha, beta, alpha_stim_stick, stim_stick_bias
            llk = eval_llh_SRstimstick1(params, stimSeq, actSeq, reinfSeq, nStims, nActions, nTrials);
        elseif modelNumber == 2 % 5 params: alpha_plus, alpha_minus, beta, alpha_stim_stick, stim_stick_bias
            llk = eval_llh_SRstimstick2(params, stimSeq, actSeq, reinfSeq, nStims, nActions, nTrials);
        elseif modelNumber == 3 % 5 params: alpha, beta_plus, beta_minus, alpha_stim_stick, stim_stick_bias
            llk = eval_llh_SRstimstick3(params, stimSeq, actSeq, reinfSeq, nStims, nActions, nTrials);
        elseif modelNumber == 4 % 6 params: alpha_plus, alpha_minus, beta_plus, beta_minus, alpha_stim_stick, stim_stick_bias
            llk = eval_llh_SRstimstick4(params, stimSeq, actSeq, reinfSeq, nStims, nActions, nTrials);
        
        elseif modelNumber == 5 % 5 params: alpha, beta, go_bias, alpha_stim_stick, stim_stick_bias
            llk = eval_llh_SRstimstick5(params, stimSeq, actSeq, reinfSeq, nStims, nActions, nTrials);
        elseif modelNumber == 6 % 6 params: alpha_plus, alpha_minus, beta, go_bias, alpha_stim_stick, stim_stick_bias
            llk = eval_llh_SRstimstick6(params, stimSeq, actSeq, reinfSeq, nStims, nActions, nTrials);
        elseif modelNumber == 7 % 6 params: alpha, beta_plus, beta_minus, go_bias, alpha_stim_stick, stim_stick_bias
            llk = eval_llh_SRstimstick7(params, stimSeq, actSeq, reinfSeq, nStims, nActions, nTrials);
        elseif modelNumber == 8 % 7 params: alpha_plus, alpha_minus, beta_plus, beta_minus, go_bias, alpha_stim_stick, stim_stick_bias
            llk = eval_llh_SRstimstick8(params, stimSeq, actSeq, reinfSeq, nStims, nActions, nTrials);
        
        else
            error('Not implemented yet.');
        end;
        
    otherwise % wrong family number
        error('Not implemented yet.');
end;
end