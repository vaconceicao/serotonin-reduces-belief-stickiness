/*
 * ------------------------------------------------------------------------
 * eval_llh_SR4_debug - (debugs the) log-likelihood calculation for the
 * (alpha_plus, alpha_minus, beta_plus, beta_minus)-model of the the S-R 
 * family [model S-R-4; Q-learning (QL) model with both positive and 
 * negative learning rates and positive and negative inverse temperatures]
 *
 * ------------------------------------------------------------------------
 * INPUT:
 *      free parameters:
 *          alpha_plus - positive learning rate
 *          alpha_minus - negative learning rate
 *          beta_plus - positive inverse temperature
 *          beta_minus - negative inverse temperature
 *      stim_seq - stimuli sequence
 *      act_seq - action sequence
 *      reinf_seq - reinforcement sequence
 *      nStims - number of stimuli
 *      nActions - number of actions (Go and NoGo, in this case)
 *      nTrials - number of trials
 *
 * Optional:
 *
 *-------------------------------------------------------------------------
 * OUTPUT:
 *      prob_v          - probabilities of doing the first action (Go) on each trial   
 *      currHS_v        - not informative for QL models; related to hidden states
 *      beliefs_m       - not informative for QL models; related to hidden states
 *      normBeliefs_m   - not informative for QL models; related to hidden states
 *      Q_m             - Q-values for each action on each trial
 *
 *-------------------------------------------------------------------------
 * REFERENCE:
 *
 * Author: Vasco A. Concei��o
 *
 */
#include<stdio.h>
#include<math.h>
#include "mex.h"

void mexFunction(int nlhs, mxArray *plhs[], /* Output variables */
        int nrhs, const mxArray *prhs[]) /* Input variables */
{
    /* Extract input information */
    double *params = mxGetPr(prhs[0]);
    double alpha_plus = params[0];
    double alpha_minus = params[1];
    double beta_plus = params[2];
    double beta_minus = params[3];
    
    double *stim_seq = mxGetPr(prhs[1]);
    double *act_seq  = mxGetPr(prhs[2]);
    double *reinf_seq = mxGetPr(prhs[3]);
    
    int nStims = mxGetScalar(prhs[4]);
    int nActions = mxGetScalar(prhs[5]);
    int nTrials = mxGetScalar(prhs[6]);
    
    /* Initialization */
    int stim = 0;
    int t = 0;
    double delta, beta_eff = 0;
    double prob = 0, llk = 0;
    
    int nHS = 3; /* not informative for QL models */
    
    /* Output variables: */
    double *prob_v; /* probabilities of doing the first action (Go) on each trial */
    double *currHS_v; /* not informative for QL models */
    double *beliefs_m; /* not informative for QL models */
    double *normBeliefs_m; /* not informative for QL models */
    double *Q_m; /* Q-values for each action on each trial */
    
    int i, j;
    double **Q = (double **) malloc(nStims * sizeof(double*));
    for (i = 0; i < nStims; i++)
    {
        Q[i] = (double *) malloc(nActions * sizeof(double));
    }
    for(i = 0; i < nStims; i++)
    {
        for(j = 0; j < nActions; j++)
        {
            Q[i][j] = 0;
        }
    }
    
    /* Output variables: */
    plhs[0] = mxCreateDoubleMatrix(nTrials, 1, mxREAL);
    plhs[1] = mxCreateDoubleMatrix(nTrials, 1, mxREAL);
    plhs[2] = mxCreateDoubleMatrix(nTrials, nHS, mxREAL);
    plhs[3] = mxCreateDoubleMatrix(nTrials, nHS, mxREAL);
    plhs[4] = mxCreateDoubleMatrix(nTrials, nActions, mxREAL);
    
    prob_v = mxGetPr(plhs[0]);
    currHS_v = mxGetPr(plhs[1]); /* not informative for QL models */
    beliefs_m = mxGetPr(plhs[2]); /* not informative for QL models */
    normBeliefs_m = mxGetPr(plhs[3]); /* not informative for QL models */
    Q_m = mxGetPr(plhs[4]);
    
    /* Trial-by-trial update */
    for(t; t < nTrials; t++)
    {
        stim = stim_seq[t] - 1;
        
        /* Update log likelihood */
        if(Q[stim][0] > 0)
        {
            beta_eff = beta_plus;
        }
        else
        {
            beta_eff = beta_minus;
        }
        
        prob = 1.0 / (1.0 + exp(-beta_eff * (Q[stim][0])));
        
        if(act_seq[t] == 1)
        {
            llk = llk + log(prob);
        }
        else
        {
            llk = llk + log(1 - prob);
        }
        
        /* Update Q-values for next trial */
        if(act_seq[t] == 1) /* only Go can yield reinforcements */
        {
            delta = (reinf_seq[t] - Q[stim][0]);
            if (delta > 0)
            {
                Q[stim][0] = Q[stim][0] + alpha_plus * delta;
            }
            else
            {
                Q[stim][0] = Q[stim][0] + alpha_minus * delta;
            }
        }
    }
    
    for (i = 0; i < nStims; i++)
    {
        free(Q[i]);
    }
    free(Q);
    
    return;
}