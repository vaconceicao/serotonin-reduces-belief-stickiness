/*
 * ------------------------------------------------------------------------
 * eval_llh_SR5_simul - simulates behavior using the 
 * (alpha, beta, go_bias)-model of the S-R family [model S-R-5; simple 
 * Q-learning (QL) model with a go bias]
 *
 * ------------------------------------------------------------------------
 * INPUT:
 *      free parameters:
 *          alpha - single learning rate
 *          beta - single inverse temperature
 *          go_bias - go bias
 *      stim_seq - stimuli sequence
 *      act_rdm_seq - sequence of random numbers (probabilities) that will be used to generate the action sequence
 *      reinf_if_go_seq - reinforcement sequence (if go; always 0, if nogo)
 *      nStims - number of stimuli
 *      nActions - number of actions (Go and NoGo, in this case)
 *      nTrials - number of trials
 *
 * Optional:
 *
 *-------------------------------------------------------------------------
 * OUTPUT:
 *      act_v           - sequence of the actions done on each trial
 *      prob_v          - probabilities of doing the first action (Go) on each trial   
 *      currHS_v        - not informative for QL models; related to hidden states
 *      beliefs_m       - not informative for QL models; related to hidden states
 *      normBeliefs_m   - not informative for QL models; related to hidden states
 *      Q_m             - Q-values for each action on each trial
 *
 *-------------------------------------------------------------------------
 * REFERENCE:
 *
 * Author: Vasco A. Concei��o
 *
 */
#include<stdio.h>
#include<math.h>
#include "mex.h"

void mexFunction(int nlhs, mxArray *plhs[], /* Output variables */
        int nrhs, const mxArray *prhs[]) /* Input variables */
{
    /* Extract input information */
    double *params = mxGetPr(prhs[0]);
    double alpha = params[0];
    double beta = params[1];
    double go_bias = params[2];
    
    double *stim_seq = mxGetPr(prhs[1]);
    double *act_rdm_seq = mxGetPr(prhs[2]);
    double *reinf_if_go_seq = mxGetPr(prhs[3]);
    
    int nStims = mxGetScalar(prhs[4]);
    int nActions = mxGetScalar(prhs[5]);
    int nTrials = mxGetScalar(prhs[6]);
    
    /* Initialization */
    int stim = 0;
    int t = 0;
    double prob = 0;
    
    int nHS = 3; /* not informative for QL models */
    
    /* Output variables: */
    double *act_v;
    double *prob_v; /* probabilities of doing the first action (Go) on each trial */
    double *currHS_v; /* not informative for QL models */
    double *beliefs_m; /* not informative for QL models */
    double *normBeliefs_m; /* not informative for QL models */
    double *Q_m; /* Q-values for each action on each trial */
    
    int i, j;
    double **Q = (double **) malloc(nStims * sizeof(double*));
    for (i = 0; i < nStims; i++)
    {
        Q[i] = (double *) malloc(nActions * sizeof(double));
    }
    for(i = 0; i < nStims; i++)
    {
        for(j = 0; j < nActions; j++)
        {
            Q[i][j] = 0;
        }
    }
    
    /* Output variables: */
    plhs[0] = mxCreateDoubleMatrix(nTrials, 1, mxREAL);
    plhs[1] = mxCreateDoubleMatrix(nTrials, 1, mxREAL);
    plhs[2] = mxCreateDoubleMatrix(nTrials, 1, mxREAL);
    plhs[3] = mxCreateDoubleMatrix(nTrials, nHS, mxREAL);
    plhs[4] = mxCreateDoubleMatrix(nTrials, nHS, mxREAL);
    plhs[5] = mxCreateDoubleMatrix(nTrials, nActions, mxREAL);
    
    act_v = mxGetPr(plhs[0]);
    prob_v = mxGetPr(plhs[1]);
    currHS_v = mxGetPr(plhs[2]); /* not informative for QL models */
    beliefs_m = mxGetPr(plhs[3]); /* not informative for QL models */
    normBeliefs_m = mxGetPr(plhs[4]); /* not informative for QL models */
    Q_m = mxGetPr(plhs[5]);
    
    /* Trial-by-trial update */
    for(t; t < nTrials; t++)
    {
        stim = stim_seq[t] - 1;
        
        /* Select an action */
        prob = 1.0 / (1.0 + exp(-beta * (Q[stim][0] + go_bias)));
        
        if(prob > act_rdm_seq[t])
        {
            act_v[t] = 1;
        }
        else
        {
            act_v[t] = 2;
        }
        
        /* Update Q-values for next trial */
        if(act_v[t] == 1) /* only Go can yield reinforcements */
        {
            Q[stim][0] = Q[stim][0] + alpha * (reinf_if_go_seq[t] - Q[stim][0]);
        }
        
        /* Store info in output variables */
        prob_v[t] = prob;
        currHS_v[t] = 0;
        for (i = 0; i < nHS; i++)
        {
            beliefs_m[nTrials * i + t] = 0;
            normBeliefs_m[nTrials * i + t] = 0;
        }
        for (i = 0; i < nActions; i++)
        {
            Q_m[nTrials * i + t] = Q[stim][i];
        }
    }
    
    for (i = 0; i < nStims; i++)
    {
        free(Q[i]);
    }
    free(Q);
    
    return;
}