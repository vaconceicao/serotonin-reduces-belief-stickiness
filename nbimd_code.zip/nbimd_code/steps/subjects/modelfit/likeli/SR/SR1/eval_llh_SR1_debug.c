/*
 * ------------------------------------------------------------------------
 * eval_llh_SR1_debug - (debugs the) log-likelihood calculation for the 
 * (alpha, beta)-model of the S-R family [model S-R-1; simple Q-learning 
 * (QL) model]
 *
 * ------------------------------------------------------------------------
 * INPUT:
 *      free parameters:
 *          alpha - single learning rate
 *          beta - single inverse temperature
 *      stim_seq - stimuli sequence
 *      act_seq - action sequence
 *      reinf_seq - reinforcement sequence
 *      nStims - number of stimuli
 *      nActions - number of actions (Go and NoGo, in this case)
 *      nTrials - number of trials
 *
 * Optional:
 *
 *-------------------------------------------------------------------------
 * OUTPUT:
 *      prob_v          - probabilities of doing the first action (Go) on each trial   
 *      currHS_v        - not informative for QL models; related to hidden states
 *      beliefs_m       - not informative for QL models; related to hidden states
 *      normBeliefs_m   - not informative for QL models; related to hidden states
 *      Q_m             - Q-values for each action on each trial
 *
 *-------------------------------------------------------------------------
 * REFERENCE:
 *
 * Author: Vasco A. Concei��o
 *
 */
#include<stdio.h>
#include<math.h>
#include "mex.h"

void mexFunction(int nlhs, mxArray *plhs[], /* Output variables */
        int nrhs, const mxArray *prhs[]) /* Input variables */
{
    /* Extract input information */
    double *params = mxGetPr(prhs[0]);
    double alpha = params[0];
    double beta = params[1];
    
    double *stim_seq = mxGetPr(prhs[1]);
    double *act_seq  = mxGetPr(prhs[2]);
    double *reinf_seq = mxGetPr(prhs[3]);
    
    int nStims = mxGetScalar(prhs[4]);
    int nActions = mxGetScalar(prhs[5]);
    int nTrials = mxGetScalar(prhs[6]);
    
    /* Initialization */
    int stim = 0;
    int t = 0;
    double prob = 0, llk = 0;
    
    int nHS = 3; /* not informative for QL models */
    
    /* Output variables: */
    double *prob_v; /* probabilities of doing the first action (Go) on each trial */
    double *currHS_v; /* not informative for QL models */
    double *beliefs_m; /* not informative for QL models */
    double *normBeliefs_m; /* not informative for QL models */
    double *Q_m; /* Q-values for each action on each trial */
    
    int i, j;
    double **Q = (double **) malloc(nStims * sizeof(double*));
    for (i = 0; i < nStims; i++)
    {
        Q[i] = (double *) malloc(nActions * sizeof(double));
    }
    for(i = 0; i < nStims; i++)
    {
        for(j = 0; j < nActions; j++)
        {
            Q[i][j] = 0;
        }
    }
    
    /* Output variables: */
    plhs[0] = mxCreateDoubleMatrix(nTrials, 1, mxREAL);
    plhs[1] = mxCreateDoubleMatrix(nTrials, 1, mxREAL);
    plhs[2] = mxCreateDoubleMatrix(nTrials, nHS, mxREAL);
    plhs[3] = mxCreateDoubleMatrix(nTrials, nHS, mxREAL);
    plhs[4] = mxCreateDoubleMatrix(nTrials, nActions, mxREAL);
    
    prob_v = mxGetPr(plhs[0]);
    currHS_v = mxGetPr(plhs[1]); /* not informative for QL models */
    beliefs_m = mxGetPr(plhs[2]); /* not informative for QL models */
    normBeliefs_m = mxGetPr(plhs[3]); /* not informative for QL models */
    Q_m = mxGetPr(plhs[4]);
    
    /* Trial-by-trial update */
    for(t; t < nTrials; t++)
    {
        stim = stim_seq[t] - 1;
        
        /* Update log likelihood */
        prob = 1.0 / (1.0 + exp(-beta * Q[stim][0]));
        
        if(act_seq[t] == 1)
        {
            llk = llk + log(prob);
        }
        else
        {
            llk = llk + log(1 - prob);
        }
        
        /* Update Q-values for next trial */
        if(act_seq[t] == 1) /* only Go can yield reinforcements */
        {
            Q[stim][0] = Q[stim][0] + alpha * (reinf_seq[t] - Q[stim][0]);
        }
        
        /* Store info in output variables */
        prob_v[t] = prob;
        currHS_v[t] = 0;
        for (i = 0; i < nHS; i++)
        {
            beliefs_m[nTrials * i + t] = 0;
            normBeliefs_m[nTrials * i + t] = 0;
        }
        for (i = 0; i < nActions; i++)
        {
            Q_m[nTrials * i + t] = Q[stim][i];
        }
    }
    
    for (i = 0; i < nStims; i++)
    {
        free(Q[i]);
    }
    free(Q);
    
    return;
}