/*
 * ------------------------------------------------------------------------
 * eval_llh_SRalphavar4 - log-likelihood calculation for the 
 * (alpha_plus, alpha_minus, beta_plus, beta_minus, alpha_plus_max, 
 * alpha_minus_max)-model of the S-R_{alpha(T)} family [model 
 * S-R-alphavar-4; Q-learning (QL) model with positive and 
 * negative learning rates, which vary as a function of the trial number, 
 * and positive and negative inverse temperatures]
 *
 * ------------------------------------------------------------------------
 * INPUT:
 *      free parameters:
 *          alpha_plus - positive learning rate (at the beginning of the task)
 *          alpha_minus - negative learning rate (at the beginning of the task)
 *          beta_plus - positive inverse temperature
 *          beta_minus - negative inverse temperature
 *          alpha_plus_max - positive learning rate at the end of the task
 *          alpha_minus_max - negative learning rate at the end of the task
 *      stim_seq - stimuli sequence
 *      act_seq - action sequence
 *      reinf_seq - reinforcement sequence
 *      nStims - number of stimuli
 *      nActions - number of actions (Go and NoGo, in this case)
 *      nTrials - number of trials
 *
 * Optional:
 *
 *-------------------------------------------------------------------------
 * OUTPUT:
 *      llk - log likelihood
 *
 *-------------------------------------------------------------------------
 * REFERENCE:
 *
 * Author: Vasco A. Concei��o
 *
 */
#include<stdio.h>
#include<math.h>
#include "mex.h"

void mexFunction(int nlhs, mxArray *plhs[], /* Output variables */
        int nrhs, const mxArray *prhs[]) /* Input variables */
{
    /* Extract input information */
    double *params = mxGetPr(prhs[0]);
    double alpha_plus = params[0];
    double alpha_minus = params[1];
    double beta_plus = params[2];
    double beta_minus = params[3];
    double alpha_plus_max = params[4];
    double alpha_minus_max = params[5];
    
    double *stim_seq = mxGetPr(prhs[1]);
    double *act_seq  = mxGetPr(prhs[2]);
    double *reinf_seq = mxGetPr(prhs[3]);
    
    int nStims = mxGetScalar(prhs[4]);
    int nActions = mxGetScalar(prhs[5]);
    int nTrials = mxGetScalar(prhs[6]);
    
    /* Initialization */
    int stim = 0;
    int t = 0;
    double delta, alpha_eff, beta_eff = 0;
    double prob = 0;
    double *llk;
    
    int i, j;
    double **Q = (double **) malloc(nStims * sizeof(double*));
    for (i = 0; i < nStims; i++)
    {
        Q[i] = (double *) malloc(nActions * sizeof(double));
    }
    for(i = 0; i < nStims; i++)
    {
        for(j = 0; j < nActions; j++)
        {
            Q[i][j] = 0;
        }
    }
    
    plhs[0] = mxCreateDoubleMatrix(1, 1, mxREAL);
    llk = mxGetPr(plhs[0]);
    llk[0] = 0;
    
    /* Trial-by-trial update */
    for(t; t < nTrials; t++)
    {
        stim = stim_seq[t] - 1;
        
        /* Update log likelihood */
        if(Q[stim][0] > 0)
        {
            beta_eff = beta_plus;
        }
        else
        {
            beta_eff = beta_minus;
        }
        
        prob = 1.0 / (1.0 + exp(-beta_eff * (Q[stim][0])));
        
        if(act_seq[t] == 1)
        {
            llk[0] = llk[0] + log(prob);
        }
        else
        {
            llk[0] = llk[0] + log(1 - prob);
        }
        
        /* Update Q-values for next trial */
        if(act_seq[t] == 1) /* only Go can yield reinforcements */
        {
            delta = (reinf_seq[t] - Q[stim][0]);
            if (delta > 0)
            {
                alpha_eff = alpha_plus + (alpha_plus_max - alpha_plus) * t / (nTrials - 1);
            }
            else
            {
                alpha_eff = alpha_minus + (alpha_minus_max - alpha_minus) * t / (nTrials - 1);
            }
            Q[stim][0] = Q[stim][0] + alpha_eff * delta;
        }
    }
    
    for (i = 0; i < nStims; i++)
    {
        free(Q[i]);
    }
    free(Q);
    
    return;
}