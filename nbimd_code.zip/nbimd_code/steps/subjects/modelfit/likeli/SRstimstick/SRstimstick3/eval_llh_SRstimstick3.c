/*
 * ------------------------------------------------------------------------
 * eval_llh_SRstimstick3 - log-likelihood calculation for the
 * (alpha, beta_plus, beta_minus, alpha_stim_stick, stim_stick_bias)-model
 * of the S-R_{StimStick} family [model S-R-stimstick-3; Q-learning (QL)
 * model with a positive and a negative inverse temperature accounting for
 * stimulus stickiness]
 *
 * ------------------------------------------------------------------------
 * INPUT:
 *      free parameters:
 *          alpha - single learning rate
 *          beta_plus - positive inverse temperature
 *          beta_minus - negative inverse temperature
 *          alpha_stim_stick - stimulus-stickiness learning rate
 *          stim_stick_bias - stimulus-stickiness bias
 *      stim_seq - stimuli sequence
 *      act_seq - action sequence
 *      reinf_seq - reinforcement sequence
 *      nStims - number of stimuli
 *      nActions - number of actions (Go and NoGo, in this case)
 *      nTrials - number of trials
 *
 * Optional:
 *
 *-------------------------------------------------------------------------
 * OUTPUT:
 *      llk - log likelihood
 *
 *-------------------------------------------------------------------------
 * REFERENCE:
 *
 * Author: Vasco A. Concei��o
 *
 */
#include<stdio.h>
#include<math.h>
#include "mex.h"

void mexFunction(int nlhs, mxArray *plhs[], /* Output variables */
        int nrhs, const mxArray *prhs[]) /* Input variables */
{
    /* Extract input information */
    double *params = mxGetPr(prhs[0]);
    double alpha = params[0];
    double beta_plus = params[1];
    double beta_minus = params[2];
    double alpha_stim_stick = params[3];
    double stim_stick_bias = params[4];
    
    double *stim_seq = mxGetPr(prhs[1]);
    double *act_seq  = mxGetPr(prhs[2]);
    double *reinf_seq = mxGetPr(prhs[3]);
    
    int nStims = mxGetScalar(prhs[4]);
    int nActions = mxGetScalar(prhs[5]);
    int nTrials = mxGetScalar(prhs[6]);
    
    /* Initialization */
    int stim = 0;
    int t = 0;
    double delta, beta_eff, eff_stim_stick_bias = 0;
    double prob = 0;
    double *llk;
    
    int i, j;
    double *prev_action = (double *) malloc(nStims * sizeof(double));
    double *stim_stick_bias_value = (double *) malloc(nStims * sizeof(double));
    double **Q = (double **) malloc(nStims * sizeof(double*));
    for (i = 0; i < nStims; i++)
    {
        Q[i] = (double *) malloc(nActions * sizeof(double));
        prev_action[i] = nActions + 1; /* actions will be 1 or 2; this is initialized at 3 to make the action-repetition bias = 0, before a stimulus is shown for the second time */
        stim_stick_bias_value[i] = 0;
    }
    for(i = 0; i < nStims; i++)
    {
        for(j = 0; j < nActions; j++)
        {
            Q[i][j] = 0;
        }
    }
    
    plhs[0] = mxCreateDoubleMatrix(1, 1, mxREAL);
    llk = mxGetPr(plhs[0]);
    llk[0] = 0;
    
    /* Trial-by-trial update */
    for(t; t < nTrials; t++)
    {
        stim = stim_seq[t] - 1;
        
        /* Update log likelihood */
        if(Q[stim][0] > 0)
        {
            beta_eff = beta_plus;
        }
        else
        {
            beta_eff = beta_minus;
        }
        
        eff_stim_stick_bias = stim_stick_bias_value[stim];
        
        prob = 1.0 / (1.0 + exp(-beta_eff * (Q[stim][0] + eff_stim_stick_bias)));
        
        if(act_seq[t] == 1)
        {
            llk[0] = llk[0] + log(prob);
        }
        else
        {
            llk[0] = llk[0] + log(1 - prob);
        }
        
        prev_action[stim] = act_seq[t];
        
        /* Update Q-values for next trial */
        if(act_seq[t] ==1)
        {
            delta = (reinf_seq[t] - Q[stim][0]);
            Q[stim][0] = Q[stim][0] + alpha * delta;
            stim_stick_bias_value[stim] = stim_stick_bias_value[stim] + alpha_stim_stick * (stim_stick_bias - stim_stick_bias_value[stim]);
        }
        else
        {
            stim_stick_bias_value[stim] = stim_stick_bias_value[stim] + alpha_stim_stick * (0 - stim_stick_bias_value[stim]);
        }
    }
    
    for (i = 0; i < nStims; i++)
    {
        free(Q[i]);
    }
    free(Q);
    
    free(prev_action);
    free(stim_stick_bias_value);
    
    return;
}