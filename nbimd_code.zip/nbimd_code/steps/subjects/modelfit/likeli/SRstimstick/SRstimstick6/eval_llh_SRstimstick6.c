/*
 * ------------------------------------------------------------------------
 * eval_llh_SRstimstick6 - log-likelihood calculation for the
 * (alpha_plus, alpha_minus, beta, go_bias, alpha_stim_stick, 
 * stim_stick_bias)-model of the S-R_{StimStick} family [model 
 * S-R-stimstick-6; Q-learning (QL) model with a positive and a negative
 * learning rate, a go bias, and accounting for stimulus stickiness]
 *
 * ------------------------------------------------------------------------
 * INPUT:
 *      free parameters:
 *          alpha_plus - positive learning rate
 *          alpha_minus - negative learning rate
 *          beta - single inverse temperature
 *          go_bias - go bias
 *          alpha_stim_stick - stimulus-stickiness learning rate
 *          stim_stick_bias - stimulus-stickiness bias
 *      stim_seq - stimuli sequence
 *      act_seq - action sequence
 *      reinf_seq - reinforcement sequence
 *      nStims - number of stimuli
 *      nActions - number of actions (Go and NoGo, in this case)
 *      nTrials - number of trials
 *
 * Optional:
 *
 *-------------------------------------------------------------------------
 * OUTPUT:
 *      llk - log likelihood
 *
 *-------------------------------------------------------------------------
 * REFERENCE:
 *
 * Author: Vasco A. Concei��o
 *
 */
#include<stdio.h>
#include<math.h>
#include "mex.h"

void mexFunction(int nlhs, mxArray *plhs[], /* Output variables */
        int nrhs, const mxArray *prhs[]) /* Input variables */
{
    /* Extract input information */
    double *params = mxGetPr(prhs[0]);
    double alpha_plus = params[0];
    double alpha_minus = params[1];
    double beta = params[2];
    double go_bias = params[3];
    double alpha_stim_stick = params[4];
    double stim_stick_bias = params[5];
    
    double *stim_seq = mxGetPr(prhs[1]);
    double *act_seq  = mxGetPr(prhs[2]);
    double *reinf_seq = mxGetPr(prhs[3]);
    
    int nStims = mxGetScalar(prhs[4]);
    int nActions = mxGetScalar(prhs[5]);
    int nTrials = mxGetScalar(prhs[6]);
    
    /* Initialization */
    int stim = 0;
    int t = 0;
    double delta, eff_stim_stick_bias = 0;
    double prob = 0;
    double *llk;
    
    int i, j;
    double *prev_action = (double *) malloc(nStims * sizeof(double));
    double *stim_stick_bias_value = (double *) malloc(nStims * sizeof(double));
    double **Q = (double **) malloc(nStims * sizeof(double*));
    for (i = 0; i < nStims; i++)
    {
        Q[i] = (double *) malloc(nActions * sizeof(double));
        prev_action[i] = nActions + 1; /* actions will be 1 or 2; this is initialized at 3 to make the action-repetition bias = 0, before a stimulus is shown for the second time */
        stim_stick_bias_value[i] = 0;
    }
    for(i = 0; i < nStims; i++)
    {
        for(j = 0; j < nActions; j++)
        {
            Q[i][j] = 0;
        }
    }
    
    plhs[0] = mxCreateDoubleMatrix(1, 1, mxREAL);
    llk = mxGetPr(plhs[0]);
    llk[0] = 0;
    
    /* Trial-by-trial update */
    for(t; t < nTrials; t++)
    {
        stim = stim_seq[t] - 1;
        
        /* Update log likelihood */
        eff_stim_stick_bias = stim_stick_bias_value[stim];
        
        prob = 1.0 / (1.0 + exp(-beta*(Q[stim][0] + go_bias + eff_stim_stick_bias)));
        
        if(act_seq[t] == 1)
        {
            llk[0] = llk[0] + log(prob);
        }
        else
        {
            llk[0] = llk[0] + log(1 - prob);
        }
        
        prev_action[stim] = act_seq[t];
        
        /* Update Q-values for next trial */
        if(act_seq[t] == 1)
        {
            delta = (reinf_seq[t] - Q[stim][0]);
            if (delta > 0)
            {
                Q[stim][0] = Q[stim][0] + alpha_plus * delta;
            }
            else
            {
                Q[stim][0] = Q[stim][0] + alpha_minus * delta;
            }
            stim_stick_bias_value[stim] = stim_stick_bias_value[stim] + alpha_stim_stick * (stim_stick_bias - stim_stick_bias_value[stim]);
        }
        else
        {
            stim_stick_bias_value[stim] = stim_stick_bias_value[stim] + alpha_stim_stick * (0 - stim_stick_bias_value[stim]);
        }
    }
    
    for (i = 0; i < nStims; i++)
    {
        free(Q[i]);
    }
    free(Q);
    
    free(prev_action);
    free(stim_stick_bias_value);
    
    return;
}