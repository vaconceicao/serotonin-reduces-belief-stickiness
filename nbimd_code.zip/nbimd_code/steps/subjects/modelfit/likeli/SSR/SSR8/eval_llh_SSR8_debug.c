/*
 * ------------------------------------------------------------------------
 * eval_llh_SSR8_debug - (debugs the) log-likelihood calculation for the 
 * (alpha_plus, alpha_minus, beta_plus, beta_minus, go_bias, gamma, zeta)-
 * model of the SSR family [model S-S-R-8; Q-learning (QL) model with both 
 * positive and negative learning rates and positive and negative inverse 
 * temperatures, and with a go bias, extended with inference about the 
 * (hidden) states of each stimulus]
 *
 * ------------------------------------------------------------------------
 * INPUT:
 *      free parameters:
 *          alpha_plus - positive learning rate
 *          alpha_minus - negative learning rate
 *          beta_plus - positive inverse temperature
 *          beta_minus - negative inverse temperature
 *          go_bias - go bias
 *          gamma - state-stickiness parameter: (over)reliance in the previous beliefs about the (hidden) states
 *          zeta - state-stickiness parameter: additional inertia to (hidden-) state changes
 *      stim_seq - stimuli sequence
 *      act_seq - action sequence
 *      reinf_seq - reinforcement sequence
 *      nStims - number of stimuli
 *      nActions - number of actions (Go and NoGo, in this case)
 *      nReinfs - number of reinforcements
 *      nTrials - number of trials
 *      nHS - (maximum) number of hidden states
 *
 * Optional:
 *
 *-------------------------------------------------------------------------
 * OUTPUT:
 *      prob_v          - probabilities of doing the first action (Go) on each trial   
 *      currHS_v        - current hidden state (for the respective stimulus) on each trial
 *      beliefs_m       - hidden-state beliefs (for the respective stimulus) on each trial
 *      normBeliefs_m   - hidden-state beliefs (for the respective stimulus) on each trial [redundant]
 *      Q_m             - Q-values for each action on each trial
 *
 *-------------------------------------------------------------------------
 * REFERENCE:
 *
 * Author: Vasco A. Concei��o
 *
 */
#include<stdio.h>
#include<math.h>
#include "mex.h"

void mexFunction(int nlhs, mxArray *plhs[],/*Outputvariables*/
        int nrhs, const mxArray *prhs[])
{
    /* Extract input information */
    double *params = mxGetPr(prhs[0]);
    double alpha_plus = params[0];
    double alpha_minus = params[1];
    double beta_plus = params[2];
    double beta_minus = params[3];
    double go_bias = params[4];
    double gamma = params[5];
    double zeta = params[6];
    
    double *stim_seq = mxGetPr(prhs[1]);
    double *act_seq  = mxGetPr(prhs[2]);
    double *reinf_seq = mxGetPr(prhs[3]);
    
    int nStims = mxGetScalar(prhs[4]);
    int nActions = mxGetScalar(prhs[5]);
    int nReinfs = mxGetScalar(prhs[6]);
    int nTrials = mxGetScalar(prhs[7]);
    int nHS = mxGetScalar(prhs[8]);
    
    int t, stim, reinf_type;
    
    double **beliefs = (double **) malloc(nStims * sizeof(double*));
    double beliefs_denom, beliefs_aux, aux;
    double ***counts = (double ***) malloc(nStims * sizeof(double**));
    
    int *currHS = (int *) malloc(nStims * sizeof(int));
    double *state_stick = (double *) malloc(nHS * sizeof(double));
    
    double beta_eff, prob, delta, llk = 0;
    
    /* Output variables: */
    double *prob_v;
    double *currHS_v;
    double *beliefs_m;
    double *normBeliefs_m;
    double *Q_m;
    
    int i, j, k;
    
    double ***Q = (double ***) malloc(nStims * sizeof(double**));
    for (i = 0; i < nStims; i++)
    {
        Q[i] = (double **) malloc(nHS * sizeof(double*));
        counts[i] = (double **) malloc(nHS * sizeof(double*));
        beliefs[i] = (double *) malloc(nHS * sizeof(double));
        for(j = 0; j < nHS; j++)
        {
            Q[i][j] = (double *) malloc(nActions * sizeof(double));
            counts[i][j] = (double *) malloc(nReinfs * sizeof(double));
            beliefs[i][j] = 1.0 / nHS;
            for(k = 0; k < nActions; k++)
            {
                Q[i][j][k] = 0;
            }
            for(k = 0; k < nReinfs; k++)
            {
                counts[i][j][k] = 1.0;
            }
        }
        currHS[i] = 0;
    }
    
    /* Output variables: */
    plhs[0] = mxCreateDoubleMatrix(nTrials, 1, mxREAL);
    plhs[1] = mxCreateDoubleMatrix(nTrials, 1, mxREAL);
    plhs[2] = mxCreateDoubleMatrix(nTrials, nHS, mxREAL);
    plhs[3] = mxCreateDoubleMatrix(nTrials, nHS, mxREAL);
    plhs[4] = mxCreateDoubleMatrix(nTrials, nActions, mxREAL);
    
    prob_v = mxGetPr(plhs[0]);
    currHS_v = mxGetPr(plhs[1]);
    beliefs_m = mxGetPr(plhs[2]);
    normBeliefs_m = mxGetPr(plhs[3]);
    Q_m = mxGetPr(plhs[4]);
    
    /* Trial-by-trial update */
    for(t = 0; t < nTrials; t++)
    {
        stim = stim_seq[t] - 1;
        
        /* Make beliefs pliable */
        beliefs_denom = 0;
        for(i = 0; i < nHS; i++)
        {
            beliefs[stim][i] = pow(beliefs[stim][i],gamma);
            beliefs_denom = beliefs_denom + beliefs[stim][i];
        }
        for(i = 0; i < nHS; i++)
        {
            beliefs[stim][i] = beliefs[stim][i] / beliefs_denom;
        }
        
        /* Update log likelihood */
        if(Q[stim][currHS[stim]][0] + go_bias > 0)
        {
            beta_eff = beta_plus;
        }
        else
        {
            beta_eff = beta_minus;
        }
        
        prob = 1.0 / (1.0 + exp(-beta_eff * (Q[stim][currHS[stim]][0] + go_bias)));
        
        if(act_seq[t] == 1)
        {
            llk = llk + log(prob);
        }
        else
        {
            llk = llk + log(1 - prob);
        }
        
        /* If Go, update beliefs and Q-values for next trial */
        if(act_seq[t] == 1)
        {            
            /* Interpret reinforcement */
            if(reinf_seq[t] == -1)
            {
                reinf_type = 0;
            } else if(reinf_seq[t] == 0)
            {
                reinf_type = 1;
            } else if (reinf_seq[t] == 1)
            {
                reinf_type = 2;
            }
            
            /* Update beliefs */
            beliefs_denom = 0; 
            for(i = 0; i < nHS; i++)
            {
                aux = 0;
                for(j = 0; j < nReinfs; j++)
                {
                    aux = aux + counts[stim][i][j];
                }
                beliefs[stim][i] = beliefs[stim][i] * counts[stim][i][reinf_type] / aux;
                beliefs_denom = beliefs_denom + beliefs[stim][i];
            }
            for(i = 0; i < nHS; i++)
            {
                beliefs[stim][i] = beliefs[stim][i] / beliefs_denom;
            }
            
            /* Check if the (hidden-) state has changed */
            for (i = 0; i < nHS; i++)
            {
                if(i == currHS[stim])
                {
                    state_stick[i] = zeta;
                } else
                {
                    state_stick[i] = 0;
                }
            }
            
            if(beliefs[stim][currHS[stim]] < 0.5) /* otherwise change is not possible */
            {
                j = 0;
                aux = beliefs[stim][0] + state_stick[0];
                for(i = 1; i < nHS; i++)
                {
                    if(beliefs[stim][i] + state_stick[i] > aux)
                    {
                        j = i;
                        aux = beliefs[stim][i] + state_stick[i];
                    }
                }
                currHS[stim] = j;
            }
            
            /* Update counts */
            counts[stim][currHS[stim]][reinf_type] = counts[stim][currHS[stim]][reinf_type] + 1.0;
            
            /* Update Q-values */
            delta = reinf_seq[t] - Q[stim][currHS[stim]][0];
            if (delta > 0)
                Q[stim][currHS[stim]][0] = Q[stim][currHS[stim]][0] + alpha_plus * delta;
            else
                Q[stim][currHS[stim]][0] = Q[stim][currHS[stim]][0] + alpha_minus * delta;
        }
        
        /* Store info in output variables */
        prob_v[t] = prob;
        currHS_v[t] = currHS[stim] + 1;
        for (i = 0; i < nHS; i++)
        {
            beliefs_m[nTrials * i + t] = beliefs[stim][i];
            normBeliefs_m[nTrials * i + t] = beliefs[stim][i];
        }
        for (i = 0; i < nActions; i++)
        {
            Q_m[nTrials * i + t] = Q[stim][currHS[stim]][i];
        }
    }
    
    /* Free stored variables */
    for (i = 0; i < nStims; i++)
    {
        for (j = 0; j < nHS; j++)
        {
            free(Q[i][j]);
            free(counts[i][j]);
        }
        free(Q[i]);
        free(counts[i]);
        free(beliefs[i]);
    }
    free(Q);
    free(counts);
    free(beliefs);
    free(currHS);
    free(state_stick);
    
    return;
}