function paths = shellmdl_set_main_paths(options)
% paths = shellmdl_set_main_paths(options)
%
% shellmdl_set_main_paths is the function that should be used to define 
% and add the main paths. Such main paths are dependent on the user number 
% indicated in shellmdl_master and are indicated in paths.datadir, 
% paths.codedir, and paths.resultsdir. This function should be fully 
% configured before the analysis pipeline is run; hence, the localization 
% of this function inside the "config" folder.
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  [none]
%
% Author: Vasco A. Concei��o
%
% Last modified: January 2024

%% Define main paths
switch options.usernumber
    case 1 % Vasco A. Concei��o
        paths.datadir               = 'C:\Users\User\Downloads\TNU_dataset_Zenodo\Dataset_TNU';         % folder containing the raw and/or manually preprocessed data
        paths.codedir               = 'C:\Users\User\OneDrive\�rea de Trabalho\nbimd_code';             % folder containing the code (must include all relevant TAPAS code); should be the same as pwd()
        paths.resultsdir            = 'C:\Users\User\OneDrive\�rea de Trabalho\nbimd_results';          % folder in which the results will be stored
        paths.previousresultsdir    = 'C:\Users\User\OneDrive\�rea de Trabalho\nbimd_article_results';  % folder in which the (previously obtained) article results are stored
        
    case 2 % Other
        error('Please configure shellmdl_set_main_paths, and then delete this error-code line.');
        
        paths.datadir               = '';       % folder in which the raw and/or manually preprocessed data should be pasted
        paths.codedir               = '';       % folder in which the code should be pasted (must include the relevant TAPAS code)
        paths.resultsdir            = '';       % folder in which the results will be stored
        paths.previousresultsdir    = '';   	% folder in which the previously obtained results are stored
        
    otherwise
        error('Either the user number was incorrectly indicated in shellmdl_master or shellmdl_set_main_paths should be corrected.');
end;

%% Add code paths
addpath(genpath([paths.codedir filesep 'steps']));  % add the "steps" subfolder
addpath(genpath([paths.codedir filesep 'utils']));  % add the "utils" subfolder; see that "config" (the other subfolder) was added in shellmdl_master

end