function options = shellmdl_set_analysis_options(options)
% options = shellmdl_set_analysis_options(options)
%
% shellmdl_set_analysis_options is a function that should be used to set 
% the analysis options of shellmdl_master. It inputs and outputs "options", 
% a struct that fully determines how shellmdl_master is run. 
% Like shellmdl_set_main_paths, this function should be configured by the 
% user before the main analysis pipeline is run; that is why this function 
% is placed inside the "config" folder. 
% To call the functions that generate a certain subset of results in 
% shellmdl_master, the user should set the corresponding options.run and 
% options.load, below, to 1 and 0, respectively. To instead load a subset 
% of the article�s results, rather than calling the functions that generate 
% those results, the user should set the corresponding options.run and 
% options.load to 0 and 1, respectively.
%
% Called in:
%  shellmdl_master
%
% List of key auxiliary functions:
%  shellmdl_specify_model
%
% Note: This function was adapted from other projects; thus, it may reflect
% the contribution from several authors.
%
% Last modified: January 2024

%% Define which analyses (and respective results) will be run (and saved / overwritten) [to be configured by the user]
options.run.taskmotivation                  = 1;
options.save.taskmotivation                 = 1;
options.overwrite.taskmotivation            = 1;
options.verbose.taskmotivation              = 1;

options.run.datapreprocessing               = 1;
options.load.datapreprocessing              = 0;
options.save.datapreprocessing              = 1;
options.overwrite.datapreprocessing         = 1;
options.verbose.datapreprocessing           = 1;

options.run.behavioralanalysis              = 1;
options.load.behavioralanalysis             = 0;
options.save.behavioralanalysis             = 1;
options.overwrite.behavioralanalysis        = 1;
options.verbose.behavioralanalysis          = 1;

% options.run.modelsimulations = 1;                     % includes three types of simulations:
options.run.modelsimulations.poc                        = 0; % proof-of-concept (poc; belief pliability)
options.run.modelsimulations.effectofstateinference     = 0; % effects of state inference on task performance
options.run.modelsimulations.modelrecovery              = 0; % model recovery
options.run.modelsimulations.paramrecovery              = 0; % parameter recovery
options.load.modelsimulations.poc                       = 0;
options.load.modelsimulations.effectofstateinference    = 0;
options.load.modelsimulations.modelrecovery             = 0;
options.load.modelsimulations.paramrecovery             = 0;
options.save.modelsimulations               = 1;
options.overwrite.modelsimulations          = 1;
options.verbose.modelsimulations            = 1;

options.run.modelfitting                    = 0; % includes two distinct MCMC procedures for each model: thermodynamic integration (TI) and model diagnosis
options.load.modelfitting                   = 0;
options.save.modelfitting                   = 1;
options.overwrite.modelfitting              = 1;
options.verbose.modelfitting                = 1;

options.run.modelinspection                 = 0;
options.load.modelinspection                = 0;
options.save.modelinspection                = 1;
options.overwrite.modelinspection           = 1;
options.verbose.modelinspection             = 1;

options.run.modelcomparison                 = 0;
options.load.modelcomparison                = 0;
options.save.modelcomparison                = 1;
options.overwrite.modelcomparison           = 1;
options.verbose.modelcomparison             = 1;

options.run.selectedmodelsanalysis        	= 0;
options.load.selectedmodelsanalysis         = 0;
options.save.selectedmodelsanalysis       	= 1;
options.overwrite.selectedmodelsanalysis  	= 1;
options.verbose.selectedmodelsanalysis    	= 1;

options.run.behavioralreplication           = 0;
options.load.behavioralreplication          = 0;
options.save.behavioralreplication          = 1;
options.overwrite.behavioralreplication     = 1;
options.verbose.behavioralreplication       = 1;

%% Define task-motivation settings [project-specific; not to be changed by the user]
% Task
options.taskmotivation.nStates              = 2;
options.taskmotivation.nPhases              = 2 * options.taskmotivation.nStates; 
options.taskmotivation.nTrialsPerPhase      = 10;
options.taskmotivation.nTrials              = options.taskmotivation.nTrialsPerPhase * options.taskmotivation.nPhases;

options.taskmotivation.phaseColors          = {[0.8 0.1 0.1], ...
                                               [0.1 0.8 0.1], ...
                                               [0.8 0.1 0.1], ...
                                               [0.1 0.8 0.1]};

options.taskmotivation.reinf1   = -1;       % first season is punishing
options.taskmotivation.reinf2   = 1;        % second season is rewarding

% Subject
options.taskmotivation.alpha    = 0.15;     % single learning rate
options.taskmotivation.beta     = 3;        % single inverse temperature

options.taskmotivation.gamma    = 10^-16;   % to depict a subject with "optimal" state inference in this simplistic, deterministic task version
options.taskmotivation.zeta     = 10^-16;

%% Define the dataset [project-specific; not to be changed by the user]
options.dataset.name                = 'NBIMD';                      % NBIMD is the name of the project that resulted in the acquisition of data for this article
options.dataset.sessions            = 1;                            % Only 1 for NBIMD
options.dataset.session             = options.dataset.sessions(1);
options.dataset.nSessions           = numel(options.dataset.sessions);

options.dataset.subjects            = 1:99;                         % The maximum ID was 99, but only data from 50 subjects were acquired;
% the following IDs were not used during data acquisition:
options.dataset.excludedSubjects    = [1:3, 6, 9:10, 12, 15, 18, 20, 22:24, 26, 29, 31, 33, 36:38, 40:41, 43:44, 46:47, ...
    54:55, 59:60, 63:65, 67:70, 74, 79, 81, 83, 85, 87, 89, 91, 93:95, 97];
% the following IDs were excluded because:
options.dataset.excludedSubjects    = [options.dataset.excludedSubjects, 42, 61, 77, 19, 16, 73];
% some did not understand the task (according to the debriefing questionnaire): 16, 42, 61, 73, 77
% some had an extreme p(go), p(go) > 90%:                                       19

options.dataset.subjects            = options.dataset.subjects(~ismember(options.dataset.subjects, options.dataset.excludedSubjects));
options.dataset.nSubjects           = max(options.dataset.subjects);
options.dataset.nEffSubjects        = numel(options.dataset.subjects);

options.dataset.onDrugSubjects      = []; % defined elsewhere
options.dataset.offDrugSubjects     = []; % defined elsewhere

options.dataset.goNogo              = 1;                                                % The Shell Game is a Go/NoGo task
options.dataset.nStimTrials         = [34 34 40 40 34 34];                              % number of times each stimulus (shell) is presented during the task
options.dataset.nTrials             = sum(options.dataset.nStimTrials);
options.dataset.stimNames           = {'RNRN', 'NRNR', 'RPRP', 'PRPR', 'PNPN', 'NPNP'}; % shell names
options.dataset.nStim               = numel(options.dataset.stimNames);
options.dataset.actionNames         = {'Go', 'NoGo'};
options.dataset.nActions            = numel(options.dataset.actionNames);
options.dataset.reinfs              = [1 0 -1];
options.dataset.nReinfs             = numel(options.dataset.reinfs);

options.dataset.seasonNames         = {'Rewarding', 'Neutral', 'Punishing'};
options.dataset.seasonTrials        = [80, 56, 80];
options.dataset.nSeasons            = numel(options.dataset.seasonNames);
options.dataset.nHS                 = 2; % 2 hidden states per shell
options.dataset.nPhases             = 4; % each shell state occurs twice, in an interspersed manner (2 * 2 = 4)

options.dataset.state2seasons       = [... % 1: Rewarding; 2: Neutral; 3: Punishing
    1 2 1 2;    % 1st shell: RNRN
    2 1 2 1;    % 2nd shell: NRNR
    1 3 1 3;    % 3rd shell: RPRP
    3 1 3 1;    % 4th shell: PRPR
    3 2 3 2;    % 5th shell: PNPN
    2 3 2 3];   % 6th shell: NPNP

options.dataset.state2correctaction = [... % 0: no correct action; 1: Go; 2: NoGo
    1 0 1 0;    % Go is the correct answer for R seasons
    0 1 0 1;
    1 2 1 2;
    2 1 2 1;
    2 0 2 0;
    0 2 0 2];   % NoGo is the correct answer for P seasons

%% Define the drug-related info [project-specific; not to be changed by the user]
options.drug.names = {'Escitalopram', 'Placebo'};
options.drug.nGroups = numel(options.drug.names);

%% Define the questionnaires-related info [project-specific; not to be changed by the user]
options.questionnaires.names                = {'OCIR'};
options.questionnaires.subscales            = {'OCIR_washing', 'OCIR_obsessing', 'OCIR_hoarding', 'OCIR_ordering', 'OCIR_checking', 'OCIR_neutralizing'};
options.questionnaires.subscaleQuestions    = [...
    5 11 17;    % 18 questions, split into six subscales
    6 12 18;
    1 7 13;
    3 9 15;
    2 8 14;
    4 10 16];
options.questionnaires.nQuestions           = numel(options.questionnaires.subscaleQuestions);
options.questionnaires.questionScores       = 0:4;          % all questions were scored 0 to 4

options.questionnaires.additionalExcludedSubjects   = 4;    % this subject did not fill in the OCI-R

%% Set the RL Models [not to be changed by the user]
options.rl.modelNames = {...
    'SR1', 'SR2', 'SR3', 'SR4', 'SR5', 'SR6', 'SR7', 'SR8', ...                                                                         % S-R models
    'SSR1', 'SSR2', 'SSR3', 'SSR4', 'SSR5', 'SSR6', 'SSR7', 'SSR8', ...                                                                 % S-S-R models
    'SRalphavar1', 'SRalphavar2', 'SRalphavar3', 'SRalphavar4', 'SRalphavar5', 'SRalphavar6', 'SRalphavar7', 'SRalphavar8', ...         % S-R_{alpha(T)}
    'SRstimstick1', 'SRstimstick2', 'SRstimstick3', 'SRstimstick4', 'SRstimstick5', 'SRstimstick6', 'SRstimstick7', 'SRstimstick8'}';   % S-R_{StimStick}
    
options.rl.modelFamilies = {...
    'SR',           'SR',           'SR',           'SR',           'SR',           'SR',           'SR',           'SR', ...           % S-R models
    'SSR',          'SSR',          'SSR',          'SSR',          'SSR',          'SSR',          'SSR',          'SSR', ...          % S-S-R models
    'SRalphavar',   'SRalphavar',  	'SRalphavar',   'SRalphavar',   'SRalphavar',   'SRalphavar',   'SRalphavar',   'SRalphavar', ...   % S-R models with varying learning rates
    'SRstimstick',  'SRstimstick',  'SRstimstick',  'SRstimstick',  'SRstimstick',  'SRstimstick',  'SRstimstick',  'SRstimstick'}';    % S-R models accounting for stimulus stickiness

options.rl.paramNames   = {...                                      % check shellmdl_specify_model, to see which parameters are used by each model
    '\alpha', 'alpha_plus', 'alpha_minus', ...                      % S-R params
    'beta', 'beta_plus', 'beta_minus',  ...                         % S-R params
    'go_bias', ...                                                  % S-R params (phi)
    'gamma', 'zeta', ...                                            % additional S-S-R params
    'alpha_max', 'alpha_plus_max', 'alpha_minus_max', ...           % additional S-R_{alpha(T)} params
    'alpha_stim_stick', 'stim_stick_bias'}';                        % additional S-R_{stimStick} params

options.rl.params       = {...
    '\alpha', '\alpha_{plus}', '\alpha_{minus}', ...                % either use the former or the latter two
    '\beta', '\beta_{plus}', '\beta_{minus}',  ...                  % either use the former or the latter two
    'go_{bias}', ...
    '\gamma', '\zeta', ...
    '\alpha_{max}', '\alpha_{plus-max}', '\alpha_{minus-max}', ...  % either use the former (if using only alpha) or the latter two (if using both alpha_plus and alpha_minus)
    '\alpha_{stimStick}', '\stimStick_{bias}'}';

options.rl.nModels              = numel(options.rl.modelNames);
options.rl.nMaxParams           = numel(options.rl.params);

options.rl.modelFamilyNumbers   = zeros(options.rl.nModels, 1);
options.rl.modelNumbers         = zeros(options.rl.nModels, 1);
options.rl.iModelNumbers        = zeros(options.rl.nModels, 1);

options.rl.paramNames           = cell(options.rl.nModels, 1);
options.rl.paramNumbers         = cell(options.rl.nModels, 1);
options.rl.nParams              = zeros(options.rl.nModels, 1);
options.rl.params               = zeros(options.rl.nModels, options.rl.nMaxParams);

options.rl.priorDistTypes       = cell(options.rl.nModels, 1);
options.rl.priorDistParams      = cell(options.rl.nModels, 1);
options.rl.priorDistTransfs     = cell(options.rl.nModels, 1);

for iModel = 1:options.rl.nModels
    modelFamily                             = options.rl.modelFamilies{iModel};
    modelName                               = options.rl.modelNames{iModel};
    
    [modelFamilyNumber, modelNumber, iModelNumber, paramNames, paramNumbers, nParams, ...
        priorDistTypes, priorDistParams, priorDistTransf] = ...
        shellmdl_specify_model(modelFamily, modelName);
    
    options.rl.modelFamilyNumbers(iModel)   = modelFamilyNumber;
    options.rl.modelNumbers(iModel)         = modelNumber;
    options.rl.iModelNumbers(iModel)        = iModelNumber;
    
    options.rl.paramNames{iModel}           = paramNames;
    options.rl.paramNumbers{iModel}         = paramNumbers;
    options.rl.nParams(iModel)              = nParams;
    options.rl.params(iModel, paramNumbers) = 1;
    
    options.rl.priorDistTypes{iModel}       = priorDistTypes;
    options.rl.priorDistParams{iModel}      = priorDistParams;
    options.rl.priorDistTransfs{iModel}     = priorDistTransf;
end;

options.rl.nHS                  = 3; % maximum number of inferred hidden states per stimuli (set to 3 for NBIMD, as there are only 3 distinct seasons)

options.rl.mainComparisonModels = 1:16;
options.rl.suppComparisonModels = 1:32;

options.rl.selectedModel        = 16;
options.rl.nestedSRModel        = 8;

options.rl.nParamsSelectedModel = 7; % alpha_plus, alpha_minus, beta_plus, beta_minus, go_bias (phi), gamma, zeta
options.rl.nParamsNestedSRModel = 5; % alpha_plus, alpha_minus, beta_plus, beta_minus, go_bias (phi)

%% Set the MCMC settings [not to be changed by the user]
options.mcmc.dataSpecification = 1;  % Default for MCMC: 1. This number specifies the type of behavioral input that the model will receive:
% 1 - Acquired data
% 2 - Data simulated using RL models and identical traces
% 3 - Data simulated using RL models but other task-alike traces
% 4 - Data simulated using RL models but different types of traces
% 5 - All sequences are manually specified

options.mcmc.procedures         = [ones(options.rl.nModels, 1); 2 * ones(options.rl.nModels, 1)]; % 1, for thermodynamic integration (TI); 2, for model diagnosis
options.mcmc.nProcedures        = numel(options.mcmc.procedures);
options.mcmc.fileNames          = {'tiResults-', 'diagResults-'}; % for TI and model diagnosis, respectively

options.mcmc.modelFamilies      = [options.rl.modelFamilies; options.rl.modelFamilies];
options.mcmc.modelFamilyNumbers = [options.rl.modelFamilyNumbers; options.rl.modelFamilyNumbers];
options.mcmc.modelNames     	= [options.rl.modelNames; options.rl.modelNames];
options.mcmc.modelNumbers       = [options.rl.modelNumbers; options.rl.modelNumbers];
options.mcmc.iModelNumbers      = [options.rl.iModelNumbers; options.rl.iModelNumbers];
options.mcmc.paramNames         = [options.rl.paramNames; options.rl.paramNames];
options.mcmc.paramNumbers       = [options.rl.paramNumbers; options.rl.paramNumbers];
options.mcmc.params             = [options.rl.params; options.rl.params];
options.mcmc.nParams            = [options.rl.nParams; options.rl.nParams];
options.mcmc.priorDistTypes     = [options.rl.priorDistTypes; options.rl.priorDistTypes];
options.mcmc.priorDistParams    = [options.rl.priorDistParams; options.rl.priorDistParams];
options.mcmc.priorDistTransfs   = [options.rl.priorDistTransfs; options.rl.priorDistTransfs];

options.mcmc.nChains    = -Inf * ones(size(options.mcmc.procedures));
options.mcmc.powerTemp  = -Inf * ones(size(options.mcmc.procedures));
for iProcedure = 1:options.mcmc.nProcedures
    switch options.mcmc.procedures(iProcedure)
    case 1 % TI: number of chains at different temperatures (from 0 to 1)
        options.mcmc.nChains(iProcedure)    = 50;   % Default: 50   (should be more than sufficient)  
        options.mcmc.powerTemp(iProcedure)  = 5;    % Default: 5    (this is the exponent; see manuscript for rationale)
    case 2 % model diagnosis: number of chains at the same temperature (1 for all)
        options.mcmc.nChains(iProcedure)    = 10;   % Default: 10   (should be more than sufficient)
        options.mcmc.powerTemp(iProcedure)  = 0;    % Default: 0    (this is the exponent)
    end;
end;

options.mcmc.firstProcedure     = 1;                            % Default: 1, but it may be desired not to run all procedures consecutively
options.mcmc.lastProcedure      = options.mcmc.nProcedures;     % Default: options.mcmc.nProcedures, but it may be desired not to run all procedures consecutively

options.mcmc.nBurninIterations  = 5000;       	% Default: 5000 (should be more than sufficient; this should not be changed from MCMC procedure to MCMC procedure)
options.mcmc.nIterations        = 5000;      	% Default: 5000 (these are the number of post-burnin iterations that will be kept and analyzed; 5000 should be more than sufficient)

options.mcmc.proposal           = [ones(options.rl.nMaxParams,1), 0.01*ones(options.rl.nMaxParams,1)]; 

options.mcmc.saveAll            = 0;            % Default: 0 (if 0, only iterations from last chain are saved; if 1, iterations from all chains are saved)
options.mcmc.doPlots            = 0;            % Default: 0 (if 0, no MCMC-related plots are done)

%% Set the model inspection settings [can be changed by the user, if desired not to run all models in a single shellmdl_master run]
options.modelinspection.firstModel  = 1;
options.modelinspection.lastModel   = options.rl.nModels;

%% Set the model-simulation settings [not to be changed by the user]
options.modelsimulations.effectofstateinference.modelName   = 'SSR8';               % simulations to show the effects of state inference on task performance
options.modelsimulations.modelrecovery.modelNames           = {'SR1', 'SR4', 'SR5', 'SR8', 'SSR1', 'SSR4', 'SSR5', 'SSR8'}';
options.modelsimulations.paramrecovery.modelNames           = {'SSR8', 'SSR8', 'SSR8', 'SSR8', 'SSR8', 'SSR8', 'SSR8'}';

options.modelsimulations.modelrecovery.modelFamilies        = {'SR', 'SR', 'SR', 'SR', 'SSR', 'SSR', 'SSR', 'SSR'}';    % note: before, there was a missing "S" for the SSR models
options.modelsimulations.paramrecovery.modelFamilies        = {'SSR', 'SSR', 'SSR', 'SSR', 'SSR', 'SSR', 'SSR'}';

options.modelsimulations.effectofstateinference.iModelNumber    = 16;               % stickiness proof-of-concept simulations       

options.modelsimulations.modelrecovery.iModelNumbers   = [1; 4; 5; 8; 9; 12; 13; 16];
options.modelsimulations.paramrecovery.iModelNumbers   = repmat(options.rl.selectedModel, options.rl.nParamsSelectedModel, 1);

options.modelsimulations.effectofstateinference.paramValues = [0, 0.411, 0.559, 0, 3.815, 3.516, 0.504, 0.456, 0.210]';	% belief stickiness: proof-of-concept simulations

options.modelsimulations.effectofstateinference.nSimulations            = 3000; % split equally between all panels (gamma, zeta, larger zeta values) [note that each simulation is done for the 44 analyzed task traces]
options.modelsimulations.effectofstateinference.nTypesOfSimulations     = 3;
options.modelsimulations.effectofstateinference.nSimulationsPerParam    = ...
    options.modelsimulations.effectofstateinference.nSimulations / options.modelsimulations.effectofstateinference.nTypesOfSimulations; 

options.modelsimulations.modelrecovery.nSimulations                     = 8; % split equally between all 8 models [note that each simulation is done for the 44 analyzed task traces]
options.modelsimulations.modelrecovery.nSimulationsPerModel             = 1;

options.modelsimulations.modelrecovery.paramValues = {...
    [0.2    2.0]; ...                                                   % alpha                         beta 
    [0.3    0.1     3.0     1.0]; ...                                   % alpha_plus    alpha_minus     beta_plus   beta_minus
    [0.2    2.0     0.2]; ...                                           % alpha                         beta                        phi
    [0.3    0.1     3.0     1.0     0.2]; ...                           % alpha_plus    alpha_minus     beta_plus   beta_minus      phi
    [0.2    2.0     0.5     0.1]; ...                                   % alpha                         beta                                    gamma       zeta
    [0.3   	0.1     3.0     1.0     0.5     0.1]; ...                   % alpha_plus    alpha_minus     beta_plus   beta_minus                  gamma       zeta
    [0.2    2.0     0.2     0.5     0.1]; ...                           % alpha                         beta                      	phi         gamma    	zeta
    [0.3   	0.1     3.0     1.0     0.2     0.5     0.1]};              % alpha_plus    alpha_minus     beta_plus   beta_minus      phi         gamma       zeta

options.modelsimulations.modelrecovery.dataSpecification = 2;  % Default for model- and parameter-recovery simulations: 2 
% This number specifies the type of behavioral input that the model will receive:
% 1 - Acquired data
% 2 - Data simulated using RL models and identical traces
% 3 - Data simulated using RL models but other task-alike traces
% 4 - Data simulated using RL models but different types of traces
% 5 - All sequences are manually specified

options.modelsimulations.modelrecovery.nModels            = numel(options.modelsimulations.modelrecovery.iModelNumbers);
options.modelsimulations.modelrecovery.procedures         = ones(options.modelsimulations.modelrecovery.nModels ^ 2, 1);    % always 1, for thermodynamic integration (TI)
options.modelsimulations.modelrecovery.nProcedures        = numel(options.modelsimulations.modelrecovery.procedures);
options.modelsimulations.modelrecovery.fileNames          = {'simul-tiResults-'};

options.modelsimulations.modelrecovery.modelFamilyNumbers = [1, 1, 1, 1, 2, 2, 2, 2];
options.modelsimulations.modelrecovery.modelNumbers       = [1, 4, 5, 8, 1, 4, 5, 8];

options.modelsimulations.modelrecovery.paramNames         = options.rl.paramNames(options.modelsimulations.modelrecovery.iModelNumbers);
options.modelsimulations.modelrecovery.paramNumbers       = options.rl.paramNumbers(options.modelsimulations.modelrecovery.iModelNumbers);
options.modelsimulations.modelrecovery.params             = options.rl.params(options.modelsimulations.modelrecovery.iModelNumbers);
options.modelsimulations.modelrecovery.nParams            = options.rl.nParams(options.modelsimulations.modelrecovery.iModelNumbers);
options.modelsimulations.modelrecovery.priorDistTypes     = options.rl.priorDistTypes(options.modelsimulations.modelrecovery.iModelNumbers);
options.modelsimulations.modelrecovery.priorDistParams    = options.rl.priorDistParams(options.modelsimulations.modelrecovery.iModelNumbers);
options.modelsimulations.modelrecovery.priorDistTransfs   = options.rl.priorDistTransfs(options.modelsimulations.modelrecovery.iModelNumbers);

options.modelsimulations.modelrecovery.nChains            = -Inf * ones(size(options.modelsimulations.modelrecovery.procedures));
options.modelsimulations.modelrecovery.powerTemp          = -Inf * ones(size(options.modelsimulations.modelrecovery.procedures));
for iProcedure = 1:options.modelsimulations.modelrecovery.nProcedures
    switch options.modelsimulations.modelrecovery.procedures(iProcedure)
    case 1 % TI: number of chains at different temperatures (from 0 to 1)
        options.modelsimulations.modelrecovery.nChains(iProcedure)    = 50;     % Default: 50   (should be more than sufficient)  
        options.modelsimulations.modelrecovery.powerTemp(iProcedure)  = 5;      % Default: 5    (this is the exponent; see manuscript for rationale)
    case 2 % model diagnosis: number of chains at the same temperature (1 for all)
        options.modelsimulations.modelrecovery.nChains(iProcedure)    = 6;      % Default: 6    (should be more than sufficient)
        options.modelsimulations.modelrecovery.powerTemp(iProcedure)  = 0;      % Default: 0    (this is the exponent)
    end;
end;

options.modelsimulations.modelrecovery.firstProcedure     = 1;                                                  % Default: 1, but it may be desired not to run all procedures consecutively
options.modelsimulations.modelrecovery.lastProcedure      = options.modelsimulations.modelrecovery.nProcedures; % Default: options.modelsimulations.modelrecovery.nProcedures, but it may be desired not to run all procedures consecutively

options.modelsimulations.modelrecovery.nBurninIterations  = 5000;   % Default: 5000 (should be more than sufficient; this should not be changed from MCMC procedure to MCMC procedure)
options.modelsimulations.modelrecovery.nIterations        = 5000;   % Default: 5000 (these are the number of post-burnin iterations that will be kept and analyzed; 5000 should be more than sufficient)

options.modelsimulations.modelrecovery.proposal           = [ones(options.rl.nMaxParams,1), 0.01*ones(options.rl.nMaxParams,1)]; 

options.modelsimulations.modelrecovery.saveAll            = 0;      % Default: 0 (if 0, only iterations from last chain are saved; if 1, iterations from all chains are saved)
options.modelsimulations.modelrecovery.doPlots            = 0;      % Default: 0 (if 0, no MCMC-related plots are done)

options.modelsimulations.paramrecovery.nSimulations             = 7;    % all using the selected model [note that each simulation is done for the 44 analyzed task traces]
options.modelsimulations.paramrecovery.nSimulationsPerModel   	= 7;

options.modelsimulations.paramrecovery.dataSpecification        = 2;    % Default for model- and parameter-recovery simulations: 2 
% This number specifies the type of behavioral input that the model will receive:
% 1 - Acquired data
% 2 - Data simulated using RL models and identical traces
% 3 - Data simulated using RL models but other task-alike traces
% 4 - Data simulated using RL models but different types of traces
% 5 - All sequences are manually specified

options.modelsimulations.paramrecovery.nModels            = 1;
options.modelsimulations.paramrecovery.procedures         = 2 * ones(options.modelsimulations.paramrecovery.nSimulations, 1);  	% always 2, for model diagnosis / parameter estimation
options.modelsimulations.paramrecovery.nProcedures        = numel(options.modelsimulations.paramrecovery.procedures);
options.modelsimulations.paramrecovery.fileNames          = {'simul-tiResults-'};

options.modelsimulations.paramrecovery.modelFamilyNumbers = [2, 2, 2, 2, 2, 2, 2];
options.modelsimulations.paramrecovery.modelNumbers       = [8, 8, 8, 8, 8, 8, 8];

options.modelsimulations.paramrecovery.paramNames         = options.rl.paramNames(options.modelsimulations.paramrecovery.iModelNumbers);
options.modelsimulations.paramrecovery.paramNumbers       = options.rl.paramNumbers(options.modelsimulations.paramrecovery.iModelNumbers);
options.modelsimulations.paramrecovery.params             = options.rl.params(options.modelsimulations.paramrecovery.iModelNumbers);
options.modelsimulations.paramrecovery.nParams            = options.rl.nParams(options.modelsimulations.paramrecovery.iModelNumbers);
options.modelsimulations.paramrecovery.priorDistTypes     = options.rl.priorDistTypes(options.modelsimulations.paramrecovery.iModelNumbers);
options.modelsimulations.paramrecovery.priorDistParams    = options.rl.priorDistParams(options.modelsimulations.paramrecovery.iModelNumbers);
options.modelsimulations.paramrecovery.priorDistTransfs   = options.rl.priorDistTransfs(options.modelsimulations.paramrecovery.iModelNumbers);

options.modelsimulations.paramrecovery.nChains            = -Inf * ones(size(options.modelsimulations.paramrecovery.procedures));
options.modelsimulations.paramrecovery.powerTemp          = -Inf * ones(size(options.modelsimulations.paramrecovery.procedures));
for iProcedure = 1:options.modelsimulations.paramrecovery.nProcedures
    switch options.modelsimulations.paramrecovery.procedures(iProcedure)
    case 1 % TI: number of chains at different temperatures (from 0 to 1)
        options.modelsimulations.paramrecovery.nChains(iProcedure)    = 50;     % Default: 50   (should be more than sufficient)  
        options.modelsimulations.paramrecovery.powerTemp(iProcedure)  = 5;      % Default: 5    (this is the exponent; see manuscript for rationale)
    case 2 % model diagnosis: number of chains at the same temperature (1 for all)
        options.modelsimulations.paramrecovery.nChains(iProcedure)    = 6;      % Default: 6    (should be more than sufficient)
        options.modelsimulations.paramrecovery.powerTemp(iProcedure)  = 0;      % Default: 0    (this is the exponent)
    end;
end;

options.modelsimulations.paramrecovery.firstProcedure     = 1;                                                  % Default: 1, but it may be desired not to run all procedures consecutively
options.modelsimulations.paramrecovery.lastProcedure      = options.modelsimulations.paramrecovery.nProcedures; % Default: options.modelsimulations.paramrecovery.nProcedures, but it may be desired not to run all procedures consecutively

options.modelsimulations.paramrecovery.nBurninIterations  = 5000; 	% Default: 5000 (should be more than sufficient; this should not be changed from MCMC procedure to MCMC procedure)
options.modelsimulations.paramrecovery.nIterations        = 5000;  	% Default: 5000 (these are the number of post-burnin iterations that will be kept and analyzed; 5000 should be more than sufficient)

options.modelsimulations.paramrecovery.proposal           = [ones(options.rl.nMaxParams,1), 0.01*ones(options.rl.nMaxParams,1)]; 

options.modelsimulations.paramrecovery.saveAll            = 0;     	% Default: 0 (if 0, only iterations from last chain are saved; if 1, iterations from all chains are saved)
options.modelsimulations.paramrecovery.doPlots            = 0;     	% Default: 0 (if 0, no MCMC-related plots are done)

%% Set the settings for the inspection of the selected model(s) [not to be changed by the user]
options.selectedmodelsanalysis.iModelNumbers   = [options.rl.nestedSRModel; options.rl.selectedModel];
options.selectedmodelsanalysis.nProcedures     = numel(options.selectedmodelsanalysis.iModelNumbers);

options.selectedmodelsanalysis.nCCAIterations  = 100000; % Default: 100000 (but would work well with a much lower number)

%% Define the Figure specifications [can be changed by the user, but it may not be necessary as some Figures were assembled in Adobe Illustrator]
% Common to all figures:
options.figs.res                = 900;      % image resolution
options.figs.fontName           = 'Arial';
options.figs.fontSize           = 8;
options.figs.labelFontSize      = 9;
options.figs.titleFontSize      = 10;
% options.figs.panelFontSize      = 12;    	% not being used now that figure panels are being generated separately, with the full figures being assembled outside MATLAB

options.figs.seasonColors = [...
    0.00 0.65 0.00;     % Rewarding ('dark' green)
    0.85 0.70 0.00;     % Neutral   (yellow; alternatively, it could be grey)
    0.70 0.00 0.00];    % Punishing ('dark' red)
    
options.figs.modelSeasonColors = [...
    0.00 0.80 0.00;     % Rewarding
    0.95 0.80 0.00;     % Neutral
    0.90 0.00 0.00];    % Punishing

options.figs.shellColors = [...
    0.15 0.60 0.10;     % RNRN
    0.15 0.60 0.10;     % NRNR
    0.45 0.45 0.10;     % RPRP
    0.45 0.45 0.10;     % PRPR
    0.60 0.15 0.10;     % PNPN
    0.60 0.15 0.10];    % NPNP

options.figs.shellSubPlots = [2 5 1 4 6 3]; % positions of the shells: RNRN, NRNR, RPRP, PRPR, PNPN, NPNP
% 1. Top left:      RPRP; 2. Top middle:    RNRN; 3. Top right:     NPNP
% 4. Bottom left:   PRPR; 5. Bottom middle: NRNR; 6. Bottom right:  PNPN

options.figs.shellBarPlots = [1 2 3 4 6 5]; % PNPN changed with NPNP, so that shells are sorted by descending p(go) from the left to the right

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 1 (The task): %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Specific to Figure 1D (only panel from Figure 1 created using MATLAB):
options.figs.fig1D.figSize  = [0 0 6 4];
options.figs.fig1D.figName  = 'Fig 1D - Task motivation';
options.figs.fig1D.figRes   = '-r900';          % options.figs.res;

options.figs.fig1D.fontName         = 'Arial';  % options.figs.fontName;
options.figs.fig1D.fontSize         = 7;        % options.figs.fontSize; 
% options.figs.fig1D.legendFontSize   = 7;        % options.figs.legendFontSize;
% options.figs.fig1D.labelFontSize    = 8;        % options.figs.labelFontSize;

options.figs.fig1D.phasePositionsX   = {...
    1:options.taskmotivation.nTrialsPerPhase, ...
    (options.taskmotivation.nTrialsPerPhase + 1):(2 * options.taskmotivation.nTrialsPerPhase), ...
    (2 * options.taskmotivation.nTrialsPerPhase + 1):(3 * options.taskmotivation.nTrialsPerPhase), ...
    (3 * options.taskmotivation.nTrialsPerPhase + 1):(4 * options.taskmotivation.nTrialsPerPhase)};
               
options.figs.fig1D.posY1             = -0.005; 
options.figs.fig1D.posY2             = 1.005;
options.figs.fig1D.phasePositionsY   = {...
    repmat(options.figs.fig1D.posY1, 1, options.taskmotivation.nTrialsPerPhase), ...
    repmat(options.figs.fig1D.posY2, 1, options.taskmotivation.nTrialsPerPhase), ...
    repmat(options.figs.fig1D.posY1, 1, options.taskmotivation.nTrialsPerPhase), ...
    repmat(options.figs.fig1D.posY2, 1, options.taskmotivation.nTrialsPerPhase)};

options.figs.fig1D.srLearnerColor        = [0.65 0.65 0.65];
options.figs.fig1D.stateInferenceColor   = [0 0 0];
options.figs.fig1D.legendString          = {'S-R learning'; 'State inference'};

options.figs.fig1D.axis_v            = [0, ...
    options.taskmotivation.nPhases * options.taskmotivation.nTrialsPerPhase + 1, ...
    options.figs.fig1D.posY1, ...
    options.figs.fig1D.posY2];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 3 (Model comparison): %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Specific to Figure 3A:
options.figs.fig3A.name              = 'Figure 3A - model frequencies';
options.figs.fig3A.dimensions        = [0 0 7 4.5];
options.figs.fig3A.axis              = [0.5, 19.5, 0, 1];
options.figs.fig3A.xLabel            = [];
options.figs.fig3B.xLabel_aux        = [];
options.figs.fig3A.xTick             = 1:19;
options.figs.fig3A.xTickLabel        = {' ', '1', '2', '3', '4', '5', '6', '7', '8', ' ', '1', '2', '3', '4', '5', '6', '7', '8', ' '};
options.figs.fig3A.barColors         = 'k';
options.figs.fig3A.yChance           = 1/options.rl.nModels;
options.figs.fig3A.chanceLine        = '-r';
options.figs.fig3A.yLabel            = 'Model frequency';
options.figs.fig3A.yTick             = 0:0.2:1;

% Specific to Figure 3B:
options.figs.fig3B.name              = 'Figure 3B - protected EPs';
options.figs.fig3B.dimensions        = [0 0 7 4.5];
options.figs.fig3B.axis              = [0.5, 19.5, 0, 1];
options.figs.fig3B.xLabel            = [];
options.figs.fig3B.xLabel_aux        = [];
options.figs.fig3B.xTick             = 1:19;
options.figs.fig3B.xTickLabel        = {' ', '1', '2', '3', '4', '5', '6', '7', '8', ' ', '1', '2', '3', '4', '5', '6', '7', '8', ' '};
options.figs.fig3B.barColors         = 'k';
options.figs.fig3B.yThreshold        = 0.95; % PEP for confident selection of a model
options.figs.fig3B.thresholdLine     = '-r';
options.figs.fig3B.yLabel            = 'PEP';
options.figs.fig3B.yTick             = 0:0.2:1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 4 (SR8 and SSR8 model fit at an individual level): %%%%%%%%%%%%%%% 
% Specific to (all panels from) Figure 4:
options.figs.fig4.res                = 1000;
options.figs.fig4.nPanels          	 = 2;
options.figs.fig4.subjects           = options.dataset.subjects;
options.figs.fig4.nSubjects          = numel(options.figs.fig4.subjects);
options.figs.fig4.dimensions         = [0 0 18 11];
options.figs.fig4.markerSize         = 4;
options.figs.fig4.seasonLineWidth    = 3;
options.figs.fig4.dispTol            = [0.1 0.15];

options.figs.fig4.undiscoveredSeasonColor   = [0 0 0];

options.figs.fig4.subjectInUse     	= 98;
% given that color-coding is subject-dependent, if this subject is 
% changed, some additional configuration might be needed within the 
% respective function

% Specific to Figure 4A:
options.figs.fig4A.name              = 'Figure 4A - predicted p(Go) in each shell trial for a given subject';
options.figs.fig4A.xLabel            = 'Trial';
options.figs.fig4A.lineColors        = [0.65 0.65 0.65; 0 0 0];
options.figs.fig4A.lineTypes         = {'--', '-'};
options.figs.fig4A.lineWidth         = 1;
options.figs.fig4A.yLabel            = 'P(Go)';
options.figs.fig4A.yTick             = 0:0.2:1;
options.figs.fig4A.seasonYPositions  = [1.06, 0.5, -0.06]; % R, N, P seasons

% Specific to Figure 4B:
options.figs.fig4B.name              = 'Figure 4B - predicted p(state) in each shell trial for a given subject';
options.figs.fig4B.xLabel            = 'Trial';

options.figs.fig4B.yLabel            = 'P(State)';
options.figs.fig4B.yTick             = 0:0.2:1;
options.figs.fig4B.seasonYPositions  = [1.06, 1.06, 1.06]; % R, N, P seasons

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 5 (and respective Supplementary Figure) [SSR8 (SR8) model fit at the group level]:
% Specific to Figure 5A:
options.figs.fig5A.nPanels           = 4; % but only 2 are used in the paper
options.figs.fig5A.name              = 'Figure 5A - fitted p(Go) per season';
options.figs.fig5A.dimensions        = [0 0 4 5];
options.figs.fig5A.axis              = [0.5, options.dataset.nSeasons + 0.5, 0, 1];
options.figs.fig5A.xLabel            = 'Season';
options.figs.fig5A.xTick             = 1:options.dataset.nSeasons;
options.figs.fig5A.xTickLabel        = {'R', 'N', 'P'};
options.figs.fig5A.yLabel            = 'P(Go)';
options.figs.fig5A.yTick             = 0:0.2:1;

options.figs.fig5A.seasonColors      = [0.2 0.2 0.2; 0.2 0.2 0.2; 0.2 0.2 0.2];
options.figs.fig5A.modelSeasonColors = [0.8 0.8 0.8; 0.8 0.8 0.8; 0.8 0.8 0.8];

options.figs.fig5A_Supp.name         = 'Supp Figure - fitted p(Go) per season - SR8';                   % Extended Data Figure 1A

% Specific to Figure 5B:
options.figs.fig5B.name              = 'Figure 5B - mean predicted p(Go) per shell phase - SSR8';
options.figs.fig5B.dimensions        = [0 0 16 9.5];
options.figs.fig5B.axis              = [1 - 0.55, options.dataset.nPhases + 0.55, 0 - 0.05, 1 + 0.05];
options.figs.fig5B.xLabel            = 'Phase';
options.figs.fig5B.xTick             = 1:options.dataset.nPhases;
options.figs.fig5B.yLabel            = 'P(Go)';
options.figs.fig5B.yTick             = 0:0.2:1;
options.figs.fig5B.line              = '-';
options.figs.fig5B.lineColor         = [0.8 0.8 0.8]; 
options.figs.fig5B.lineWidth         = 2;
options.figs.fig5B.seasonLineWidth   = 3;
options.figs.fig5B.seasonYPositions  = [1.025, 0.5, - 0.025]; % R, N, P seasons
options.figs.fig5B.seasonXPositions  = [...
    0.5 1.5;    % phase 1
    1.5 2.5;    % phase 2
    2.5 3.5;    % phase 3
    3.5 4.5];   % phase 4

options.figs.fig5B.auxLine           = '-';
options.figs.fig5B.auxLineColor      = [0.2 0.2 0.2];
options.figs.fig5B.auxLineWidth      = 2;

options.figs.fig5B_Supp.name      	= 'Supp Figure - mean predicted p(Go) per shell phase - SR8';       % Extended Data Figure 1B

% Specific to Figure 5C:
options.figs.fig5C.nPanels           = 4; % but only 2 are used in the paper
options.figs.fig5C.name              = 'Figure 5C - fitted p(corr) in the 2nd and 4th phases';
options.figs.fig5C.dimensions        = [0 0 4 5];
options.figs.fig5C.axis              = [0.5, 2.5, 0.5, 1];
options.figs.fig5C.xLabel            = 'Phase';
options.figs.fig5C.xTick             = 1:2;
options.figs.fig5C.xTickLabel        = {'2', '4'};
options.figs.fig5C.barColors         = [0.75 0.75 0.75; 0.75 0.75 0.75];
options.figs.fig5C.yLabel            = 'P(Correct)';
options.figs.fig5C.yTick             = 0.5:0.1:1;

options.figs.fig5C.auxBarColors      = [0.2 0.2 0.2; 0.2 0.2 0.2];

options.figs.fig5C_Supp.name         = 'Supp Figure - fitted p(corr) in the 2nd and 4th phases - SR8'; 	% Extended Data Figure 1C

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Methods Figure 3 (Proof-of-concept simulations): %%%%%%%%%%%%%%%%%%%%%%%%
options.figs.figM3.figName          = 'Belief pliability';
options.figs.figM3.figDimensions    = [0 0 18 15];
options.figs.figM3.nPanels          = 4;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Extended Data Figure 2 (Extended model comparison): %%%%%%%%%%%%%%%%%%%%%
options.figs.figED2A.dimensions     = [0 0 12 4.5];
options.figs.figED2A.name           = 'Figure ED2A - model frequencies';
options.figs.figED2A.xTickAngle     = 0;
options.figs.figED2A.xTickLabel     = {' ', '1', '2', '3', '4', '5', '6', '7', '8', ...
        ' ', '1', '2', '3', '4', '5', '6', '7', '8', ...
        ' ', '1', '2', '3', '4', '5', '6', '7', '8', ...
        ' ', '1', '2', '3', '4', '5', '6', '7', '8', ' '};

options.figs.figED2B.dimensions     = [0 0 12 4.5];
options.figs.figED2B.name           = 'Figure ED2B - protected EPs';
options.figs.figED2B.xTickAngle     = 0;
options.figs.figED2B.xTickLabel     = {' ', '1', '2', '3', '4', '5', '6', '7', '8', ...
        ' ', '1', '2', '3', '4', '5', '6', '7', '8', ...
        ' ', '1', '2', '3', '4', '5', '6', '7', '8', ...
        ' ', '1', '2', '3', '4', '5', '6', '7', '8', ' '};
options.figs.figED2B.yThreshold 	= 0.95; % PEP for confident selection of a model
options.figs.figED2B.thresholdLine  = '-r';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Supplementary Results Figure 1 (Effect of state inference on performance):
options.figs.figSR1.dimensions         = [0 0 9.5 8];
options.figs.figSR1.ylabel             = 'Number of Correct Responses';

% Specific to Supplementary Results Figure 1A:
options.figs.figSR1A.yMin              = 112;   % define axes of the figure
options.figs.figSR1A.yMax              = 124;
options.figs.figSR1A.xMin              = 0;
options.figs.figSR1A.xMax              = 1;

options.figs.figSR1A.xlValue           = 0.250; % to plot a vertical line, left x value
options.figs.figSR1A.xrValue           = 0.693; % to plot a vertical line, right x value

options.figs.figSR1A.xmaxValue         = 0.167; % to plot an additional vertical line, x value that leads to the maximum

% Specific to Supplementary Results Figure 1B:
options.figs.figSR1B.yMin              = 112;
options.figs.figSR1B.yMax              = 124;
options.figs.figSR1B.xMin              = 0;
options.figs.figSR1B.xMax              = 0.5;

options.figs.figSR1B.xlValue           = 0.065; % to plot a vertical line, left x value
options.figs.figSR1B.xrValue           = 0.356; % to plot a vertical line, right x value

% Specific to Supplementary Results Figure 1C:
options.figs.figSR1C.yMin              = 112;
options.figs.figSR1C.yMax              = 124;
options.figs.figSR1C.xMin              = 0.5;
options.figs.figSR1C.xMax              = 1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Supplementary Results Figure 2 (Model- and parameter-recovery simulations):
options.figs.figSR2.paramNames       = {'\alpha^+', '\alpha^-', '\beta^+', '\beta^-', '\phi', '\gamma', '\zeta'};
options.figs.figSR2.paramNames_mod   = {'\alpha^+', '\alpha^-', '\beta^+', '\beta^-', '\phi', '\gamma', '\zeta'};

% Specific to Supplementary Results Figure 2A:
options.figs.figSR2A.name          	 = 'Figure SR2A - Confusion Matrix';
options.figs.figSR2A.dimensions      = [0 0 12 10] * 3/4;
options.figs.figSR2A.axis            = [0.25 8.75 0.25 8.75];
options.figs.figSR2A.xLabel          = 'Simulated Model';
options.figs.figSR2A.xTick           = 1:1:8;
options.figs.figSR2A.xTickLabel      = {'SR1', 'SR4', 'SR5', 'SR8', 'SSR1', 'SSR4', 'SSR5', 'SSR8'};
options.figs.figSR2A.yLabel          = 'Fit Model';
options.figs.figSR2A.yTick           = options.figs.figSR2A.xTick;
options.figs.figSR2A.yTickLabel      = options.figs.figSR2A.xTickLabel;
options.figs.figSR2A.title           = 'PEP';

% Specific to Supplementary Results Figure 2B:
options.figs.figSR2B.figDimensions   = [0 0 5 5];
options.figs.figSR2B.x_label         = 'Simulated value';
options.figs.figSR2B.y_label         = 'Fit value';
options.figs.figSR2B.fontName        = 'Arial';
options.figs.figSR2B.titleFontSize   = 9;
options.figs.figSR2B.labelFontSize   = 8;
options.figs.figSR2B.fontSize        = 7;
options.figs.figSR2B.markerSize      = 2;
options.figs.figSR2B.markerColor     = 'b';

options.figs.figSR2B.figureNames     = {...
    'Parameter recovery - alpha_plus';
    'Parameter recovery - alpha_minus';
    'Parameter recovery - beta_plus';
    'Parameter recovery - beta_minus';
    'Parameter recovery - phi';
    'Parameter recovery - gamma';
    'Parameter recovery - zeta'};

options.figs.figSR2B.x_tick          = [...
    0.0 : 0.2 : 1.0;        % alpha+
    0.0 : 0.2 : 1.0;        % alpha-
    0.0 : 3.0 : 15;         % beta+
    0.0 : 3.0 : 15;         % beta-
    0.0 : 0.2 : 1.0         % phi
    0.0 : 0.2 : 1.0         % gamma
    0.0 : 0.1 : 0.5];       % zeta

options.figs.figSR2B.y_tick          = options.figs.figSR2B.x_tick;

options.figs.figSR2B.axis_v          = [...
    0   1       0   1;      % alpha+
    0   1       0   1;      % alpha-
    0   15      0   15;     % beta+
    0   15      0   15;     % beta-
    0   1       0   1       % phi
    0   1       0   1       % gamma
    0   0.5     0   0.5];   % zeta

% Specific to Supplementary Results Figure 2C:
options.figs.figSR2C.figDimensions                  = [0 0 9 7.5];

options.figs.figSR2C.whiteShadingColorMap           = 1;    % Default: 1
options.figs.figSR2C.use_Holm_corrected_p_values    = 1;    % Default: 1

% create a color map to facilitate Figure visualization:
mymap(1, :)     = [0.60 0.00 0.00];  mymap(2, :)     = [0.65 0.00 0.00];
mymap(3, :)     = [0.70 0.00 0.00];  mymap(4, :)     = [0.75 0.00 0.00];
mymap(5, :)     = [0.80 0.00 0.00];  mymap(6, :)     = [0.85 0.00 0.00];
mymap(7, :)     = [0.90 0.00 0.00];  mymap(8, :)     = [0.95 0.00 0.00];
mymap(9, :)     = [1.00 0.00 0.00];  mymap(10, :)    = [1.00 0.05 0.05];
mymap(11, :)    = [1.00 0.10 0.10];  mymap(12, :)    = [1.00 0.15 0.15];
mymap(13, :)    = [1.00 0.20 0.20];  mymap(14, :)    = [1.00 0.25 0.25];
mymap(15, :)    = [1.00 0.30 0.30];  mymap(16, :)    = [1.00 0.35 0.35];
mymap(17, :)    = [1.00 0.40 0.40];  mymap(18, :)    = [1.00 0.45 0.45];
mymap(19, :)    = [1.00 0.50 0.50];  mymap(20, :)    = [1.00 0.55 0.55];
mymap(21, :)    = [1.00 0.60 0.60];  mymap(22, :)    = [1.00 0.65 0.65];
mymap(23, :)    = [1.00 0.70 0.70];  mymap(24, :)    = [1.00 0.75 0.75];
mymap(25, :)    = [1.00 0.80 0.80];  mymap(26, :)    = [1.00 0.85 0.85];
mymap(27, :)    = [1.00 0.90 0.90];  mymap(28, :)    = [1.00 0.95 0.95];
mymap(29, :)    = [1.00 1.00 1.00];  mymap(30, :)    = [0.975 0.975 1.00];
mymap(31, :)    = [0.95 0.95 1.00];  mymap(32, :)    = [0.925 0.925 1.00];
mymap(33, :)    = [0.90 0.90 1.00];  mymap(34, :)    = [0.86 0.86 1.00];
mymap(35, :)    = [0.82 0.82 1.00];  mymap(36, :)    = [0.78 0.78 1.00];
mymap(37, :)    = [0.74 0.74 1.00];  mymap(38, :)    = [0.70 0.70 1.00];
mymap(39, :)    = [0.65 0.65 1.00];  mymap(40, :)    = [0.60 0.60 1.00];
mymap(41, :)    = [0.55 0.55 1.00];  mymap(42, :)    = [0.50 0.50 1.00];
mymap(43, :)    = [0.45 0.45 1.00];  mymap(44, :)    = [0.40 0.40 1.00];
mymap(45, :)    = [0.35 0.35 1.00];  mymap(46, :)    = [0.30 0.30 1.00];
mymap(47, :)    = [0.25 0.25 1.00];  mymap(48, :)    = [0.20 0.20 1.00];
mymap(49, :)    = [0.15 0.15 1.00];  mymap(50, :)    = [0.10 0.10 1.00];
mymap(51, :)    = [0.05 0.05 1.00];  mymap(52, :)    = [0.00 0.00 1.00];
mymap(53, :)    = [0.00 0.00 0.925]; mymap(54, :)    = [0.00 0.00 0.85];
mymap(55, :)    = [0.00 0.00 0.775]; mymap(56, :)    = [0.00 0.00 0.70];
mymap(57, :)    = [0.00 0.00 0.60];

options.figs.figSR2C.mymap = mymap;

if options.figs.figSR2C.whiteShadingColorMap
    if options.figs.figSR2C.use_Holm_corrected_p_values
        options.figs.figSR2C.myMapWhiteFirst = 18; % based on Holm-corrected p-values
        options.figs.figSR2C.myMapWhiteLast  = 40;
    else
        options.figs.figSR2C.myMapWhiteFirst = 21; % based on uncorrected p-values
        options.figs.figSR2C.myMapWhiteLast  = 37;
    end;
end;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Supplementary Results Figure 3 [Behavioral replication of the association between escitalopram and p(corr)]:
% Specific to Supplementary Results Figure 3A:
options.figs.figSR3A.name              = 'Figure SR3A - Relation between the increase in p(corr) from the 2nd to 4th phases and escitalopram';
options.figs.figSR3A.dimensions        = [0 0 6 4.5];
options.figs.figSR3A.axis              = [0, 85, -0.3, 0.5];
options.figs.figSR3A.xLabel            = 'Escitalopram level (nmol/l)';
options.figs.figSR3A.xTick             = 0:10:80;
options.figs.figSR3A.yLabel            = '\DeltaP(Correct)';
options.figs.figSR3A.yTick             = -0.3:0.1:0.5;
options.figs.figSR3A.markerSize        = 4;
options.figs.figSR3A.markerFaceColor   = 'k';  % raw data points colored in black
options.figs.figSR3A.markerEdgeColor   = 'k';
options.figs.figSR3A.regressionLine    = ':k'; % regression line in black also

% Specific to Supplementary Results Figure 3B:
options.figs.figSR3B.name              = 'Figure SR3B - Relation between the mean p(corr) in phases 3 and 4 and escitalopram';
options.figs.figSR3B.dimensions        = [0 0 6 4.5];
options.figs.figSR3B.axis              = [0, 85, 0.4, 1];
options.figs.figSR3B.xLabel            = 'Escitalopram level (nmol/l)';
options.figs.figSR3B.xTick             = 0:10:80;
options.figs.figSR3B.yLabel            = 'P_{{3,4}}(Correct)';  
options.figs.figSR3B.yTick             = 0.4:0.1:1;           
options.figs.figSR3B.markerSize        = 4;
options.figs.figSR3B.markerFaceColor   = 'k';  % raw data points colored in black
options.figs.figSR3B.markerEdgeColor   = 'k';
options.figs.figSR3B.regressionLine    = ':k'; % regression line in black also

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Supplementary Results Figure 4 [Behavioral replication of the association between escitalopram and p(go) in different seasons]:
% Specific to Supplementary Results Figure 4 (A, left panel):
options.figs.figSR4A.name             = 'Figure SR4A - Logistic regression predicting p(go) for rewarding seasons';
options.figs.figSR4A.dimensions       = [0 0 5 5 ];
options.figs.figSR4A.axis             = [0, 85, 0, 1];
options.figs.figSR4A.xLabel           = 'Escitalopram level (nmol/l)';
options.figs.figSR4A.xTick            = 0:20:80;
options.figs.figSR4A.yLabel           = 'P(Go)';
options.figs.figSR4A.yTick            = 0:0.2:1;
options.figs.figSR4A.title            = 'R';
options.figs.figSR4A.markerSize       = 4;
options.figs.figSR4A.markerFaceColor  = options.figs.seasonColors(1, :);
options.figs.figSR4A.markerEdgeColor  = options.figs.seasonColors(1, :);
options.figs.figSR4A.regressionLine   = ':k';
options.figs.figSR4A.labelFontSize    = 9;
options.figs.figSR4A.fontSize         = 8;

% Specific to Supplementary Results Figure 4 (B, middle panel):
options.figs.figSR4B.name             = 'Figure SR4B - Logistic regression predicting p(go) for neutral seasons';
options.figs.figSR4B.dimensions       = [0 0 5 5 ];
options.figs.figSR4B.axis             = [0, 85, 0, 1];
options.figs.figSR4B.xLabel           = 'Escitalopram level (nmol/l)';
options.figs.figSR4B.xTick            = 0:20:80;
options.figs.figSR4B.yLabel           = '';
options.figs.figSR4B.yTick            = 0:0.2:1;
options.figs.figSR4B.yTickLabel       = [];
options.figs.figSR4B.title            = 'N';
options.figs.figSR4B.markerSize       = 4;
options.figs.figSR4B.markerFaceColor  = options.figs.seasonColors(2, :);
options.figs.figSR4B.markerEdgeColor  = options.figs.seasonColors(2, :);
options.figs.figSR4B.regressionLine   = ':k';
options.figs.figSR4B.labelFontSize    = 9;
options.figs.figSR4B.fontSize         = 8;

% Specific to Supplementary Results Figure 4 (C, right panel):
options.figs.figSR4C.name             = 'Figure SR4C - Logistic regression predicting p(go) for punishing seasons';
options.figs.figSR4C.dimensions       = [0 0 5 5 ];
options.figs.figSR4C.axis             = [0, 85, 0, 1];
options.figs.figSR4C.xLabel           = 'Escitalopram level (nmol/l)';
options.figs.figSR4C.xTick            = 0:20:80;
options.figs.figSR4C.yLabel           = '';
options.figs.figSR4C.yTick            = 0:0.2:1;
options.figs.figSR4C.yTickLabel       = [];
options.figs.figSR4C.title            = 'P';
options.figs.figSR4C.markerSize       = 4;
options.figs.figSR4C.markerFaceColor  = options.figs.seasonColors(3, :);
options.figs.figSR4C.markerEdgeColor  = options.figs.seasonColors(3, :);
options.figs.figSR4C.regressionLine   = ':k';
options.figs.figSR4C.labelFontSize    = 9;
options.figs.figSR4C.fontSize         = 8;
end
