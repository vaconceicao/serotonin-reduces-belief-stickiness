function [modelFamilyNumber, modelNumber, iModelNumber, paramNames, paramNumbers, nParams, ...
    priorDistTypes, priorDistParams, priorDistTransf] = ...
    shellmdl_specify_model(modelFamily, modelName)
% [modelNumber, paramNames, paramNumbers, nParams, priorDistTypes, ...
%   priorDistParams, priorDistTransf] = shellmdl_specify_model(modelFamily, modelName)
%
% shellmdl_specify_model is a function called (e.g.) in 
% shellmdl_set_analysis_options that receives the family and name of
% a given reinforcement-learning (RL) model as input, and, according to 
% that information, fully specifies the parameters (and respective prior 
% distributions) of the RL model. In doing so, shellmdl_specify_model 
% provides as output the (some of the) necessary information for the 
% inversion routine of the respective RL model. (The MCMC and other 
% model-inversion settings are specified elsewhere.)
% 
% All RL models specified here are implemented inside the 
% "steps/modelfit/likeli" folder. There, they're organized in subfolders, 
% according to their respective model families (e.g., ".../likeli/SR/SR1", 
% for the S-R-1 model).
%
% Input:
%  modelFamily                      1-4: SR; SSR; SRalphavar; SRstimstick
%  modelName
%
% Output:
%  modelFamilyNumber                1-4: SR; SSR; SRalphavar; SRstimstick
%  modelNumber                      Number within-family (1 to 8)
%  iModelNumber                     Number across families (1 to 32)
%  paramNames                       
%  paramNumbers
%  nParams
%  priorDistTypes                   1-2: Beta; Gamma
%  priorDistParams
%  priorDistTransf                  Specify how the parameter drawn from 
%                               the prior distribution is linearly 
%                               transformed before being used in the RL 
%                               model(1 and 0, respectively, if no
%                               transformation is necessary)
%
% Author: Vasco A. Concei��o
%
% Last modified: September 2023
%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Additional details:
%
% Parameters (and respective paramNames):
%  learning rate(s):
%       1:  alpha                   single learning rate OR
%       2:  alpha_plus          	positive learning rate &
%       3:  alpha_minus          	negative learning rate
%
%  inverse temperature(s):
%       4:  beta                    single inverse temperature OR
%       5:  beta_plus               positive inverse temperature &
%       6:  beta_minus          	negative inverse temperature
%
%  go bias:
%       7:  go_bias (or phi)        bias to do Go (versus NoGo)
%
%  state-inference parameters:
%       8:  gamma               	(over)reliance in the previous beliefs
%                                	  about (hidden) states
%       9:  zeta                    additional inertia to (hidden-) state 
%                                     changes
%
%  learning-rate modifier(s):
%       10: alpha_max               maximum value of the single learning
%                                    rate (when this parameter is used,
%                                    alpha is the value of the effective
%                                    learning rate at the first trial of
%                                    the task and alpha_max is the value
%                                    of the effective learning rate at
%                                    the last trial of the task) OR
%       11: alpha_plus_max          maximum value of the positive learning
%                                    rate (analogous to alpha_max, but for
%                                    alpha_plus) &
%       12: alpha_minus_max         maximum value of the negative learning
%                                    rate (analogous to alpha_max, but for
%                                    alpha_minus)
%
%  stimulus-stickiness parameters:
%       13: alpha_stim_stick        learning rate used to update the
%                                    stimulus-stickiness value
%       14: stim_stick_bias         maximum stimulus-stickiness value
%
% Families:
%  S-R models (SR) include only parameters 1-7
%  S-S-R models (SSR) include parameters 1-7 and 8-9
%  S-R_{alpha(T)} models (SRalphavar) include parameters 1-7 and 10-12
%  S-R_{StimStick} models (SRstimstick) include parameters 1-7 and 13-14

%%
if isequal(modelFamily, 'SR')
    modelFamilyNumber   = 1;
    modelNumber         = str2double(modelName(3:end));
    iModelNumber        = modelNumber;
elseif isequal(modelFamily, 'SSR')
    modelFamilyNumber   = 2;
    modelNumber         = str2double(modelName(4:end));
    iModelNumber        = modelNumber + 8;
elseif isequal(modelFamily, 'SRalphavar')
    modelFamilyNumber   = 3;
    modelNumber         = str2double(modelName(11:end));
    iModelNumber        = modelNumber + 16;
elseif isequal(modelFamily, 'SRstimstick')
    modelFamilyNumber   = 4;
    modelNumber         = str2double(modelName(12:end));
    iModelNumber        = modelNumber + 24;
else
    error('Not implemented yet.');
end

% To configure the S-R models:
switch modelNumber
    case 1 % S-R-1 model or its equivalents from other families %%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        paramNames      = {'alpha', 'beta'};
        paramNumbers    = [1, 4];
        nParams         = numel(paramNames);
        
        priorDistTypes  = [1; 2];
        priorDistParams = [...
            1.01, 1.01;
            2.00, 2.00];
        priorDistTransf = [ones(nParams, 1), zeros(nParams, 1)];
        
    case 2 % S-R-2 model or its equivalents from other families %%%%%%%%%%%
        paramNames      = {'alpha_plus', 'alpha_minus', 'beta'};
        paramNumbers    = [2, 3, 4];
        nParams         = numel(paramNames);
        
        priorDistTypes  = [1; 1; 2];
        priorDistParams = [...
            1.01, 1.01;
            1.01, 1.01;
            2.00, 2.00];
        priorDistTransf = [ones(nParams, 1), zeros(nParams, 1)];
        
    case 3 % S-R-3 model or its equivalents from other families %%%%%%%%%%%
        paramNames      = {'alpha', 'beta_plus', 'beta_minus'};
        paramNumbers    = [1, 5, 6];
        nParams         = numel(paramNames);
        
        priorDistTypes  = [1; 2; 2];
        priorDistParams = [...
            1.01, 1.01;
            2.00, 2.00;
            2.00, 2.00];
        priorDistTransf = [ones(nParams, 1), zeros(nParams, 1)];
        
    case 4 % S-R-4 model or its equivalents from other families %%%%%%%%%%%
        paramNames      = {'alpha_plus', 'alpha_minus', 'beta_plus', 'beta_minus'};
        paramNumbers    = [2, 3, 5, 6];
        nParams         = numel(paramNames);
        
        priorDistTypes  = [1; 1; 2; 2];
        priorDistParams = [...
            1.01, 1.01;
            1.01, 1.01;
            2.00, 2.00;
            2.00, 2.00];
        priorDistTransf = [ones(nParams, 1), zeros(nParams, 1)];
        
    case 5 % S-R-5 model or its equivalents from other families %%%%%%%%%%%
        paramNames      = {'alpha', 'beta', 'go_bias'};
        paramNumbers    = [1, 4, 7];
        nParams         = numel(paramNames);
        
        priorDistTypes  = [1; 2; 1];
        priorDistParams = [...
            1.01, 1.01;
            2.00, 2.00;
            1.01, 1.01];
        priorDistTransf = [ones(nParams, 1), zeros(nParams, 1)];
        
    case 6 % S-R-6 model or its equivalents from other families %%%%%%%%%%%
        paramNames      = {'alpha_plus', 'alpha_minus', 'beta', 'go_bias'};
        paramNumbers    = [2, 3, 4, 7];
        nParams         = numel(paramNames);
        
        priorDistTypes  = [1; 1; 2; 1];
        priorDistParams = [...
            1.01, 1.01;
            1.01, 1.01;
            2.00, 2.00;
            1.01, 1.01];
        priorDistTransf = [ones(nParams, 1), zeros(nParams, 1)];
        
    case 7 % S-R-7 model or its equivalents from other families %%%%%%%%%%%
        paramNames      = {'alpha', 'beta_plus', 'beta_minus', 'go_bias'};
        paramNumbers    = [1, 5, 6, 7];
        nParams         = numel(paramNames);
        
        priorDistTypes  = [1; 2; 2; 1];
        priorDistParams = [...
            1.01, 1.01;
            2.00, 2.00;
            2.00, 2.00;
            1.01, 1.01];
        priorDistTransf = [ones(nParams, 1), zeros(nParams, 1)];
        
    case 8 % S-R-8 model or its equivalents from other families %%%%%%%%%%%
        paramNames      = {'alpha_plus', 'alpha_minus', 'beta_plus', 'beta_minus', 'go_bias'};
        paramNumbers    = [2, 3, 5, 6, 7];
        nParams         = numel(paramNames);
        
        priorDistTypes  = [1; 1; 2; 2; 1];
        priorDistParams = [...
            1.01, 1.01;
            1.01, 1.01;
            2.00, 2.00;
            2.00, 2.00;
            1.01, 1.01];
        priorDistTransf = [ones(nParams, 1), zeros(nParams, 1)];
end;

% To finish configuring the other models (those not from the S-R family):
if isequal(modelFamily, 'SSR')
    paramNames      = [paramNames, 'gamma', 'zeta'];
    paramNumbers    = [paramNumbers, 8, 9];
    nParams         = nParams + 2;
    
    priorDistTypes  = [priorDistTypes; 1; 1];
    priorDistParams = [priorDistParams;
        1.01, 1.01;
        1.01, 1.01];
    priorDistTransf = [priorDistTransf;
        1, 0;
        0.5, 0];
    
elseif isequal(modelFamily, 'SRalphavar')
    if ismember(modelNumber, [1, 3, 5, 7]) % single learning rate
        paramNames      = [paramNames, 'alpha_max'];
        paramNumbers    = [paramNumbers, 10];
        nParams         = nParams + 1;
        
        priorDistTypes  = [priorDistTypes; 1];
        priorDistParams = [priorDistParams;
            1.01, 1.01];
        priorDistTransf = [priorDistTransf;
            1, 0];
    else % both positive and negative learning rates
        paramNames      = [paramNames, 'alpha_plus_max', 'alpha_minus_max'];
        paramNumbers    = [paramNumbers, 11, 12];
        nParams         = nParams + 2;
        
        priorDistTypes  = [priorDistTypes; 1; 1];
        priorDistParams = [priorDistParams;
            1.01, 1.01;
            1.01, 1.01];
        priorDistTransf = [priorDistTransf;
            1, 0;
            1, 0];
    end;
    
elseif isequal(modelFamily, 'SRstimstick')
    paramNames      = [paramNames, 'alpha_stim_stick', 'stim_stick_bias'];
    paramNumbers    = [paramNumbers, 13, 14];
    nParams         = nParams + 2;
    
    priorDistTypes  = [priorDistTypes; 1; 1];
    priorDistParams = [priorDistParams;
        1.01, 1.01;
        1.01, 1.01];
    priorDistTransf = [priorDistTransf;
        1, 0;
        1, 0];
end;

end