% shellmdl_master is the main analysis script for the "Serotonin reduces
% belief stickiness" article.
%
% shellmdl_master loads the manually preprocessed behavioral data as input, 
% and it should not be altered. It runs all (or a subset of the) MATLAB 
% functions and scripts that were used in the article (depending on how it 
% is configured; see below). In doing so, it also saves all (or a subset of 
% the) data files that were loaded and analyzed in other software (such as 
% Jamovi, R, and SPSS). For information regarding how to obtain the
% manually preprocessed behavioral data, please check info.txt.
%
% All shellmdl_master settings (including, e.g., which analyses will be run
% each time) are defined in two auxiliary functions that may be configured 
% by the user:
% - shellmdl_set_analysis_options;
% - shellmdl_set_main_paths.
% Both such functions may be found inside the "config" subfolder. The full
% analysis pipeline of the paper is very demanding computationally and it
% will require several hours/days/weeks; thus, it might be useful to
% configure shellmdl_set_analysis_options so that the code sections from
% this script are run consecutively, but not on a single shellmdl_master
% run. [If the code sections are not run consecutively, errors may occur,
% because some functions (e.g., related to the behavioral analysis of the
% data) load results from previous sections (e.g., data preprocessing).]
%
% Importantly, shellmdl_master should be run from its folder [pwd()];
% otherwise, the "config" folder must be added to MATLAB's path in a
% different manner.
%
% List of key auxiliary functions:
%  [Settings / Script configuration]
%   shellmdl_set_analysis_options       It might be useful to configure
%                                   this function everytime the script is
%                                   run. It can be found inside the
%                                   "config" subfolder
%   shellmdl_set_main_paths             This function may be configured by
%                                   the user, but it is unlikely that it
%                                   needs to be altered more than once.
%                                   It can be found inside the "config"
%                                   subfolder
%   shellmdl_paths                      This function is coded so that it
%                                   does not need any further alteration.
%                                   It can be found inside the main code
%                                   (this) folder
%
%  [Task motivation]
%   shellmdl_show_task_motivation
%
%  [Data (pre)processing]
%   shellmdl_reformat_git_data
%   shellmdl_loop_preprocess_subj_behav_data
%   shellmdl_aggreg_preprocess_subj_behav_data
%   shellmdl_loop_preprocess_trace_behav_data
%   shellmdl_aggreg_preprocess_trace_behav_data
%   shellmdl_preprocess_demog_drug_quest_info
%
%  [Behavioral analyses (without using RL models)]
%   shellmdl_loop_analyze_subj_behav_data
%   shellmdl_aggreg_analyze_subj_behav_data
%   shellmdl_calc_p_go_per_season
%   shellmdl_calc_p_corr_per_phase
%
%  [Model simulations - Proof-of-concept depictions of belief pliability]
%   shellmdl_show_belief_pliability
%
%  [Model fitting]
%   shellmdl_loop_subj_invert_model
%
%  [Model inspection (of all RL models)]
%   shellmdl_loop_assess_TI_fit_and_get_me_and_gof_estimates
%
%  [Model comparison]
%   shellmdl_assess_btw_group_differences_in_model_frequencies
%   shellmdl_plot_model_frequencies_and_protected_EPs
%   shellmdl_calculate_difference_in_log_model_evidences
%
%  [Selected models analysis - Detailed inspection of the selected models]
%   shellmdl_loop_assess_diag_fit_and_get_param_estimates
%   shellmdl_loop_predict_subj_behavior
%   shellmdl_plot_predicted_subj_behavior
%   shellmdl_predict_group_behavior
%   shellmdl_plot_fitted_p_go_per_season
%   shellmdl_plot_predicted_group_behavior
%   shellmdl_plot_fitted_p_corr_per_phase
%   shellmdl_aggreg_data_for_cca
%   shellmdl_perform_cca_permutations
%   shellmdl_assess_plot_relations_state_inference_stickiness
%
%  [Model simulations - Effects of state inference on task performance]
%   shellmdl_loop_simulate_subj_behavior
%   shellmdl_aggreg_simulated_behavior
%   shellmdl_show_effects_of_state_inference
%
%  [Model-recovery simulations]
%   shellmdl_loop_simulate_subj_behavior
%   shellmdl_aggreg_simulated_behavior
%   shellmdl_loop_subj_invert_model
%   shellmdl_show_model_recovery_results
%
%  [Parameter-recovery simulations]
%   shellmdl_loop_simulate_subj_behavior
%   shellmdl_aggreg_simulated_behavior
%   shellmdl_loop_subj_invert_model
%   shellmdl_show_param_recovery_results
%
% [Behavioral replication of the selected-model(s) analysis]
%   shellmdl_replicate_relations_state_inference_escitalopram
%   shellmdl_assess_relations_sr_learning_escitalopram
%
% Note: Some functions involve stochastic processes, so there may be minor 
% fluctuations in the results each time shellmdl_master is run. There is 
% stochasticity (1) during model inversion, due to the use of Markov chain 
% Monte Carlo (MCMC), and (2) in the generation of simulated data 
% (presented in the Supplementary Results of the article). In both cases, 
% run-to-run variation is extremely unlikely to lead to meaningfully 
% different results: for model inversion, we used specific metrics 
% (described in the Methods of the article) to assess convergence of the 
% MCMC routines; for simulated data, we simulated a relatively large number 
% of datapoints. Still, to facilitate replicability, we provide 
% intermediate files with the results of each major processing step. To 
% load and use an intermediate file, instead of running the respective code 
% secion, please configure shellmdl_set_analysis_options accordingly.
%
% Author: Vasco A. Concei��o (but several other authors were involved in
% the functions called by shellmdl_master)
%
% Last modified: April 2024

%%
clear all; close all; clc;

% warning('off');
warning('off', 'MATLAB:dispatcher:nameConflict');       % comment/delete these lines, if desired to see the respective warnings
warning('off', 'stats:lillietest:OutOfRangePLow');
warning('off', 'stats:lillietest:OutOfRangePHigh');
warning('off', 'MATLAB:DELETE:FileNotFound');
warning('off', 'MATLAB:LargeImage');
warning('off', 'MATLAB:Figure:FigureSavedToMATFile');

disp(datetime);

%% Settings / Script configuration
addpath([pwd() filesep 'config']);  % adds the "config" folder to MATLAB's path

disp('You are about to run shellmdl_master.');
disp('This script allows you to run the analyses of the article: ''Serotonin reduces belief stickiness''.'); disp(' ');

options.usernumber  = input('Please indicate who you are, by entering: \n 1, if Vasco A. Concei��o; \n 2, if other user. \n');

disp(' '); disp('Running the analysis pipeline...');

options = shellmdl_set_analysis_options(options);       % it should be customized by the user; hence, inside the "config" folder
paths   = shellmdl_set_main_paths(options);           	% it should be customized by the user; hence, inside the "config" folder
paths   = shellmdl_paths(paths, 1, 1, 1, options);    	% it should not be customized by the user; hence, not inside the "config" folder

%% Task motivation
if options.run.taskmotivation 
    shellmdl_show_task_motivation(options, paths);
end;

% data loading can be done manually for this section of the code

%% Data (pre)processing
if options.run.datapreprocessing
    shellmdl_reformat_git_data(options, paths);
    
    shellmdl_loop_preprocess_subj_behav_data(options, paths);
    shellmdl_aggreg_preprocess_subj_behav_data(options, paths);
    
    shellmdl_loop_preprocess_trace_behav_data(options, paths);
    shellmdl_aggreg_preprocess_trace_behav_data(options, paths);
    
    shellmdl_preprocess_demog_drug_quest_info(options, paths);  % preprocesses and saves demographic, drug, and questionnaire information, while confirming that the two groups (on- vs. off-drug) were balanced
end;

if options.load.datapreprocessing
    shellmdl_load_datapreprocessing_results(options, paths);
end;

%% Model-free behavioral data analysis
if options.run.behavioralanalysis
    % run the main analyses while getting the variables that will be needed
    % for model-based behavioral analyses too:
    shellmdl_loop_analyze_subj_behav_data(options, paths);
    shellmdl_aggreg_analyze_subj_behav_data(options, paths);    % (also necessary for Figure 6A of the paper)
    
    shellmdl_calc_p_go_per_season(options, paths);              % this function saves a file that is loaded in shellmdl_plot_fitted_p_go_per_season (necessary for Figure 6A and Extended Data Figure 1A of the paper)
    shellmdl_calc_p_corr_per_phase(options, paths);             % this function saves a file that is loaded in shellmdl_plot_fitted_p_corr_per_phase (necessary for Figure 6C and Extended Data Figure 1C of the paper)
end;

if options.load.behavioralanalysis
    shellmdl_load_behavioralanalysis_results(options, paths);
end;

%% Proof-of-concept model simulations
if options.run.modelsimulations.poc
    shellmdl_show_belief_pliability(options, paths);            % this function creates the Methods Figure 3 of the paper
end;

if options.load.modelsimulations.poc
    shellmdl_load_modelsimulations_poc_results(options, paths);
end;

%% Model fitting
if options.run.modelfitting
    if options.verbose.modelfitting
        disp(' ');
        disp('--------------------------------------------------------------');
        disp('Running the full model-fitting procedure by calling shellmdl_loop_subj_invert_model repeatedly...');
        disp(' ');
        disp('Below, information will be displayed as configured in shellmdl_loop_subj_invert_model and/or in TAPAS-related functions.');
    end;
    
    for iProcedure = options.mcmc.firstProcedure:options.mcmc.lastProcedure % model fitting for: 1) model comparison (TI) - all chains at different temperatures; 2) model diagnosis - all chains at a temperature of 1
        modelInfo.dataset.name              = options.dataset.name;
        modelInfo.dataset.goNogo            = options.dataset.goNogo;
        modelInfo.dataset.session           = options.dataset.session;
        modelInfo.dataset.subjsOfInterest   = options.dataset.subjects;
        modelInfo.dataset.dataSpecification = options.mcmc.dataSpecification;
        modelInfo.dataset.traceDataFolder   = paths.results.group.behavior2model;
        
        modelInfo.rl.nHS                = options.rl.nHS;
        modelInfo.rl.modelFamily        = options.mcmc.modelFamilies{iProcedure};
        modelInfo.rl.modelFamilyNumber  = options.mcmc.modelFamilyNumbers(iProcedure);
        modelInfo.rl.modelName          = options.mcmc.modelNames{iProcedure};
        modelInfo.rl.modelNumber        = options.mcmc.modelNumbers(iProcedure);
        modelInfo.rl.iModelNumber       = options.mcmc.iModelNumbers(iProcedure);
        modelInfo.rl.paramNames         = options.mcmc.paramNames{iProcedure};
        modelInfo.rl.paramNumbers       = options.mcmc.paramNumbers{iProcedure};
        modelInfo.rl.nParams            = options.mcmc.nParams(iProcedure);
        modelInfo.rl.priorDistTypes     = options.mcmc.priorDistTypes{iProcedure};
        modelInfo.rl.priorDistParams    = options.mcmc.priorDistParams{iProcedure};
        modelInfo.rl.priorDistTransf    = options.mcmc.priorDistTransfs{iProcedure};
        
        MCMCInfo.iProcedure             = iProcedure;
        MCMCInfo.procedure              = options.mcmc.procedures(iProcedure);
        MCMCInfo.powerTemp              = options.mcmc.powerTemp(iProcedure);
        MCMCInfo.nChains                = options.mcmc.nChains(iProcedure);
        MCMCInfo.nIterations            = options.mcmc.nIterations;
        MCMCInfo.nBurninIterations      = options.mcmc.nBurninIterations;
        MCMCInfo.proposal               = options.mcmc.proposal(modelInfo.rl.paramNumbers, :);
        
        MCMCInfo.fileName               = options.mcmc.fileNames{MCMCInfo.procedure};
        MCMCInfo.verbose                = options.verbose.modelfitting;
        MCMCInfo.overwrite              = options.overwrite.modelfitting;
        
        MCMCInfo.saveAll                = options.mcmc.saveAll;
        MCMCInfo.doPlots                = options.mcmc.doPlots;
        
        MCMCInfo.outputFolder           = 'modelfitdir';
        
        shellmdl_loop_subj_invert_model(options, paths, modelInfo, MCMCInfo);
    end;
end;

if options.load.modelfitting
    shellmdl_load_modelfitting_results(options, paths);
end;

%% Model inspection
if options.run.modelinspection
    if options.verbose.modelinspection
        disp(' ');
        disp('--------------------------------------------------------------');
        disp('Running the full model-inspection procedure by calling shellmdl_loop_assess_TI_fit_and_get_me_and_gof_estimates repeatedly...');
    end;
    
    if exist(paths.results.group.modelcomparison.tempsession.all.modelEvidencesFile, 'file')        % if the model-inspection routine has been previously run for some models
        load(paths.results.group.modelcomparison.tempsession.all.modelEvidencesFile);
    else
        modelEvidences      = -Inf * ones(options.rl.nModels, options.dataset.nEffSubjects);
    end;
    if exist([paths.results.group.modelcomparison.tempsession.all.McFaddenPseudoR2File], 'file')    % if the model-inspection routine has been previously run for some models
        load([paths.results.group.modelcomparison.tempsession.all.McFaddenPseudoR2File]);
    else
        McFaddenPseudoR2    = -Inf * ones(options.rl.nModels, options.dataset.nEffSubjects);
    end;
    
    for iModel = options.modelinspection.firstModel:options.modelinspection.lastModel
        [modelEvidences(iModel, :), McFaddenPseudoR2(iModel, :)] = shellmdl_loop_assess_TI_fit_and_get_me_and_gof_estimates(options, paths, iModel);
        % shellmdl_loop_assess_diag_fit_and_get_param_estimates(options, paths, iModel); % it is only necessary to run this function for the selected model;
        % thus, shellmdl_loop_assess_diag_fit_and_get_param_estimates (like several other functions) is now being run in .selectedmodelsanalysis only
        
        % sometimes, shellmdl_loop_assess_TI_fit_and_get_me_and_gof_estimates yields an error when writing the results into .xls files;
        % saving at every iteration of the cycle ensures that the progress done until that point is not lost
        if options.save.modelinspection && options.overwrite.modelinspection
            paths       = shellmdl_paths(paths, 1);
            outputDir   = paths.results.group.modelcomparison.tempsession.alldir;
            
            if ~exist(outputDir, 'dir')
                mkdir(outputDir);
            end;
            
            save([paths.results.group.modelcomparison.tempsession.all.modelEvidencesFile], 'modelEvidences');
            save([paths.results.group.modelcomparison.tempsession.all.McFaddenPseudoR2File], 'McFaddenPseudoR2');
        end;
    end;
end;

if options.load.modelinspection
    shellmdl_load_modelinspection_results(options, paths);
end;

%% Model comparison
if options.run.modelcomparison
    if options.verbose.modelcomparison
        disp(' ');
        disp('--------------------------------------------------------------');
        disp('Running the full model-comparison procedure...');
    end;
    
    [h_diff_group_freq_main, p_diff_group_freq_main] = shellmdl_assess_btw_group_differences_in_model_frequencies(options, paths, 'main');
    if options.verbose.modelcomparison
        disp(' ');
        disp('When assessing whether the two groups differed in model frequencies (S-R and S-S-R models):');
        h_diff_group_freq_main, p_diff_group_freq_main
    end;
    
    shellmdl_plot_model_frequencies_and_protected_EPs(options, paths, 'main'); 	% creates Figure 4 of the paper; some of the text was added in Adobe Illustrator
    
    deltaLogME = shellmdl_calculate_difference_in_log_model_evidences(options, paths);
    
    [h_diff_group_freq_supp, p_diff_group_freq_supp] = shellmdl_assess_btw_group_differences_in_model_frequencies(options, paths, 'supp');
    if options.verbose.modelcomparison
        disp(' ');
        disp('When assessing whether the two groups differed in model frequencies (all models):');
        h_diff_group_freq_supp, p_diff_group_freq_supp
    end;
    
    shellmdl_plot_model_frequencies_and_protected_EPs(options, paths, 'supp');  % creates Extended Data Figure 2 of the paper; some of the text was added in Adobe Illustrator
end;

if options.load.modelcomparison
    shellmdl_load_modelcomparison_results(options, paths);
end;

%% Selected model(s) analysis
if options.run.selectedmodelsanalysis   % assesses the fit of S-S-R-8 (and, in some cases, of S-R-8, for comparison between the selected model and its nested S-R equivalent)
    if options.verbose.selectedmodelsanalysis
        disp(' ');
        disp('--------------------------------------------------------------');
        disp('Running a detailed model-inspection procedure for the selected RL model (and its nested S-R equivalent)...');
    end;
    
    for iProcedure = 1:options.selectedmodelsanalysis.nProcedures
        iModel = options.selectedmodelsanalysis.iModelNumbers(iProcedure);
        shellmdl_loop_assess_diag_fit_and_get_param_estimates(options, paths, iModel);
        shellmdl_loop_predict_subj_behavior(options, paths, iModel);
    end;
    
    shellmdl_plot_predicted_subj_behavior(options, paths);              % creates Figure 5 of the paper
    
    shellmdl_predict_group_behavior(options, paths);                    % creates the matrix to be loaded in the function(s) below
    shellmdl_plot_fitted_p_go_per_season(options, paths);               % creates Figure 6A and Extended Data Figure 1A of the paper
    shellmdl_plot_predicted_group_behavior(options, paths);             % creates Figure 6B and Extended Data Figure 1B of the paper
    shellmdl_plot_fitted_p_corr_per_phase(options, paths);              % creates Figure 6C and Extended Data Figure 1C of the paper
    
    shellmdl_aggreg_data_for_cca(options, paths);
    shellmdl_perform_cca_permutations(options, paths);
    
    shellmdl_assess_plot_relations_state_inference_stickiness(options, paths);  % creates Figures 7 and 8 of the paper
    
    if options.verbose.selectedmodelsanalysis
        disp(' ');
        disp('To assess the relations between 1) the S-R learning parameters and 2) escitalopram and OCI-R scores, please run perform_mv_reg_in_R.');
    end;
end;

if options.load.selectedmodelsanalysis
    shellmdl_load_selectedmodelsanalysis_results(options, paths);
end;

%% Simulations to show the effect of state inference on performance
if options.run.modelsimulations.effectofstateinference
    if options.verbose.modelsimulations
        disp(' ');
        disp('--------------------------------------------------------------');
        disp('Running model simulations aimed at showing how (better vs. worse) state inference influence task performance...');
    end;
    
    % simulate individual data and aggregate it:
    iModel  = options.modelsimulations.effectofstateinference.iModelNumber;
    paths  	= shellmdl_paths(paths, 1, -1, iModel, options); % -1 is the subject error code
    load([paths.results.group.modelinspection.tempsession.tempmodeldir filesep 'params_m.mat']);
    
    for iSimul = 1:options.modelsimulations.effectofstateinference.nSimulations
        params_simul_m = repmat(mean(params_m, 1), options.dataset.nEffSubjects, 1);
        if iSimul <= options.modelsimulations.effectofstateinference.nSimulationsPerParam
            params_simul_m(:, 6) = rand();      % use a different value of gamma for all subjects, on each simulation
        elseif iSimul <= 2 * options.modelsimulations.effectofstateinference.nSimulationsPerParam
            params_simul_m(:, 7) = rand() / 2;  % use a different value of zeta for all subjects, on each simulation
        else
            params_simul_m(:, 7) = 0.5 + (rand() / 2);  % use a different value of zeta (above 0.5, but below 1) for all subjects, on each simulation
        end;
        
        outputDirInfo   = 'effectofstateinference';
        groupOutputDir  = paths.results.group.modelsimulations.effectofstateinference.tempsession.alldir;
        groupOutputFile = [paths.results.group.modelsimulations.effectofstateinference.tempsession.all.effectofstateinferencefile(1:(end-4)) '-' num2str(iSimul) '.mat'];
        shellmdl_loop_simulate_subj_behavior(options, paths, iSimul, iModel, params_simul_m, outputDirInfo, groupOutputDir, groupOutputFile);
        
        inputFileInfo           = 'effectofstateinference';
        modelsimulOutputDir     = paths.results.group.modelsimulations.effectofstateinference.tempsession.alldir;
        modelsimulOutputFile    = [paths.results.group.modelsimulations.effectofstateinference.tempsession.all.aggregeffectofstateinferencefile(1:(end-4)) '-' num2str(iSimul) '.mat'];
        shellmdl_aggreg_simulated_behavior(options, paths, iSimul, iModel, inputFileInfo, modelsimulOutputDir, modelsimulOutputFile);
    end;
    
    % plot the simulated data:
    shellmdl_show_effects_of_state_inference(options, paths);   % this function creates Supplementary Results Figure 1 of the paper
end;

if options.load.modelsimulations.effectofstateinference
    shellmdl_load_modelsimulations_effectofstateinference_results(options, paths);
end;

%% Model-recovery simulations
if options.run.modelsimulations.modelrecovery
    if options.verbose.modelsimulations
        disp(' ');
        disp('--------------------------------------------------------------');
        disp('Running model-recovery simulations...');
    end;
    
    % simulate individual data and aggregate it:
    for iSimul = 1:options.modelsimulations.modelrecovery.nSimulations
        simulType   = ceil(iSimul / options.modelsimulations.modelrecovery.nSimulationsPerModel);
        iModel      = options.modelsimulations.modelrecovery.iModelNumbers(simulType);
        paths       = shellmdl_paths(paths, 1, -1, iModel, options); % -1 is the subject error code
        
        params_simul_m = repmat(options.modelsimulations.modelrecovery.paramValues{simulType, 1}, options.dataset.nEffSubjects, 1);
        
        outputDirInfo   = 'modelrecovery';
        groupOutputDir  = paths.results.group.modelsimulations.modelrecovery.tempsession.alldir;
        groupOutputFile = [paths.results.group.modelsimulations.modelrecovery.tempsession.all.modelrecoveryfile(1:(end-4)) '-' num2str(iSimul) '.mat'];
        shellmdl_loop_simulate_subj_behavior(options, paths, iSimul, iModel, params_simul_m, outputDirInfo, groupOutputDir, groupOutputFile);
        
        inputFileInfo           = 'modelrecovery';
        modelsimulOutputDir     = paths.results.group.modelsimulations.modelrecovery.tempsession.alldir;
        modelsimulOutputFile    = [paths.results.group.modelsimulations.modelrecovery.tempsession.all.aggregmodelrecoveryfile(1:(end-4)) '-' num2str(iSimul) '.mat'];
        shellmdl_aggreg_simulated_behavior(options, paths, iSimul, iModel, inputFileInfo, modelsimulOutputDir, modelsimulOutputFile);
    end;
    
    % fit the data:
    if options.verbose.modelsimulations
        disp(' ');
        disp('--------------------------------------------------------------');
        disp('Running the model-fitting procedure necessary to perform the model-recovery analysis by calling shellmdl_loop_subj_invert_model repeatedly...');
        disp(' ');
        disp('Below, information will be displayed as configured in shellmdl_loop_subj_invert_model and/or in TAPAS-related functions.');
    end;
    
    for iProcedure = options.modelsimulations.modelrecovery.firstProcedure:options.modelsimulations.modelrecovery.lastProcedure
        simulModelInfo.dataset.name                 = options.dataset.name;
        simulModelInfo.dataset.goNogo               = options.dataset.goNogo;
        simulModelInfo.dataset.session              = options.dataset.session;
        simulModelInfo.dataset.subjsOfInterest      = options.dataset.subjects;
        simulModelInfo.dataset.dataSpecification    = options.modelsimulations.modelrecovery.dataSpecification;
        simulModelInfo.dataset.traceDataFolder      = paths.results.group.behavior2model; % it can be the same
        
        simulModelInfo.rl.nHS                = options.rl.nHS;
        
        iProcedure_aux = mod(iProcedure, options.modelsimulations.modelrecovery.nSimulations); % each set of simulated data will be fit by all candidate models
        if iProcedure_aux == 0
            iProcedure_aux = options.modelsimulations.modelrecovery.nSimulations;
        end;
        simulModelInfo.rl.modelFamily        = options.modelsimulations.modelrecovery.modelFamilies{iProcedure_aux};
        simulModelInfo.rl.modelFamilyNumber  = options.modelsimulations.modelrecovery.modelFamilyNumbers(iProcedure_aux);
        simulModelInfo.rl.modelName          = options.modelsimulations.modelrecovery.modelNames{iProcedure_aux};
        simulModelInfo.rl.modelNumber        = options.modelsimulations.modelrecovery.modelNumbers(iProcedure_aux);
        simulModelInfo.rl.iModelNumber       = options.modelsimulations.modelrecovery.iModelNumbers(iProcedure_aux);
        simulModelInfo.rl.paramNames         = options.modelsimulations.modelrecovery.paramNames{iProcedure_aux};
        simulModelInfo.rl.paramNumbers       = options.modelsimulations.modelrecovery.paramNumbers{iProcedure_aux};
        simulModelInfo.rl.nParams            = options.modelsimulations.modelrecovery.nParams(iProcedure_aux);
        simulModelInfo.rl.priorDistTypes     = options.modelsimulations.modelrecovery.priorDistTypes{iProcedure_aux};
        simulModelInfo.rl.priorDistParams    = options.modelsimulations.modelrecovery.priorDistParams{iProcedure_aux};
        simulModelInfo.rl.priorDistTransf    = options.modelsimulations.modelrecovery.priorDistTransfs{iProcedure_aux};
        
        simulMCMCInfo.iProcedure             = iProcedure;
        simulMCMCInfo.procedure              = options.modelsimulations.modelrecovery.procedures(iProcedure);
        simulMCMCInfo.powerTemp              = options.modelsimulations.modelrecovery.powerTemp(iProcedure);
        simulMCMCInfo.nChains                = options.modelsimulations.modelrecovery.nChains(iProcedure);
        simulMCMCInfo.nIterations            = options.modelsimulations.modelrecovery.nIterations;
        simulMCMCInfo.nBurninIterations      = options.modelsimulations.modelrecovery.nBurninIterations;
        simulMCMCInfo.proposal               = options.modelsimulations.modelrecovery.proposal(simulModelInfo.rl.paramNumbers, :);
        
        simulMCMCInfo.fileName               = options.modelsimulations.modelrecovery.fileNames{1};
        simulMCMCInfo.verbose                = options.verbose.modelsimulations;
        simulMCMCInfo.overwrite              = options.overwrite.modelsimulations;
        
        simulMCMCInfo.saveAll                = options.modelsimulations.modelrecovery.saveAll;
        simulMCMCInfo.doPlots                = options.modelsimulations.modelrecovery.doPlots;
        
        simulMCMCInfo.outputFolder           = 'modelrecoverydir';
        
        simulMCMCInfo.simulatedDataset     	 = ceil(iProcedure / options.modelsimulations.modelrecovery.nSimulations);
        simulationResultsFile                = [paths.results.group.modelsimulations.modelrecovery.tempsession.all.modelrecoveryfile(1:(end-4)) ...
            '-' num2str(simulMCMCInfo.simulatedDataset) '.mat'];
        
        shellmdl_loop_subj_invert_model(options, paths, simulModelInfo, simulMCMCInfo, simulationResultsFile);
    end;
    
    % plot the model-recovery results:
    shellmdl_show_model_recovery_results(options, paths);       % this function creates panel A of the Supplementary Results Figure 2 of the paper
end;

if options.load.modelsimulations.modelrecovery
    shellmdl_load_modelsimulations_modelrecovery_results(options, paths);
end;

%% Parameter-recovery simulations
if options.run.modelsimulations.paramrecovery
    if options.verbose.modelsimulations
        disp(' ');
        disp('--------------------------------------------------------------');
        disp('Running parameter-recovery simulations...');
    end;
    
    % simulate individual data and aggregate it:
    for iSimul = 1:options.modelsimulations.paramrecovery.nSimulations
        simulType   = ceil(iSimul / options.modelsimulations.paramrecovery.nSimulationsPerModel);
        iModel      = options.rl.selectedModel;
        paths       = shellmdl_paths(paths, 1, -1, iModel, options); % -1 is the subject error code
        load([paths.results.group.modelinspection.tempsession.tempmodeldir filesep 'params_m.mat']);
        
        params_simul_m = repmat(mean(params_m, 1), options.dataset.nEffSubjects, 1);
        switch iSimul % vary a parameter across subjects in each simulation:
            case {1, 2, 5, 6}   % draw the learning rates, the go bias, and gamma from the respective Beta distribution
                params_simul_m(:, iSimul) = betarnd(1.01, 1.01, options.dataset.nEffSubjects, 1); % if shellmdl_set_analysis_options/shellmdl_specify_model is changed, this should be altered
            case {3, 4}         % draw the inverse temperatures from the respective Gamma distribution
                params_simul_m(:, iSimul) = gamrnd(2.00, 2.00, options.dataset.nEffSubjects, 1); % if shellmdl_set_analysis_options/shellmdl_specify_model is changed, this should be altered
            case 7              % draw zeta from the respective transformed Beta distribution
                params_simul_m(:, iSimul) = betarnd(1.01, 1.01, options.dataset.nEffSubjects, 1) / 2;
        end;
        
        outputDirInfo   = 'paramrecovery';
        groupOutputDir  = paths.results.group.modelsimulations.paramrecovery.tempsession.alldir;
        groupOutputFile = [paths.results.group.modelsimulations.paramrecovery.tempsession.all.paramrecoveryfile(1:(end-4)) '-' num2str(iSimul) '.mat'];
        shellmdl_loop_simulate_subj_behavior(options, paths, iSimul, iModel, params_simul_m, outputDirInfo, groupOutputDir, groupOutputFile);
        
        inputFileInfo           = 'paramrecovery';
        modelsimulOutputDir     = paths.results.group.modelsimulations.paramrecovery.tempsession.alldir;
        modelsimulOutputFile    = [paths.results.group.modelsimulations.paramrecovery.tempsession.all.aggregparamrecoveryfile(1:(end-4)) '-' num2str(iSimul) '.mat'];
        shellmdl_aggreg_simulated_behavior(options, paths, iSimul, iModel, inputFileInfo, modelsimulOutputDir, modelsimulOutputFile);
    end;
    
    % fit the data:
    if options.verbose.modelsimulations
        disp(' ');
        disp('--------------------------------------------------------------');
        disp('Running the model-fitting procedure necessary to perform the parameter-recovery analysis by calling shellmdl_loop_subj_invert_model repeatedly...');
        disp(' ');
        disp('Below, information will be displayed as configured in shellmdl_loop_subj_invert_model and/or in TAPAS-related functions.');
    end;
    
    for iProcedure = options.modelsimulations.paramrecovery.firstProcedure:options.modelsimulations.paramrecovery.lastProcedure
        simulModelInfo.dataset.name                 = options.dataset.name;
        simulModelInfo.dataset.goNogo               = options.dataset.goNogo;
        simulModelInfo.dataset.session              = options.dataset.session;
        simulModelInfo.dataset.subjsOfInterest      = options.dataset.subjects;
        simulModelInfo.dataset.dataSpecification    = options.modelsimulations.paramrecovery.dataSpecification;
        simulModelInfo.dataset.traceDataFolder      = paths.results.group.behavior2model; % it can be the same
        
        simulModelInfo.rl.nHS                = options.rl.nHS;
        
        iProcedure_aux                       = 1; % only the selected model will be used to fit the simulated data
        simulModelInfo.rl.modelFamily        = options.modelsimulations.paramrecovery.modelFamilies{iProcedure_aux};
        simulModelInfo.rl.modelFamilyNumber  = options.modelsimulations.paramrecovery.modelFamilyNumbers(iProcedure_aux);
        simulModelInfo.rl.modelName          = options.modelsimulations.paramrecovery.modelNames{iProcedure_aux};
        simulModelInfo.rl.modelNumber        = options.modelsimulations.paramrecovery.modelNumbers(iProcedure_aux);
        simulModelInfo.rl.iModelNumber       = options.modelsimulations.paramrecovery.iModelNumbers(iProcedure_aux);
        simulModelInfo.rl.paramNames         = options.modelsimulations.paramrecovery.paramNames{iProcedure_aux};
        simulModelInfo.rl.paramNumbers       = options.modelsimulations.paramrecovery.paramNumbers{iProcedure_aux};
        simulModelInfo.rl.nParams            = options.modelsimulations.paramrecovery.nParams(iProcedure_aux);
        simulModelInfo.rl.priorDistTypes     = options.modelsimulations.paramrecovery.priorDistTypes{iProcedure_aux};
        simulModelInfo.rl.priorDistParams    = options.modelsimulations.paramrecovery.priorDistParams{iProcedure_aux};
        simulModelInfo.rl.priorDistTransf    = options.modelsimulations.paramrecovery.priorDistTransfs{iProcedure_aux};
        
        simulMCMCInfo.iProcedure             = iProcedure;
        simulMCMCInfo.procedure              = options.modelsimulations.paramrecovery.procedures(iProcedure);
        simulMCMCInfo.powerTemp              = options.modelsimulations.paramrecovery.powerTemp(iProcedure);
        simulMCMCInfo.nChains                = options.modelsimulations.paramrecovery.nChains(iProcedure);
        simulMCMCInfo.nIterations            = options.modelsimulations.paramrecovery.nIterations;
        simulMCMCInfo.nBurninIterations      = options.modelsimulations.paramrecovery.nBurninIterations;
        simulMCMCInfo.proposal               = options.modelsimulations.paramrecovery.proposal(simulModelInfo.rl.paramNumbers, :);
        
        simulMCMCInfo.fileName               = options.modelsimulations.paramrecovery.fileNames{1};
        simulMCMCInfo.verbose                = options.verbose.modelsimulations;
        simulMCMCInfo.overwrite              = options.overwrite.modelsimulations;
        
        simulMCMCInfo.saveAll                = options.modelsimulations.paramrecovery.saveAll;
        simulMCMCInfo.doPlots                = options.modelsimulations.paramrecovery.doPlots;
        
        simulMCMCInfo.outputFolder           = 'paramrecoverydir';
        
        simulMCMCInfo.simulatedDataset     	 = iProcedure;
        simulationResultsFile                 = [paths.results.group.modelsimulations.paramrecovery.tempsession.all.paramrecoveryfile(1:(end-4)) ...
            '-' num2str(simulMCMCInfo.simulatedDataset) '.mat'];
        
        shellmdl_loop_subj_invert_model(options, paths, simulModelInfo, simulMCMCInfo, simulationResultsFile);
    end;
    
    % plot the parameter-recovery results:
    shellmdl_show_param_recovery_results(options, paths); 	% this function creates panels B and C of the Supplementary Results Figure 2 of the paper (panel D was made in Adobe Illustrator, based on the same results)
end;

if options.load.modelsimulations.paramrecovery
    shellmdl_load_modelsimulations_paramrecovery_results(options, paths);
end;

%% Behavioral replication of the selected-model(s) analysis
if options.run.behavioralreplication
    if options.verbose.behavioralreplication
        disp(' ');
        disp('--------------------------------------------------------------');
        disp('Running behavioral analysis aimed at replicating the results from the analysis of the selected RL model...');
    end;
    shellmdl_replicate_relations_state_inference_escitalopram(options, paths);  % creates Supplementary Results Figure 3 of the paper
    shellmdl_assess_relations_sr_learning_escitalopram(options, paths);         % creates Supplementary Results Figure 4 of the paper
end;

if options.load.behavioralreplication
    shellmdl_load_behavioralreplication_results(options, paths);
end;